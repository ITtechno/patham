import { Component, ViewChild } from '@angular/core';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { TranslateService } from '@ngx-translate/core';

import { Config, Nav, Platform,LoadingController,AlertController,  ToastController } from 'ionic-angular';

import { User } from '../providers';

import { Storage } from '@ionic/storage';
import { MenuController } from 'ionic-angular';
import { Events } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import { Push, PushObject, PushOptions } from '@ionic-native/push';

import { FirstRunPage } from '../pages';
import { ListMasterPage } from '../pages';
import { LoginPage } from '../pages';

import { AndroidPermissions } from '@ionic-native/android-permissions';

import { Settings } from '../providers';

@Component({
  template: `<ion-menu side="lef" [content]="content">
            <ion-icon name="ios-menu"></ion-icon>
             <ion-content>
            <div class="pollution-back good" style="">
            <div class="profile-img">
               <ion-img class="img-round" src="{{img_src}}"></ion-img>
             </div>

            <div class="pro-name">
              {{ name }}
            </div>
            <div class="pro-school">
              {{ school }}
            </div>
          </div>

            <ion-list>
             
              

              <!-- <button menuClose ion-item >
                <ion-icon ios="ios-notifications" md="md-notifications"></ion-icon> Notifications
              </button> -->

              <button menuClose (click)="OpenPage('MessagePage')" ion-item >
                <ion-icon name="mail-open"></ion-icon>
                Message
              </button>
              
              <button menuClose *ngIf="user_role == 'parent'" (click)="OpenPage('ParentAssinmentListPage')" ion-item >
                  <i class="fa fa-book" aria-hidden="true"></i>
                  Study Material
              </button>
              

              <!-- <button menuClose ion-item >
                <ion-icon ios="ios-trash" md="md-trash"></ion-icon> Trash
              </button>

              <button menuClose ion-item >
                <ion-icon ios="ios-analytics" md="md-analytics"></ion-icon> Analytics
              </button> -->
              

              <button *ngIf="user_role == 'student'" menuClose (click)="OpenPage('SearchPage')" ion-item >
                <ion-icon name="copy" class="fx-2"></ion-icon> 
                Study Material
              </button>

              <button *ngIf="user_role == 'teacher'" menuClose (click)="OpenPage('SearchSubjectPage')" ion-item >
                <ion-icon name="copy" class="fx-2"></ion-icon> 
                Study Material
              </button>


              <button menuClose *ngIf="user_role != 'driver'" (click)="OpenPage(user_role != 'admin' ? 'ReportPage' : 'AdminReportPage')" ion-item >
                <ion-icon ios="ios-trending-up" md="md-trending-up"></ion-icon>
                Report
              </button>

              <button *ngIf="user_role == 'admin'" menuClose (click)="OpenPage('FeesMainPage')" ion-item >
               <i class="fa fa-inr" aria-hidden="true"></i>
                  Fees
              </button>
                            
              <button *ngIf="user_role == 'admin'" menuClose (click)="OpenPage('AdminStudyMainPage')" ion-item >
                 <i class="fa fa-book" aria-hidden="true"></i>
                  Study Material
              </button>

              
              <button *ngIf="user_role == 'admin'" menuClose (click)="OpenPage('TransportationMainPage')" ion-item >
               <i class="fa fa-bus" aria-hidden="true"></i>
                  Transportation
              </button>           
              
              <button *ngIf="user_role == 'admin'" menuClose (click)="OpenPage('ExpensesMainPage')" ion-item >
               <i class="fa fa-inr" aria-hidden="true"></i>
                   Expenses
              </button>
              
              <button menuClose (click)="OpenPage('SettingsPage')" ion-item >
                <ion-icon ios="ios-settings" md="md-settings"></ion-icon> Setting
              </button>
             
              <button menuClose ion-item (click)="sign_out()">
                <ion-icon ios="ios-log-out" md="md-log-out"></ion-icon> Logout
              </button>
              
              <ion-item>
                <ion-label>Language</ion-label>
                <ion-select (ionChange)="chnageLanguage()" [(ngModel)]="language">
                  <ion-option value="1">English (अंग्रेजी)</ion-option>
                  <ion-option value="6">Hindi (हिंदी)</ion-option>

                  <ion-option value="13">Oriya (ଓଡ଼ିଆ)</ion-option>
                  <ion-option value="14">Bengali (বাংলা )</ion-option>

                  <ion-option value="15">Gujrati (ગુજરાતી)</ion-option>
                  
                </ion-select>
              </ion-item>  
            </ion-list>

          </ion-content>

        </ion-menu>
        <ion-nav [root]="rootPage" #content swipeBackEnabled="false"></ion-nav>`
})

export class MyApp {

  rootPage = FirstRunPage;

  logged_in : any=null;

  record:any;
  name :any;
  school:any;
  img_src: any;

  language: any;

  user_role:any;

  token: any;
  res:any;
  classesd: any;
  

  selectedLan : any = ["en","ar","fr","nl","de","hi","it","tr","ru","es","pt","cz","Or","bn","gj"];
  

  stuId: any;

  showMenu : boolean = false;

  @ViewChild(Nav) nav: Nav;


  constructor(private translate: TranslateService, 
              public toastCtrl: ToastController, 
              public loadingCtrl: LoadingController, 
              public user: User,private network: Network, 
              public events: Events,public platform: Platform,
              public menu:MenuController, 
              private push: Push,
              private androidPermissions: AndroidPermissions,
              private storage: Storage, 
              public settings: Settings, 
              private config: Config, 
              private statusBar: StatusBar,
              private splashScreen: SplashScreen,
              public alertCtrl: AlertController) {
              
              this.pushSetup();
     
     events.subscribe('user:created', (user, time) => {

      this.logged_in = user;
      
      if(this.logged_in.data){

          this.user_role = this.logged_in.data.role;

          console.log('test'+this.user_role);
      
          if(this.logged_in != null)
           { 
             this.showMenu = true;
             this.rootPage = ListMasterPage;
           }
           else
           {
             this.rootPage = FirstRunPage;
           } 
     
            this.record = user;
            if(this.record){
     
              this.name = this.record.data.fullName;
     
              if(this.record.data.photo == null)
              {
                 this.img_src = "assets/imgs/profile.jpg";
              }
              else {
                  //this.img_src = "assets/imgs/profile.jpg";
                  
                   this.img_src = "http://paatham.in/lms/uploads/profile/profile_"+this.record.data.id+'.jpg';
              }
              this.school = this.record.school[0].school_name;
            }
          console.log(this.record);
          if(this.record.refresh != undefined) {
            
          }
     }     
      
  });
  
  events.subscribe('lang:selected', (lang, time) => {
        
      this.selectedLan.forEach((key : any, val: any) => {
                  
                  if(key == lang){
                    this.language = val+1;
                  }

        })

      console.log(this.language);
  });
   
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.

      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
    this.initTranslate();
    
  }

  initTranslate() {
    // Set the default language for translation strings, and the current language.
    this.translate.setDefaultLang('en');
    const browserLang = this.translate.getBrowserLang();

    if (browserLang) {
      if (browserLang === 'zh') {
        const browserCultureLang = this.translate.getBrowserCultureLang();

        if (browserCultureLang.match(/-CN|CHS|Hans/i)) {
          this.translate.use('zh-cmn-Hans');
        } else if (browserCultureLang.match(/-TW|CHT|Hant/i)) {
          this.translate.use('zh-cmn-Hant');
        }
      } else {
        this.translate.use(this.translate.getBrowserLang());
      }
    } else {
      this.translate.use('en'); // Set your language here
    }

    this.translate.get(['BACK_BUTTON_TEXT']).subscribe(values => {
      this.config.set('ios', 'backButtonText', values.BACK_BUTTON_TEXT);
    });
  }

  ionViewDidEnter() {
    //to disable menu, or
    this.menu.enable(false);
  }

  initializeApp() {

            this.platform.ready().then(() => {

              this.settings.initializeNetworkEvents();

                  // Offline event
                this.events.subscribe('network:offline', () => {
                    alert('network:offline ==> '+this.network.type);    
                });

                // Online event
                this.events.subscribe('network:online', () => {
                    alert('network:online ==> '+this.network.type);        
                });

            });
  }

  ngOnInit(){


    this.storage.get('auth_user').then((val) => {
          
              this.logged_in = val;

            if(this.logged_in) {

              this.user_role = this.logged_in.data.role;
               
               if(this.logged_in != null)
                { 
                  this.showMenu = true;
                  this.rootPage = ListMasterPage;
                }
                else
                {
                  this.rootPage = FirstRunPage;
                } 
          
                 this.record = val;
                 if(this.record){
          
                   this.name = this.record.data.fullName;
                  
                   console.log('test'+this.record.data.photo);
                   if(this.record.data.photo == null)
                   {
                      this.img_src = "assets/imgs/profile.jpg";
                   }
                   else {
                      
                      //this.img_src = "assets/imgs/profile.jpg";

                      this.img_src = "http://paatham.in/lms/uploads/profile/profile_"+this.record.data.id+'.jpg?nocache='+ new Date();
                   }
                   this.school = this.record.school[0].school_name;
                 }

            }     
       
  });
  
}

  openPage(page) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    this.nav.setRoot(page.component);
  }

  sign_out()
  {
    this.showMenu=false;
    this.storage.clear();
    this.nav.setRoot(LoginPage);
  }

  chnageLanguage(){

      console.log(this.language);
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'accountSettings/profile',{spec: "defLang", value: this.language}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                    this.nav.setRoot(ListMasterPage);
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.nav.setRoot('LoginPage');

            })

     }); 
  }

  OpenPage(comp)
  {
     this.storage.get('auth_user').then((val) => {

          this.token = val;
          this.classesd = this.token.classesd;
          this.nav.push(comp , {token: this.token , classesd:this.classesd });
      }); 
  }

  
  pushSetup(){

    if (this.platform.is('android')) {
      
      this.push.createChannel({
        id: "channel1",
        description: "notification",
        // The importance property goes from 1 = Lowest, 2 = Low, 3 = Normal, 4 = High and 5 = Highest.
        importance: 5,
        vibration: true, 
        sound : 'notification'
       }).then(() => console.log('Channel created'));

      this.push.hasPermission()
               .then((res: any) => {

                  if (res.isEnabled) {
                    //alert('We have permission to send push notifications');
                  } else {
                    //alert('We do not have permission to send push notifications');
                  }

                });

      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.RECEIVE_BOOT_COMPLETED).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.RECEIVE_BOOT_COMPLETED)
      );
    }
    const options: PushOptions = {
      android: {
        senderID : '323542118514',
        forceShow : true
      },
      ios: {
          alert: 'true',
          badge: true,
          sound: 'false'
      }
   };
   
   const pushObject: PushObject = this.push.init(options);
   
   
   pushObject.on('notification').subscribe((notification: any) => console.log('Received a notification', notification));
  
   pushObject.on('error').subscribe(error => console.error('Error with Push plugin', error));
  
}



}
