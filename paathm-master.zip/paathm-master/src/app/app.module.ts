import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule} from '@angular/platform-browser';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Camera } from '@ionic-native/camera';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { IonicStorageModule, Storage } from '@ionic/storage';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import { Geolocation } from '@ionic-native/geolocation';

import { AndroidPermissions } from '@ionic-native/android-permissions';

import { Calendar } from '@ionic-native/calendar';

import { Push } from '@ionic-native/push';

import { DatePipe } from '@angular/common';
import { DatePicker } from '@ionic-native/date-picker';

import { File } from '@ionic-native/file';
import { FileTransfer } from '@ionic-native/file-transfer';

import { FileOpener } from '@ionic-native/file-opener';

import { Items } from '../mocks/providers/items';
import { Settings, User, Api } from '../providers';
import { MyApp } from './app.component';
import { LanguageProvider } from '../providers/language/language';



import { ImagePicker } from '@ionic-native/image-picker';

import { SocialSharing } from '@ionic-native/social-sharing';
import { Connectivity } from '../providers/connectivity-service/connectivity-service';
import { GoogleMaps } from '../providers/google-maps/google-maps';

import { AgmCoreModule } from '@agm/core';
import { LocationServiceProvider } from '../providers/location-service/location-service';
import { NotificationProvider } from '../providers/notification/notification';

import { Diagnostic } from '@ionic-native/diagnostic';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { UniqueDeviceID } from '@ionic-native/unique-device-id';

export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

export function provideSettings(storage: Storage) {

}

@NgModule({
  declarations: [
    MyApp
  ],
  imports: [
    BrowserModule,
   
    BrowserAnimationsModule,
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAf7eL74YpTdSidk1cDK1srfD9KEw5MZ9M',
      libraries: ["places"]
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp
  ],
  providers: [
    Api,
    Items,
    Push,
    User,
    Calendar,
    Network,
    DatePipe,
    DatePicker,
    ImagePicker,
    Geolocation,
    AndroidPermissions,
    File,
    FileOpener,
    SocialSharing,
    FileTransfer,
    Camera,
    SplashScreen,
    UniqueDeviceID,
    StatusBar,
    { provide: Settings, useFactory: provideSettings, deps: [Storage] },
    // Keep this to enable Ionic's runtime error handling during development
    { provide: ErrorHandler, useClass: IonicErrorHandler },
    LanguageProvider,
    Connectivity,
    GoogleMaps,
    Diagnostic,
    LocationAccuracy,
    LocationServiceProvider,
    NotificationProvider
  ]
})
export class AppModule { }
