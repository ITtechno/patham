import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FeeCollectionPage } from './fee-collection';

@NgModule({
  declarations: [
    FeeCollectionPage,
  ],
  imports: [
    IonicPageModule.forChild(FeeCollectionPage),
  ],
})
export class FeeCollectionPageModule {}
