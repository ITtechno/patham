import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Items } from '../../providers';


import { SafeResourceUrl, DomSanitizer } from '@angular/platform-browser';

@IonicPage()
@Component({
  selector: 'page-item-detail',
  templateUrl: 'item-detail.html'
})
export class ItemDetailPage {

  trustedVideoUrl: SafeResourceUrl;
  titles: any;

  constructor(public navCtrl: NavController,private domSanitizer: DomSanitizer, navParams: NavParams, items: Items) {
    this.trustedVideoUrl = this.domSanitizer.bypassSecurityTrustResourceUrl(navParams.get('videoUrl'));
    this.titles = navParams.get('title');
  }

  closeModal() {
        this.navCtrl.pop();
   }

}
