import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminaddclassshedulePage } from './adminaddclassshedule';

@NgModule({
  declarations: [
    AdminaddclassshedulePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminaddclassshedulePage),
  ],
})
export class AdminaddclassshedulePageModule {}
