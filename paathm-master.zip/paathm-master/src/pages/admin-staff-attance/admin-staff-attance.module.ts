import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStaffAttancePage } from './admin-staff-attance';

@NgModule({
  declarations: [
    AdminStaffAttancePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStaffAttancePage),
  ],
})
export class AdminStaffAttancePageModule {}
