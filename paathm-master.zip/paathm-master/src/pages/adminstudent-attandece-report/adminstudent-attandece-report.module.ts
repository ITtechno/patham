import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminstudentAttandeceReportPage } from './adminstudent-attandece-report';

@NgModule({
  declarations: [
    AdminstudentAttandeceReportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminstudentAttandeceReportPage),
  ],
})
export class AdminstudentAttandeceReportPageModule {}
