import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMarkSheetreportPage } from './admin-mark-sheetreport';

@NgModule({
  declarations: [
    AdminMarkSheetreportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMarkSheetreportPage),
  ],
})
export class AdminMarkSheetreportPageModule {}
