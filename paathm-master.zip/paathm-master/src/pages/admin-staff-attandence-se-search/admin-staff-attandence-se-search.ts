import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';
import { DatePipe } from '@angular/common';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-staff-attandence-se-search',
  templateUrl: 'admin-staff-attandence-se-search.html',
})
export class AdminStaffAttandenceSeSearchPage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any;
  sect: any;

  sectionssel: any;

  fromDate: any;
  toDate: any;
  status: any;

  students: any;

  language : any;

  lang : any = {'parent':'','student':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','admin':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController,public langs : LanguageProvider, private storage: Storage , public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     


     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

      this.storage.get('auth_user').then((val) => {
     
        this.token= val;

      })

      events.subscribe('user:flush_date', (user, time) => {

            this.fromDate = '';

      });
 
  }

  ionViewDidLoad() {

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getStudent()
  {

     if(this.fromDate && this.toDate && this.status)
     {
       
       this.navCtrl.push('AdminStaffAttandenceListPage',{'from_date':this.fromDate , 'to_date':this.toDate , 'status':this.status});
     }
     else
     {
        let msg='';
        
        if(this.fromDate == undefined || this.fromDate == '')
        {
          msg='Please Select from Field';
          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();

          return false;
        }

        if(this.toDate == undefined || this.toDate == '')
        {
          msg='Please Select to Field';

          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();
          return false;
        }

        if(this.status == undefined || this.status == '')
        {
          msg='Please Select status Field';

          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();

          return false;
        }

        
     }

  }

}