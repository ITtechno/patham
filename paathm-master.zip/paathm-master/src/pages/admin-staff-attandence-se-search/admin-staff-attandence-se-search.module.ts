import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStaffAttandenceSeSearchPage } from './admin-staff-attandence-se-search';

@NgModule({
  declarations: [
    AdminStaffAttandenceSeSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStaffAttandenceSeSearchPage),
  ],
})
export class AdminStaffAttandenceSeSearchPageModule {}
