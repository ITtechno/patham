import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';
import  moment  from 'moment';

@IonicPage()
@Component({
  selector: 'page-admin-student-indivisual-act-history-search',
  templateUrl: 'admin-student-indivisual-act-history-search.html',
})
export class AdminStudentIndivisualActHistorySearchPage {
  token: any;
  res:any;
  
  report : FormGroup;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;
  sectionslist: any;

  section: any;

  student: any;
  
  sections: any;

  se: any;
  
  yearList: any;

  class: any;
  results = [];

  studentList : any = [];

  from: any;
  monthList: any;

  language : any;
  
  to : any;
  lang : any = {'sec':'','Year':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


	constructor(public navCtrl: NavController,public formBuilder:FormBuilder, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
        
        this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

          this.report = this.formBuilder.group({
            class : ['', Validators.required],
            section: ['', Validators.required],
            from : ['', Validators.required],
            to : ['', Validators.required],
            student : ['', Validators.required],
          });

        this.class = this.report.controls['class'];
        this.section = this.report.controls['section'];
        this.from = this.report.controls['from'];    
        this.to = this.report.controls['to'];
        this.student = this.report.controls['student'];
        
          
	}

  ionViewDidLoad() {
    
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getCall(this.token.token,'attendance/indStdAttdReports/statistic').subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;



                 if(this.res){
                   
                   this.response = this.res.classes;



                   for (let key in this.response) {
                      
                      this.results.push({"id":key, "value": this.response[key]});
                   }

                   console.log(this.results);
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }
  
  getSection(){
      console.log('test');
      this.user.getPost(this.token.token,'dashboard/sectionsSubjectsList', {"classes":this.class.value}).subscribe((resp) => {
 
              if(resp){

                 this.se = resp;
                 

                 if(this.se){
                   
                   this.sections = this.se.sections;

                   this.studentList = this.se.students;
                 }
                 console.log(this.se);
              }

            }, (err) => {
 
              //console.log(err);
              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })
  }

  getYears()
  {
        
        this.yearList = [{"id":2015,"value":2015},{"id":2016,"value":2016},{"id":2017,"value":2017},{"id":2018,"value":2018},{"id":2019,"value":2019},{"id":2020,"value":2020},{"id":2021,"value":2021},{"id":2022,"value":2022},{"id":2023,"value":2023},{"id":2024,"value":2024},{"id":2025,"value":2025},{"id":2026,"value":2026},{"id":2027,"value":2027},{"id":2028,"value":2028}];

        this.monthList = [{"id":1,"value":"JAN"},{"id":2,"value":"FEB"},{"id":3,"value":"MAR"},{"id":4,"value":"APR"},{"id":5,"value":"MAY"},{"id":6,"value":"JUN"},{"id":7,"value":"JULY"},{"id":8,"value":"AUG"},{"id":9,"value":"SEP"},{"id":10,"value":"OCT"},{"id":11,"value":"NOV"},{"id":12,"value":"DEC"}];
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  saveClass(){
    this.navCtrl.push('AdminStudentIndivisualActHistoryPage',{"class":this.class.value,
                                                         "section": this.section.value,
                                                         "from" : moment(this.from.value).format('DD/MM/YYYY'),
                                                         "to": moment(this.to.value).format('DD/MM/YYYY'),
                                                         "student": this.student.value
                                                        });
  }


}
