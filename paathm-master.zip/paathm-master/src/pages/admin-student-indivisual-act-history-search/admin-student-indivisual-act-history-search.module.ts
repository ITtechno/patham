import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentIndivisualActHistorySearchPage } from './admin-student-indivisual-act-history-search';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminStudentIndivisualActHistorySearchPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentIndivisualActHistorySearchPage),
    MaterialModule
  ],
})
export class AdminStudentIndivisualActHistorySearchPageModule {}
