import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

/**
 * Generated class for the AdminpeoplePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-adminpeople',
  templateUrl: 'adminpeople.html',
})
export class AdminpeoplePage {
  
  record: any;
  language: any;
  lang: any = {"People":"","student":"","parents":"","teacher":""};

  constructor(public storage: Storage, public langs: LanguageProvider, public navCtrl: NavController, public navParams: NavParams) {


          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

               console.log(this.lang);
          });

          console.log(this.language);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminpeoplePage');
  }


  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  OpenPage(com: any)
  {
     this.navCtrl.push(com);
  }

}
