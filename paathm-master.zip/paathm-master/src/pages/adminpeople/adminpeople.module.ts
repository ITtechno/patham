import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminpeoplePage } from './adminpeople';

@NgModule({
  declarations: [
    AdminpeoplePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminpeoplePage),
  ],
})
export class AdminpeoplePageModule {}
