import { Component } from '@angular/core';
import { IonicPage, ModalController, NavController , Events , MenuController, ToastController  } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { User } from '../../providers';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-attandence-status',
  templateUrl: 'attandence-status.html',
})
export class AttandenceStatusPage {

  record: any;
  attandence: any;
  attStatus=['Absent','Present','Late','Late with Execuse','Early Dismissal'];

  attendenceStatus : any;
  userDetails: any; 
  name: any;

  language : any;
  
   lang : any = {'sec':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController, public langs : LanguageProvider ,public events: Events, public menu:MenuController, public toastCtrl: ToastController , public user: User , private storage: Storage , public modalCtrl: ModalController) {
     
       this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

  }

  ionViewDidLoad() {
          this.storage.get('auth_user').then((val) => {
        
                this.record = val;

                 for (let key in this.record.dashRecord.studentAttendance) {
		              this.attendenceStatus=this.record.dashRecord.studentAttendance[key];

		              console.log(key);
		             }
                
                if(this.attendenceStatus){
		             this.attandence=this.attendenceStatus.d;
		             this.userDetails=this.attendenceStatus.n;
                 this.name = this.userDetails.name;
                }
                  
                 
      });
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

}
