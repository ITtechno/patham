import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AttandenceStatusPage } from './attandence-status';

@NgModule({
  declarations: [
    AttandenceStatusPage,
  ],
  imports: [
    IonicPageModule.forChild(AttandenceStatusPage),
  ],
})
export class AttandenceStatusPageModule {}
