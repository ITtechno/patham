import { Component , ViewChild} from '@angular/core';

import { MenuController } from 'ionic-angular';

import { IonicPage,Platform,PopoverController, NavController,ActionSheetController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import { Camera } from '@ionic-native/camera';
import { LanguageProvider } from '../../providers';

import { ImagePicker } from '@ionic-native/image-picker';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

@IonicPage()
@Component({
  selector: 'page-adminstudent',
  templateUrl: 'adminstudent.html',
})
export class AdminstudentPage {
  

 @ViewChild('fileInput') fileInput;

  pet: string = "puppies";
  token: any;
  res:any;
  students: any;

  approval: any;
  
  searchText :any;
  searchClass : any;
  searchEmail :any;
  searchGender : any;
  searchSection :any;


  private student:FormGroup ;
  
  addres: any;
  fullName: any;
  studentRollId: any;
  email: any;
  username: any;
  password: any;
  phoneNo: any;
  mobileNo: any;
  studentClass: any;
  studentSection: any;
  hostel: any;
  transport: any;

  gender : any;
  birthday : any;

  classes: any;
  sections: any;
  
  sectionsList : any;
  hostels: any;
  transports: any;

  hostal: any;
  response: any;

  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;

  studentSuccess: any;

  language : any;
  profilePic : any;
  urlImage: any;
  time : any = new Date();
  lang : any = {'sec':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  

  constructor(private imagePicker: ImagePicker, public camera: Camera, public actionsheetCtrl :ActionSheetController , public platform :Platform,public datepipe: DatePipe, public menuCtrl : MenuController, public langs : LanguageProvider, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder ,public popoverCtrl: PopoverController, public navCtrl: NavController,private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

    this.student = this.formBuilder.group({
              fullName: ['', Validators.required],
              studentRollId: ['', Validators.required],
              email: ['', Validators.required],
              username: ['', Validators.required],
              addres : [],
              password: ['', Validators.required],
              gender  : ['', Validators.required],
              birthday: ['', Validators.required],
              studentClass: ['', Validators.required],
              studentSection: ['', Validators.required],
              mobileNo: ['', Validators.required],
              phoneNo: [],
              transport: [],
              hostel: [],
            });

    this.fullName = this.student.controls['fullName'];
    this.studentRollId = this.student.controls['studentRollId'];
    this.addres = this.student.controls['addres'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.password = this.student.controls['password'];
    this.gender  = this.student.controls['gender'];
    this.birthday = this.student.controls['birthday'];
    this.hostel = this.student.controls['hostel'];
    this.transport = this.student.controls['transport'];
    this.studentClass = this.student.controls['studentClass'];
    this.studentSection = this.student.controls['studentSection'];
    this.mobileNo = this.student.controls['mobileNo'];
    this.phoneNo = this.student.controls['phoneNo'];
  }

  advanceSearch(){

     if(this.searchText == '' && this.searchSection == '' && this.searchClass == '' && this.searchEmail == '' && this.searchGender == ''){
          
          let toast = this.toastCtrl.create({
            message: "Please fill atleast one field",
            duration: 3000,
            position: 'top'
          });
          toast.present();

          return false;
     }
     

     this.menuCtrl.close('authenticated');

     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'students/listAll/1', {searchInput: { text : this.searchText ,
                                                                                             email: this.searchEmail ,
                                                                                             gender:this.searchGender ,
                                                                                             class : this.searchClass,
                                                                                             section : this.searchSection }}).subscribe((resp) => {
                     
              if(resp){

                 this.res = resp;

                 if(this.res){
                   this.students   = this.res.students;
                   this.classes    = this.res.classes;
                   this.hostels    = this.res.hostel;
                   this.transports = this.res.transports;
                   
                   this.sectionsList = this.res.sections;
                   this.hostal = [];
                   for (let key in this.hostels) {
                      this.hostal.push({"name":this.hostels[key] , "id": key });
                   }

                   this.totalData= parseInt(this.res.totalItems);

                   if(this.totalData % this.perPage == 0)
                   {
                        this.totalPage = this.totalData / this.perPage ; 
                   }
                   else
                   {
                        this.totalPage = this.totalData / this.perPage + 1; 
                   }

                 }
                 
              }

            }, (err) => {


              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });  
  }
 
  toggleMenu() {
    this.menuCtrl.toggle('authenticated');
  }
  

  ngOnInit()
  {

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'students/listAll/'+this.page , {sortBy: "id + 0 DESC"}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                 
                 this.waitingData();

                 if(this.res){
                   this.students   = this.res.students;
                   this.classes    = this.res.classes;
                   this.hostels    = this.res.hostel;
                   this.transports = this.res.transports;
                   
                   this.sectionsList = this.res.sections;
                   this.hostal = [];
                   for (let key in this.hostels) {
                      this.hostal.push({"name":this.hostels[key] , "id": key });
                   }

                   this.totalData= parseInt(this.res.totalItems);

                   if(this.totalData % this.perPage == 0)
                   {
                        this.totalPage = this.totalData / this.perPage ; 
                   }
                   else
                   {
                        this.totalPage = this.totalData / this.perPage + 1; 
                   }

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });  


  }


  waitingData(){

     this.user.getCall(this.token.token,'students/waitingApproval').subscribe((resp) => {
              if(resp){

                 this.approval = resp;
              }

            }, (err) => {

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminstudentPage');
  }
  
  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {

            this.navCtrl.push('AdminstudenteditPage',{"id":id,"classes":this.classes,"hostels":this.hostal,"transports":this.transports});
            console.log('Cancel clicked');
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
  }

  getSection(){

      this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getAllSubjectToadd/"+this.studentClass.value;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            this.response = resp;

            if(resp){
               this.sections = this.response.sections;
            
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
    
  }
  
  doInfinite(infiniteScroll) {
  this.page = this.page+1;
  setTimeout(() => {
    this.user.getCall(this.token.token,'students/listAll/'+this.page)
       .subscribe(
         (resp) =>{
            if(resp){

               this.getData = resp;
               
               for (let key in this.getData.students) {
                  this.students.push(this.getData.students[key]);
 
                }

               this.totalData= this.getData.totalItems;

               if(this.totalData % this.perPage == 0)
               {
                    this.totalPage = this.totalData / this.perPage ; 
               }else
               {
                    this.totalPage = this.totalData / this.perPage + 1; 
               }
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();
               this.storage.clear();
               this.navCtrl.setRoot('LoginPage');
          }
       );

      infiniteScroll.complete();
    }, 1000);
  }


  OpenPage(com: any)
  {
     this.navCtrl.push(com);
  }

  saveData()
  {  
     let fd=new FormData();
     fd.append('username', this.username.value);
     fd.append('email', this.email.value);
     fd.append('fullName', this.fullName.value);
     fd.append('gender', this.gender.value);
     fd.append('birthday', this.datepipe.transform(this.birthday.value, 'dd/MM/yyyy'));
     fd.append('address', this.addres.value);
     fd.append('phoneNo', this.phoneNo.value);
     fd.append('studentRollId', this.studentRollId.value);

     fd.append('mobileNo', this.mobileNo.value);
     fd.append('photo', this.urlImage );
     fd.append('studentClass', this.studentClass.value);
     fd.append('transport', this.mobileNo.value);
     fd.append('hostel', this.mobileNo.value);
     fd.append("studentSection",this.studentSection.value);

         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.getPostMulti(this.token.token,'students', fd).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
              
              let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){
                this.navCtrl.push('AdminstudentPage');  
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })
  }

  removeUser(id: any){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="students/delete/"+id;

          this.user.getPost(this.token.token , url , {}).subscribe((resp) => {
            loading.dismiss();

            this.studentSuccess = resp;

            let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){

                let active = this.navCtrl.getActive(); 
                this.navCtrl.remove(active.index);
                this.navCtrl.push(active.component);

              }

          }, (err) => {
            
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });

  }

  pickImage(){
     
    let options = {
         // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
         maximumImagesCount: 1,
         title: 'Select Picture',
         message: 'Profile Picture', // optional default no helper message above the picker UI
         // be careful with these options as they require additional processing
         width: 400,
         quality: 80,
         outputType:1
         //             outputType: imagePicker.OutputType.BASE64_STRING
       }

    this.imagePicker.getPictures(options).then((results) => {
       
           this.profilePic = 'data:image/jpg;base64,' + results;
           
           this.urlImage = this.dataURItoBlob(this.profilePic)

     }, (err) => { });

 }

 dataURItoBlob(dataURI) {
   var binary = atob(dataURI.split(',')[1]);
   var array = [];
   for (var i = 0; i < binary.length; i++) {
      array.push(binary.charCodeAt(i));
   }
   return new Blob([new Uint8Array(array)], {
     type: 'image/jpg'
   });
 }

 getPicture() {
   if (Camera['installed']()) {
     this.camera.getPicture({
       destinationType: this.camera.DestinationType.DATA_URL,
       targetWidth: 96,
       targetHeight: 96
     }).then((data) => {
       this.profilePic = 'data:image/jpg;base64,' + data ;
       
       this.urlImage = this.dataURItoBlob(this.profilePic)

     }, (err) => {
       //alert('Unable to take photo');
     })
   } else {
     this.fileInput.nativeElement.click();
   }
 }

 processWebImage(event) {

   let reader = new FileReader();
   reader.onload = (readerEvent) => {

     let imageData = (readerEvent.target as any).result;
     this.profilePic= imageData;
   };
   
   this.urlImage = event.target.files[0];

   console.log(this.urlImage)
   reader.readAsDataURL(event.target.files[0]);
 }

 getProfileImageStyle() {
   return 'url(' + this.profilePic + ')'
 }
 
 openeditprofile() {
   let actionSheet = this.actionsheetCtrl.create({
     title: 'Option',
     cssClass: 'action-sheets-basic-page',
     buttons: [
       {
         text: 'Take photo',
         role: 'destructive',
         icon: !this.platform.is('ios') ? 'ios-camera-outline' : null,
         handler: () => {
           this.getPicture();
         }
       },
       {
         text: 'Choose photo from Gallery',
         icon: !this.platform.is('ios') ? 'ios-images-outline' : null,
         handler: () => {
           this.pickImage();
         }
       },
     ]
   });
   actionSheet.present();
 }


}
