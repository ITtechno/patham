import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminstudentreportPage } from './adminstudentreport';

@NgModule({
  declarations: [
    AdminstudentreportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminstudentreportPage),
  ],
})
export class AdminstudentreportPageModule {}
