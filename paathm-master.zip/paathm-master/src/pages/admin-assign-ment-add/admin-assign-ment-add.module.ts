import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminAssignMentAddPage } from './admin-assign-ment-add';

@NgModule({
  declarations: [
    AdminAssignMentAddPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminAssignMentAddPage),
  ],
})
export class AdminAssignMentAddPageModule {}
