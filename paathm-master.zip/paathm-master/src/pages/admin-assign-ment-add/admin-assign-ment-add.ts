import { Component , ViewChild } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';
import moment from 'moment';

@IonicPage()
@Component({
  selector: 'page-admin-assign-ment-add',
  templateUrl: 'admin-assign-ment-add.html',
})
export class AdminAssignMentAddPage {
  
  @ViewChild('fileInput') fileInput;

  className : any;
  class: FormGroup;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  language : any;
  
  lang : any = {'user':''};

  section : any;

  classes : any;

  classSec : any = [];

  teacher: any;
  teacherList: any =[];

  teacherName : any;

  sectionName : any;

  subjectName : any;
  sectionTitle : any;
  assignmentTitle : any;
  assignmentDescription : any;
  assignMentDeadline : any;
  assignmentFile : any;
  subjects : any;
  sectionList : any;

  photosUpload : any;


  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.section = this.navParams.get('data');
     
     this.classes = this.section.classes;

     this.class = this.formBuilder.group({
              className: ['', Validators.required],
              assignmentTitle: ['', Validators.required],
              sectionName: ['', Validators.required],
              subjectName: ['', Validators.required],
              assignmentDescription : ['', Validators.required],
              assignMentDeadline : ['', Validators.required],
              assignmentFile : ['']
            });

    this.className = this.class.controls['className'];
    this.assignmentTitle = this.class.controls['assignmentTitle'];
    this.assignmentDescription = this.class.controls['assignmentDescription'];

    this.assignMentDeadline = this.class.controls['assignMentDeadline'];
    this.sectionName = this.class.controls['sectionName'];
    this.subjectName = this.class.controls['subjectName'];
    this.assignmentFile = this.class.controls['assignmentFile'];

  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          let fd = new FormData();
          fd.append('AssignTitle',this.assignmentTitle.value);
          fd.append('AssignDescription',this.assignmentDescription.value);
          fd.append('AssignDeadLine',moment(this.assignMentDeadline.value).format('DD/MM/YYYY'));
          fd.append('AssignFile', this.photosUpload);
          fd.append('classId[]', this.className.value);
          fd.append('sectionId[]',this.sectionName.value);
          fd.append('subjectId',this.subjectName.value);
    
          this.user.getPost(this.token.token,'assignments' , fd).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminAssignMentListPage');
  }

  getSection(data : any){
    console.log(data);
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/onlineExams/getAllSubjectonadd/"+data.toString();

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

                   this.sectionList = this.res.sections;
                   this.subjects = this.res.subjects;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  changeListener(event) {
    
    this.photosUpload = event.target.files[0];

    console.log("photo",this.photosUpload)
  }

}

