import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DriverTrackingHistoryPage } from './driver-tracking-history';

@NgModule({
  declarations: [
    DriverTrackingHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(DriverTrackingHistoryPage),
  ],
})
export class DriverTrackingHistoryPageModule {}
