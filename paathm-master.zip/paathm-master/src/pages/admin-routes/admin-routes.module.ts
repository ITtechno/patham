import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRoutesPage } from './admin-routes';

@NgModule({
  declarations: [
    AdminRoutesPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRoutesPage),
  ],
})
export class AdminRoutesPageModule {}
