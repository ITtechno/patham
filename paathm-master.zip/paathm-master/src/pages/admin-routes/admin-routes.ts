import { Component } from '@angular/core';
import { IonicPage, NavController,AlertController ,  ActionSheetController, NavParams,LoadingController , ModalController, ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-routes',
  templateUrl: 'admin-routes.html',
})
export class AdminRoutesPage {

  inputData: any;
  token: any;
  res: any;
  
  result : any;

  id : any;

  language : any;

  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  
  constructor(public navCtrl: NavController, 
              public modalCtrl :ModalController, 
              public langs : LanguageProvider , 
              private storage: Storage, 
              private alertCtrl : AlertController,
              public loadingCtrl: LoadingController, 
              public user: User, 
              public actionSheetCtrl: ActionSheetController,
              public toastCtrl: ToastController , 
              public navParams: NavParams) {

      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }
  
  presentPopover(id: any , tracking : any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.editTransport(id);
          }
        },
        {
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
  }

  editTransport(id){
    let profileModal = this.modalCtrl.create('AdminRoutesEditPage' , {id : id});
    profileModal.present();
  }
  
  delete(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/removeTptRoute/"+this.id;

		      this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;
               
              if(this.res.status == 'success'){

                    let toast = this.toastCtrl.create({
                  message: this.res.message,
                  duration: 3000,
                  position: 'top'
                });
                toast.present();

                this.getData();

              }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });

  }

  deleteConfirm(id : any) {
    this.id = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.delete(this.id);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }


  AddNewClass(){
    let profileModal = this.modalCtrl.create('AdminRoutesAddPage');
    profileModal.present();
  }

  ionViewDidLoad() {
       this.getData();
  }
  
  getData(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/tpt_routes_listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.result = this.res.tpt_routes_detatils;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

}

