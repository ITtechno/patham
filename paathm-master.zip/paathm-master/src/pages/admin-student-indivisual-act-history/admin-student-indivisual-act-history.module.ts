import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentIndivisualActHistoryPage } from './admin-student-indivisual-act-history';

@NgModule({
  declarations: [
    AdminStudentIndivisualActHistoryPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentIndivisualActHistoryPage),
  ],
})
export class AdminStudentIndivisualActHistoryPageModule {}
