import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSubjectsPage } from './admin-subjects';

@NgModule({
  declarations: [
    AdminSubjectsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSubjectsPage),
  ],
})
export class AdminSubjectsPageModule {}
