import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminTeacherPage } from './admin-teacher';

@NgModule({
  declarations: [
    AdminTeacherPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminTeacherPage),
  ],
})
export class AdminTeacherPageModule {}
