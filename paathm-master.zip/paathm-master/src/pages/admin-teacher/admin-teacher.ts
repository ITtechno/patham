import { Component } from '@angular/core';
import { IonicPage, ActionSheetController,PopoverController , NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

import { LanguageProvider } from '../../providers';

import { MenuController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-admin-teacher',
  templateUrl: 'admin-teacher.html',
})
export class AdminTeacherPage {

  
  pet: string = "puppies";
  token: any;
  res:any;
  students: any;

  approval: any;

  private student:FormGroup ;
  
  address : any;
  fullName: any;

  email: any;
  username: any;
  password: any;
  phoneNo: any;
  mobileNo: any;
  studentClass: any;
  studentSection: any;
  hostel: any;
  transport: any;

  gender : any;
  birthday : any;
  
  searchText :any;
  searchGender : any;
  searchEmail :any;

  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;
  transports: any;

  studentSuccess: any;

  language : any;
  
  lang : any = {'ip':'','listTeachers':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  

  constructor(public datepipe: DatePipe,public menuCtrl:MenuController, public langs: LanguageProvider, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder ,public popoverCtrl: PopoverController, public navCtrl: NavController,private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
      

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

    this.student = formBuilder.group({
              fullName: ['', Validators.required],
              studentRollId: ['', Validators.required],
              email: ['', Validators.compose([
                        Validators.required,
                        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')
                      ])],
              username: ['', Validators.required],
              address : [],
              password: ['', Validators.required],
              gender  : ['', Validators.required],
              birthday: ['', Validators.required],
              studentClass: [],
              studentSection: [],
              mobileNo: [],
              phoneNo: [],
              transport: [],
            });

    this.fullName = this.student.controls['fullName'];
    this.address = this.student.controls['address'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.password = this.student.controls['password'];
    this.gender  = this.student.controls['gender'];
    this.birthday = this.student.controls['birthday'];

    this.transport = this.student.controls['transport'];

    
    this.mobileNo = this.student.controls['mobileNo'];
    this.phoneNo = this.student.controls['phoneNo'];
  }
  

  toggleMenu() {
    this.menuCtrl.toggle('authenticated');
  }
  
  advanceSearch(){


    if(this.searchText == '' && this.searchGender == '' && this.searchEmail == ''){
         
         let toast = this.toastCtrl.create({
           message: "Please fill atleast one field",
           duration: 3000,
           position: 'top'
         });
         toast.present();

         return false;
    }

    this.menuCtrl.close('authenticated');
    
    this.storage.get('auth_user').then((val) => {
     
         this.token= val;
   
         this.user.getPost(this.token.token,'teachers/listAll/1', {searchInput: { text : this.searchText ,
                                                                                            email: this.searchEmail ,
                                                                                            gender:this.searchGender }}).subscribe((resp) => {
                    

             if(resp){

                this.res = resp;

                if(this.res){
                  this.students=this.res.teachers;
                   
                  this.transports = this.res.transports;
                  this.totalData= parseInt(this.res.totalItems);

                  if(this.totalData % this.perPage == 0)
                  {
                       this.totalPage = this.totalData / this.perPage ; 
                  }
                  else
                  {
                       this.totalPage = this.totalData / this.perPage + 1; 
                  }

                }
                
             }

           }, (err) => {


             let toast = this.toastCtrl.create({
               message: "Session has been expired",
               duration: 3000,
               position: 'top'
             });
             toast.present();

             this.storage.clear();
             this.navCtrl.setRoot('LoginPage');

           })

    });  
 }

  ionViewDidLoad() {
        
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'teachers/listAll/'+this.page , {sortBy: "id + 0 DESC"}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   this.students=this.res.teachers;
                   
                   this.transports = this.res.transports;
                   this.totalData= parseInt(this.res.totalItems);

                   if(this.totalData % this.perPage == 0)
                   {
                        this.totalPage = this.totalData / this.perPage ; 
                   }
                   else
                   {
                        this.totalPage = this.totalData / this.perPage + 1; 
                   }

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });
  }

  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.navCtrl.push('AdminteachereditPage',{"id":id,"transports":this.transports});

            console.log('Cancel clicked');
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
  }

  doInfinite(infiniteScroll) {
  this.page = this.page+1;
  setTimeout(() => {
    this.user.getCall(this.token.token,'teachers/listAll/'+this.page)
       .subscribe(
         (resp) =>{
            if(resp){

               this.getData = resp;
               
               for (let key in this.getData.students) {
                  this.students.push(this.getData.students[key]);
 
                }

               this.totalData= this.getData.totalItems;

               if(this.totalData % this.perPage == 0)
               {
                    this.totalPage = this.totalData / this.perPage ; 
               }else
               {
                    this.totalPage = this.totalData / this.perPage + 1; 
               }
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();
               this.storage.clear();
               this.navCtrl.setRoot('LoginPage');
          }
       );

      infiniteScroll.complete();
    }, 1000);
  }


  saveForm(){

           let dataValue = {"username":this.username.value,"email":this.email.value,"fullName":this.fullName.value,"password":this.password.value,"gender":this.gender.value,"address":this.address.value,"phoneNo":this.phoneNo.value,"mobileNo":this.mobileNo.value,"transport":this.transport.value,"birthday":this.datepipe.transform(this.birthday.value, 'dd/MM/yyyy')};

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.getPostMulti(this.token.token,'teachers', dataValue).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
              
              let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){
                this.navCtrl.push('AdminTeacherPage');  
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })
  }

   nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  removeUser(id: any){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="teachers/delete/"+id;

          this.user.getPost(this.token.token , url , {}).subscribe((resp) => {
            loading.dismiss();

            this.studentSuccess = resp;

            let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){

                    let active = this.navCtrl.getActive(); 
                    this.navCtrl.remove(active.index);
                    this.navCtrl.push(active.component);

              }

          }, (err) => {
            
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });

  }

}
