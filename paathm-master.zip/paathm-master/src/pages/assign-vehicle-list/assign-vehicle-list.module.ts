import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AssignVehicleListPage } from './assign-vehicle-list';

@NgModule({
  declarations: [
    AssignVehicleListPage,
  ],
  imports: [
    IonicPageModule.forChild(AssignVehicleListPage),
  ],
})
export class AssignVehicleListPageModule {}
