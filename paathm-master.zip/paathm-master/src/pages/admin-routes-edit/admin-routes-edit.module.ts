import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRoutesEditPage } from './admin-routes-edit';

@NgModule({
  declarations: [
    AdminRoutesEditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRoutesEditPage),
  ],
})
export class AdminRoutesEditPageModule {}
