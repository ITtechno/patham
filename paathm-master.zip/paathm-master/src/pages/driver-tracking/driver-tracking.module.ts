import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DriverTrackingPage } from './driver-tracking';
import { SocketService } from './../../providers';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    DriverTrackingPage,
  ],
  imports: [
    IonicPageModule.forChild(DriverTrackingPage),
    MaterialModule
  ],
  providers:[
    SocketService
  ]
})
export class DriverTrackingPageModule {}
