import { Component, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { IonicPage, NavController, LoadingController, ToastController } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Subscription } from 'rxjs/Subscription';
import { filter } from 'rxjs/operators';
import { Storage } from '@ionic/storage';

import { Diagnostic } from '@ionic-native/diagnostic';
import { Geoposition } from '@ionic-native/geolocation';
import uuid from 'uuid/v1';

import { LocationServiceProvider } from '../../providers/location-service/location-service';
import { NotificationProvider } from '../../providers/notification/notification';

import { User } from '../../providers';


import { SocketService } from './../../providers';
declare var google;

@IonicPage()
@Component({
  selector: 'page-driver-tracking',
  templateUrl: 'driver-tracking.html',
})
export class DriverTrackingPage implements AfterViewInit, OnDestroy {

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  currentMapTrack = null;

  data: any = 'test';
  data1: any = 'test1';

  isTracking = false;
  trackedRoute = [];
  previousTracks = [];
  markers = [];
  positionSubscription: Subscription;


  locationDenied = false;
  locationWatcher: any;
  sessionId: string;
  lastLocation = { position: { latitude: 0, longitude: 0 } };
  tracking = false;

  driver: any;
  markerArray: any = [];

  mark: any;

  directionsDisplay: any;
  directionsService: any;

  stepDisplay: any;

  token: any;

  trackingObject: any;

  image_url: String = 'assets/imgs/navi.png';

  pointS: any;
  startPoint: any;
  endPoint: any;
  waypoints: any = [];

  respe: any

  constructor(private navCtrl: NavController,
    private diagnostic: Diagnostic,
    private user: User,
    private toastCtrl: ToastController,
    public loadingCtrl: LoadingController,
    private location: LocationServiceProvider,
    private notification: NotificationProvider,
    public socketio: SocketService, 
    private geolocation: Geolocation,
    private storage: Storage) {

  }

  ionViewDidLoad() {
    this.socketio.connect();
    this.driverVehicle();

  }

  async driverVehicle() {
    let loading = this.loadingCtrl.create({ content: 'Please Wait..' });
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {

      this.token = val;

      let url = "driver-vehicle/" + this.token.data.id;

      this.user.getCall(this.token.token, url).subscribe((resp) => {

        loading.dismiss();
        if (resp) {

          this.trackingObject = resp;
          console.log(this.trackingObject);
          this.trackingObject = this.trackingObject.tracking_details;

          this.pointS = this.trackingObject.length;
          this.startPoint = { lat: parseFloat(this.trackingObject[0].latitude), lng: parseFloat(this.trackingObject[0].longitude) };
          this.endPoint = { lat: parseFloat(this.trackingObject[this.pointS - 1].latitude), lng: parseFloat(this.trackingObject[this.pointS - 1].longitude) };

          for (let i = 0; i < (this.pointS - 2); i++) {
            if (this.trackingObject[i + 1].stop_name != "" && this.trackingObject[i + 1].stop_name != null) {
              this.waypoints.push({
                location: this.trackingObject[i + 1].stop_name,
                stopover: true
              });
            }
          }

          this.directionsDisplay = new google.maps.DirectionsRenderer;
          this.directionsService = new google.maps.DirectionsService;

          this.geolocation.getCurrentPosition({ maximumAge: 3000, timeout: 5000, enableHighAccuracy: true }).then((resp) => {
            let mylocation = new google.maps.LatLng(resp.coords.latitude, resp.coords.longitude);
            this.map = new google.maps.Map(this.mapElement.nativeElement, {
              zoom: 20,
              center: mylocation
            });

            this.directionsDisplay = new google.maps.DirectionsRenderer({ map: this.map });

            this.stepDisplay = new google.maps.InfoWindow;

            this.calculateAndDisplayRoute(this.directionsDisplay, this.directionsService, this.markerArray, this.stepDisplay, this.map);

            //this.calculateAndDisplayRouteAnother( this.directionsDisplay , this.directionsService ,this.markerArray, this.stepDisplay , this.map);

          });



        }

      }, (err) => {

        loading.dismiss();

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');
      })

    });
  }

  async calculateAndDisplayRoute(directionsDisplay, directionsService,
    markerArray, stepDisplay, map) {
    // First, remove any existing markers from the map.
    for (var i = 0; i < markerArray.length; i++) {
      markerArray[i].setMap(null);
    }

    // Retrieve the start and end locations and create a DirectionsRequest using
    // WALKING directions.
    directionsService.route({
      origin: this.startPoint,  // Haight.
      destination: this.endPoint,
      waypoints: this.waypoints,
      provideRouteAlternatives: true,
      travelMode: 'DRIVING',
      transitOptions: {
        departureTime: new Date(1337675679473),
        modes: ['BUS'],
        routingPreference: 'FEWER_TRANSFERS'
      },
      drivingOptions: {
        departureTime: new Date(/* now, or future date */),
        trafficModel: 'pessimistic'
      },
      unitSystem: google.maps.UnitSystem.IMPERIAL
    }, (response, status) => {
      // Route the directions and pass the response to a function to create
      // markers for each step.
      if (status === 'OK') {
        // document.getElementById('warnings-panel').innerHTML =
        //     '<b>' + response.routes[0].warnings + '</b>';
        directionsDisplay.setDirections(response);
        //this.showSteps(response, markerArray, stepDisplay, map);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

  async calculateAndDisplayRouteAnother(directionsDisplay, directionsService,
    markerArray, stepDisplay, map) {
    // First, remove any existing markers from the map.
    for (var i = 0; i < markerArray.length; i++) {
      markerArray[i].setMap(null);
    }

    // Retrieve the start and end locations and create a DirectionsRequest using
    // WALKING directions.
    directionsService.route({
      origin: { lat: 28.672149, lng: 77.411698 },  // Haight.
      destination: { lat: 28.535517, lng: 77.391029 },
      travelMode: 'DRIVING'
    }, (response, status) => {
      // Route the directions and pass the response to a function to create
      // markers for each step.
      if (status === 'OK') {
        // document.getElementById('warnings-panel').innerHTML =
        //     '<b>' + response.routes[0].warnings + '</b>';
        directionsDisplay.setDirections(response);
        this.showSteps(response, markerArray, stepDisplay, map);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

  showSteps(directionResult, markerArray, stepDisplay, map) {
    // For each step, place a marker, and add the text to the marker's infowindow.
    // Also attach the marker to an array so we can keep track of it and remove it
    // when calculating new routes.
    var myRoute = directionResult.routes[0].legs[0];
    for (var i = 0; i < myRoute.steps.length; i++) {
      var marker = markerArray[i] = markerArray[i] || new google.maps.Marker;
      marker.setMap(map);
      marker.setPosition(myRoute.steps[i].start_location);
      this.attachInstructionText(
        stepDisplay, marker, myRoute.steps[i].instructions, map);
    }
  }

  attachInstructionText(stepDisplay, marker, text, map) {
    google.maps.event.addListener(marker, 'click', function () {
      // Open an info window when the marker is clicked on, containing the text
      // of the step.
      stepDisplay.setContent(text);
      stepDisplay.open(map, marker);
    });
  }

  calculateAndDisplayRouteWithMode(directionsService, directionsDisplay) {
    let selectedMode = 'DRIVING';
    directionsService.route({
      origin: { lat: 28.535517, lng: 77.391029 },  // Haight.
      destination: { lat: 28.704060, lng: 77.102493 },  // Ocean Beach.
      // Note that Javascript allows us to access the constant
      // using square brackets and a string value as its
      // "property."
      travelMode: google.maps.TravelMode[selectedMode]
    }, function (response, status) {
      console.log(status);
      if (status == 'OK') {
        directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

  async addMarker(location, image) {

    var icon = {
      url: image, // url
      scaledSize: new google.maps.Size(17, 17), // scaled size
      origin: new google.maps.Point(0, 0), // origin
      anchor: new google.maps.Point(0, 0) // anchor
    };

    this.mark = new google.maps.Marker({
      position: location,
      map: this.map,
      icon: icon
    });

    this.map.setZoom(12);
    this.map.panTo(this.mark.position);
  }

  setMapOnAll(map) {
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(map);
    }
  }

  clearMarkers() {
    this.setMapOnAll(null);
  }

  deleteMarkers() {
    this.clearMarkers();
    this.markers = [];
  }

  loadHistoricRoutes() {
    this.storage.get('routes').then(data => {
      if (data) {
        this.previousTracks = data;
      }
    });
  }

  startTracking() {
    this.isTracking = true;
    this.trackedRoute = [];
    console.log('started');
    this.socketio.updateLocation('Started');


    this.positionSubscription = this.geolocation.watchPosition()
      .pipe(
        filter((p) => p.coords !== undefined) //Filter Out Errors
      )
      .subscribe(data => {
        this.data1 = JSON.stringify(data);
        this.socketio.updateLocation({ lat: data.coords.latitude, lng: data.coords.longitude });

        setTimeout(() => {

          this.trackedRoute.push({ lat: data.coords.latitude, lng: data.coords.longitude });

          console.log(data);
          this.redrawPath(this.trackedRoute);
        }, 0);
      });

  }

  redrawPath(path) {
    if (this.currentMapTrack) {
      this.currentMapTrack.setMap(null);
    }

    if (path.length > 1) {
      this.currentMapTrack = new google.maps.Polyline({
        path: path,
        geodesic: true,
        strokeColor: '#ff00ff',
        strokeOpacity: 1.0,
        strokeWeight: 3
      });
      this.currentMapTrack.setMap(this.map);
    }
  }

  stopTracking() {
    let newRoute = { finished: new Date().getTime(), path: this.trackedRoute };
    this.previousTracks.push(newRoute);
    this.storage.set('routes', this.previousTracks);

    this.isTracking = false;
    this.positionSubscription.unsubscribe();

  }

  showHistoryRoute(route) {
    this.redrawPath(route);
  }

  ngAfterViewInit() {
    this.diagnostic.registerLocationStateChangeHandler(() => {
      this.diagnostic.isLocationEnabled().then((locationEnabled) => {
        if (!locationEnabled) {
          this.notification.toast('You need to enable location to continue!');
          this.location.requestLocationService(
            () => this.locationDenied = true
          );
        }
      });
    });
  }

  async toggleTracking() {

    if (this.isTracking) {
      this.location.removeLocationWatcher(this.locationWatcher);

      this.deleteMarkers();
      this.isTracking = false;
      return;
    }

    this.sessionId = uuid();
    this.isTracking = true;
    this.locationWatcher = this.location.registerLocationWatcher((location: Geoposition) => {

      // ignore if last location is same - later on update timestamp
      if (
        location.coords.latitude === this.lastLocation.position.latitude &&
        location.coords.longitude === this.lastLocation.position.longitude
      ) { return; }

      const pos = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      this.location
        .getPhysicalAddress(pos.latitude, pos.longitude)
        .then(address => {
          let locationEntry = {
            sessionId: this.sessionId,
            position: {
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
              physicalAddress: address,
            },
            driverPhone: 'this.driver.phone',
            timestamp: location.timestamp,
          };

          let mylocation = new google.maps.LatLng(location.coords.latitude, location.coords.longitude);
          // this.map = new google.maps.Map(this.mapElement.nativeElement, {
          //   zoom: 17,
          //   center: mylocation
          // });

          console.log(locationEntry);

          // let image = 'assets/imgs/navi.png';
          // this.addMarker(mylocation , image);

          if (!this.mark) {
            let image = 'assets/imgs/navi.png';
            this.addMarker(mylocation, image);
          }

          this.mark.setPosition(mylocation);
          this.socketio.updateLocation(locationEntry);
          // push entry to firebase
          // this.db.collection<LocationEntry>('locationHistory').add(locationEntry);
          // this.driverDocument.update({
          //   lastActive: locationEntry.timestamp,
          //   lastLocation: locationEntry.position,
          //   lastSessionId: this.sessionId,
          // });
          this.lastLocation = locationEntry;
        }).catch(error => {
          console.log(error);
        });

    });
  }

  ngOnDestroy() {
    
    this.clearMarkers();
    this.deleteMarkers();
    this.toggleTracking();
    this.socketio.resetSocket();
    this.locationWatcher.unsubscribe();
  }

  closeModal() {
    this.navCtrl.pop();
  }

  pick(pick, status) {

    this.storage.get('auth_user').then((val) => {

      this.token = val;

      let url = "pickup/pick";

      let currentTime = new Date();

      let currentOffset = currentTime.getTimezoneOffset();

      let ISTOffset = 330;   // IST offset UTC +5:30 

      let ISTTime = new Date(currentTime.getTime() + (ISTOffset + currentOffset) * 60000);

      let hoursIST = ISTTime.getHours()
      let minutesIST = ISTTime.getMinutes()

      this.user.getPostNode(this.token.token, url, {
        status: status,
        driver_id: this.token.data.id,
        route_id: pick.route_id,
        vehicle_id: pick.vehicle_id,
        school_id: pick.school_id,
        time: hoursIST + ":" + minutesIST,
        user_id: pick.id,
        trip_date: pick.trip_date
      }).subscribe((resp) => {

        if (resp) {
          this.respe = resp;

          let toast = this.toastCtrl.create({
            message: this.respe.message,
            duration: 3000,
            position: 'top'
          });
          toast.present();
          this.updateStudent();
        }

      }, (err) => {

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');
      })

    });
  }

  updateStudent() {

    this.storage.get('auth_user').then((val) => {

      this.token = val;

      let url = "driver-vehicle/" + this.token.data.id;

      this.user.getCall(this.token.token, url).subscribe((resp) => {

        if (resp) {

          this.trackingObject = resp;
          console.log(this.trackingObject);
          this.trackingObject = this.trackingObject.tracking_details;

        }

      }, (err) => {

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');
      })

    });
  }


}
