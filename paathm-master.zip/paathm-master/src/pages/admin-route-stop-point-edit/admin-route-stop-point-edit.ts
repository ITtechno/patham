import { Component , ElementRef, ViewChild, NgZone } from '@angular/core';
import { IonicPage, NavController, Platform, ViewController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

import { MapsAPILoader ,MouseEvent  } from '@agm/core';

import { Geolocation } from '@ionic-native/geolocation';

import * as moment from 'moment';

declare let google;

@IonicPage()
@Component({
  selector: 'page-admin-route-stop-point-edit',
  templateUrl: 'admin-route-stop-point-edit.html',
})
export class AdminRouteStopPointEditPage {

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  class : FormGroup;

  stop_name : any;
  start_date : any;

  route_id : any;
  route_zone : any
  point_name : any;

  end_date : any;
  picktime : any;
  droptime : any;
  description: any;

  latitude: number;
  longitude: number;
  autocompleteService: any;
  placesService: any;
  query: string = '';
  places: any = [];
  searchDisabled: boolean;
  saveDisabled: boolean;
  location: any; 

  routeList : any;
  routeZoneList : any;


  map : any;
  
  @ViewChild('map') mapElement: ElementRef;


  title: string = 'Your Location';
  zoom: number;
  address: string;
  private geoCoder;
 
  @ViewChild('search')
  public searchElementRef: ElementRef;


  constructor(private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    public navCtrl: NavController, public zone: NgZone, public platform: Platform, public geolocation: Geolocation, public viewCtrl: ViewController,public formBuilder: FormBuilder , public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
    
    this.getZoneDetails();

    this.searchDisabled = true;
        this.saveDisabled = true;

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          


     this.class = this.formBuilder.group({
              start_date: ['', Validators.required],
              route_id : ['', Validators.required],
              route_zone : ['', Validators.required],
              point_name : ['', Validators.required],

              end_date : ['', Validators.required],
              picktime : ['', Validators.required],
              droptime : ['', Validators.required],
              description : [''],
            });

    this.start_date = this.class.controls['start_date'];
    this.end_date = this.class.controls['end_date'];
    
    this.route_id = this.class.controls['route_id'];
    this.route_zone = this.class.controls['route_zone'];
    this.point_name = this.class.controls['point_name'];

    this.picktime = this.class.controls['picktime'];
    
    this.droptime = this.class.controls['droptime'];
    this.description = this.class.controls['description'];

  }

  getZoneDetails(){
      
      let loading = this.loadingCtrl.create({content:'Please Wait..'});
      loading.present(loading);
  
  
       this.storage.get('auth_user').then((val) => {
        
            this.token= val;
  
            this.user.getCall(this.token.token,'v1/transports/tpt_routes_zones_listAll').subscribe((resp) => {
                       
                loading.dismiss();  
                  if(resp){
  
                     this.res = resp;
                     
                     if(this.res){
                        this.routeList = this.res.tpt_route_detatils;
                        this.routeZoneList = this.res.tpt_routes_zones_detatils;

                     }
                      console.log(this.res);
                  }
  
              }, (err) => {
  
                loading.dismiss(); 
  
                let toast = this.toastCtrl.create({
                  message: "Session has been expired",
                  duration: 3000,
                  position: 'top'
                });
                toast.present();
  
                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
  
              })
  
       });
  
  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPost(this.token.token,'transports/tpt_route_point/'+this.route_zone.value+'/'+this.route_id.value,
                                                              {
                                                               "route_id":this.route_id.value,
                                                               "route_zone_id":this.route_zone.value,
                                                               "ruote_point_name":this.point_name.value,
                                                               "latitude":this.latitude,
                                                               "route_point_pickUptime": this.picktime.value,
                                                               "route_point_Droptime" : this.droptime.value,
                                                               "longitude":this.longitude,
                                                               "end_dt":moment(this.end_date.value).format('YYYY-MM-DD'),
                                                               "route_point_description":this.description.value,
                                                               "start_dt":moment(this.start_date.value).format('YYYY-MM-DD'),
                                                               "stopName":this.stop_name
                                                              }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminRouteStopPointPage');
  }
 
  ngOnInit() {
    //load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      this.setCurrentLocation();
      this.geoCoder = new google.maps.Geocoder;
 
      let autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ["establishment"]
      });
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {
          //get the place result
          let place= autocomplete.getPlace();
 
          //verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }
 
          //set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }
 
  // Get Current Location Coordinates
  private setCurrentLocation() {
    this.geolocation.getCurrentPosition().then((resp) => {
        this.latitude = resp.coords.latitude;
        this.longitude = resp.coords.longitude;
        this.zoom = 8;
        this.getAddress(this.latitude, this.longitude);

     }).catch((error) => {
       console.log('Error getting location', error);
     });

  }
 
 
  markerDragEnd($event: MouseEvent) {
    console.log($event);
    this.latitude = $event.coords.lat;
    this.longitude = $event.coords.lng;
    this.getAddress(this.latitude, this.longitude);
  }
 
  getAddress(latitude, longitude) {
    
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
      console.log(results);
      console.log(status);
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 12;
          this.address = results[0].formatted_address;
          this.stop_name = this.address;
          console.log(this.address);
        } else {
          window.alert('No results found');
        }
      } else {
        window.alert('Geocoder failed due to: ' + status);
      }
 
    });
  }
 
  
}