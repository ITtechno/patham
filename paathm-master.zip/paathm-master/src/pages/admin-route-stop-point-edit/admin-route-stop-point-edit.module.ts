import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRouteStopPointEditPage } from './admin-route-stop-point-edit';

import { AgmCoreModule } from '@agm/core';
import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminRouteStopPointEditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRouteStopPointEditPage),
    AgmCoreModule,
    MaterialModule
  ],
})
export class AdminRouteStopPointEditPageModule {}
