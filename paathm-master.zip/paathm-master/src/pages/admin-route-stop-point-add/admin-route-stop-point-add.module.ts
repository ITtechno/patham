import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRouteStopPointAddPage } from './admin-route-stop-point-add';
import { AgmCoreModule } from '@agm/core';
import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminRouteStopPointAddPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRouteStopPointAddPage),
    AgmCoreModule,
    MaterialModule
  ],
})
export class AdminRouteStopPointAddPageModule {}
