import {ViewChild, Component } from '@angular/core';
import { IonicPage,Platform, NavController,ActionSheetController, Events , NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';
import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { Camera } from '@ionic-native/camera';

import { LanguageProvider } from '../../providers';

import { ImagePicker } from '@ionic-native/image-picker';

@IonicPage()
@Component({
  selector: 'page-admin-add-user',
  templateUrl: 'admin-add-user.html',
})
export class AdminAddUserPage {

  
 @ViewChild('fileInput') fileInput;

  pet: string = "puppies";
  token: any;
  res:any;
  students: any;

  approval: any;

  private student:FormGroup ;
  
  fullName: any;
  email: any;
  username: any;
  password: any;
  permissions: any;
  communication: any;
  photo : any;

  response: any;

  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;

  studentSuccess: any;
  
  success : any;
  language : any;
  urls: any = new Array<string>();
  lang : any = {'sec':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  
  urlImage : any ;

  photosUpload : any;

  customPermission : any = false;

  permissionList : any;

  customPermissions : any;

  constructor(private formBuilder:FormBuilder , private imagePicker: ImagePicker, public platform :Platform ,public actionsheetCtrl: ActionSheetController,public camera: Camera, public langs : LanguageProvider , public events:Events, public navCtrl: NavController, private storage: Storage,  public loadingCtrl: LoadingController, public user: User, public toastCtrl: ToastController , public navParams: NavParams) {

    this.langs.language().then( res => {

             this.language = res;
             
             if(this.language.dashRecord){
                this.lang = this.language.dashRecord.language;

                this.permissionList = this.language.dashRecord.adminPerm;
             }

        });
        

    this.student = this.formBuilder.group({
              fullName: ['', Validators.required],
              email: ['', Validators.required],
              username: ['', Validators.required],
              password: ['', Validators.required],
              photo  : [],
              communication: ['', Validators.required],
              permissions: ['', Validators.required],
              profilePic:['',''],
              customPermissions : [],
            });

    this.fullName = this.student.controls['fullName'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.password = this.student.controls['password'];

    this.photo  = this.student.controls['photo'];
    this.communication = this.student.controls['communication'];
    this.permissions = this.student.controls['permissions'];

    this.customPermissions = this.student.controls['customPermissions'];
  }
  
  permission(perm : any){
       switch(perm){
        case 'full':
             this.customPermission = false;
          break;
        case 'custom':
             this.customPermission = true;
          break;
        default:

       }
  }
  changeListener(event) {
    this.photosUpload = event.target.files[0];
   }

  pickImage(){
     
     let options = {
          // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
          maximumImagesCount: 1,
          title: 'Select Picture',
          message: 'Profile Picture', // optional default no helper message above the picker UI
          // be careful with these options as they require additional processing
          width: 400,
          quality: 80,
          outputType:1
          //             outputType: imagePicker.OutputType.BASE64_STRING
        }

     this.imagePicker.getPictures(options).then((results) => {
        
            this.photo = 'data:image/jpg;base64,' + results;
            
            this.urlImage = this.dataURItoBlob(this.photo)

      }, (err) => { });

  }
  
  openeditprofile() {
    let actionSheet = this.actionsheetCtrl.create({
      title: 'Option',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Take photo',
          role: 'destructive',
          icon: !this.platform.is('ios') ? 'ios-camera-outline' : null,
          handler: () => {
            this.getPicture();
          }
        },
        {
          text: 'Choose photo from Gallery',
          icon: !this.platform.is('ios') ? 'ios-images-outline' : null,
          handler: () => {
            this.pickImage();
          }
        },
      ]
    });
    actionSheet.present();
  }

  dataURItoBlob(dataURI) {
    var binary = atob(dataURI.split(',')[1]);
    var array = [];
    for (var i = 0; i < binary.length; i++) {
       array.push(binary.charCodeAt(i));
    }
    return new Blob([new Uint8Array(array)], {
      type: 'image/jpg'
    });
  }

  getPicture() {
    if (Camera['installed']()) {
      this.camera.getPicture({
        destinationType: this.camera.DestinationType.DATA_URL,
        targetWidth: 96,
        targetHeight: 96
      }).then((data) => {
        this.photo = 'data:image/jpg;base64,' + data ;
        
        this.urlImage = this.dataURItoBlob(this.photo)

      }, (err) => {
        //alert('Unable to take photo');
      })
    } else {
      this.fileInput.nativeElement.click();
    }
  }

  processWebImage(event) {

    let reader = new FileReader();
    reader.onload = (readerEvent) => {

      let imageData = (readerEvent.target as any).result;
      this.photo= imageData;
    };
    
    this.urlImage = event.target.files[0];

    console.log(this.urlImage)
    reader.readAsDataURL(event.target.files[0]);
  }

  getProfileImageStyle() {
    return 'url(' + this.photo + ')'
  }

  addNewUser(event: any){
    event.preventDefault();
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    //let parts =this.response.birthday.split('/');
    this.storage.get('auth_user').then((val) => {
      
      this.token= val;

    let fd = new FormData();
    fd.append('fullName', this.fullName.value);
    fd.append('email', this.email.value);
    fd.append('password', this.password.value);
    fd.append('username', this.username.value);

    fd.append('communication', this.communication.value);
    fd.append('permissions', this.permissions.value);
    fd.append('photo', this.urlImage);

    fd.append('customPermissions', this.customPermissions.value);
    
    let url="admins";

    this.user.getPostMulti(this.token.token , url , fd).subscribe((resp) => {
                  
           loading.dismiss();  
           if(resp){
               
                 this.success = resp;

                 let toast = this.toastCtrl.create({
                   message: this.success.message,
                   duration: 3000,
                   position: 'top'
                 });
                 toast.present();

                 this.navCtrl.setRoot('ListMasterPage');
                /*this.res = resp;
                this.response = this.res.students;*/
             
           }
         }, (err) => {

           loading.dismiss(); 

           let toast = this.toastCtrl.create({
             message: "Session has been expired",
             duration: 3000,
             position: 'top'
           });
           toast.present();

               //this.storage.clear();
               //this.navCtrl.setRoot('LoginPage');
         });
  }

    )};

}
