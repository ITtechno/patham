import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';
import { DatePipe } from '@angular/common';
import { LanguageProvider } from '../../providers';
import * as moment from 'moment';


@IonicPage()
@Component({
  selector: 'page-attendence',
  templateUrl: 'attendence.html',
})
export class AttendencePage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any;
  sect: any;

  sectionssel: any;
  myDate: any;

  students: any;

  language : any;



  
  lang : any = {'sec':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

  constructor(public navCtrl: NavController,public langs : LanguageProvider, private storage: Storage , public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

     this.token = navParams.get('token');

      events.subscribe('user:flush_date', (user, time) => {

            this.myDate = '';

      });
 
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    if(this.token){
           this.user.getAttendance(this.token.token).subscribe((resp) => {
                   
            loading.dismiss();  
            if(resp){

               this.res = resp;
               this.results = this.res.classes;
            }

          }, (err) => {

            loading.dismiss(); 

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');

          })
      }
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getSections()
  {
    // console.log(this.class);

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    //console.log(this.token.token);
    this.user.getSections(this.token.token , this.class).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){

           this.responses = resp;

           this.sect = this.responses.sections;
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');
      })

  }

  getStudent()
  {

     if(this.myDate &&  this.class  && this.sectionssel)
     {
      //this.myDate = this.datepipe.transform(this.myDate, 'dd/MM/yyyy');
      this.myDate = moment(this.myDate).format('DD/MM/YYYY');
      this.navCtrl.push('StuAttendencePage',{'classes':this.class,'section':this.sectionssel,'date':this.myDate , 'token':this.token.token});
     }
     else
     {
        let msg='';
        
        if(this.class  == undefined )
        {
          msg='Please Select class Field';
        }
        else if(this.sectionssel  == undefined)
        {
          msg='Please Select section Field';
        }
        else if(this.myDate == undefined || this.myDate == '')
        {
          msg='Please Select date Field';
        }

        let toast = this.toastCtrl.create({
          message: msg,
          duration: 3000,
          position: 'top'
        });
        toast.present();
     }

  }

}
