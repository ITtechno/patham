import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSearchMarksheetGenrationListPage } from './admin-search-marksheet-genration-list';

@NgModule({
  declarations: [
    AdminSearchMarksheetGenrationListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSearchMarksheetGenrationListPage),
  ],
})
export class AdminSearchMarksheetGenrationListPageModule {}
