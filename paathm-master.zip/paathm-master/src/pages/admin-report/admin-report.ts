import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-report',
  templateUrl: 'admin-report.html',
})
export class AdminReportPage {

  token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  language: any;
  
    lang : any = {'parent':'','student':'','staff':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','admin':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


	constructor(public navCtrl: NavController, public langs:LanguageProvider , public viewCtrl: ViewController
	, public navParams: NavParams, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

               console.log(this.lang);
          });

	}


  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com);

  }


}