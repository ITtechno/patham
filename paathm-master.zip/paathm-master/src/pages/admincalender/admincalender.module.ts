import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdmincalenderPage } from './admincalender';

@NgModule({
  declarations: [
    AdmincalenderPage,
  ],
  imports: [
    IonicPageModule.forChild(AdmincalenderPage),
  ],
})
export class AdmincalenderPageModule {}
