import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Calendar } from '@ionic-native/calendar';

@IonicPage()
@Component({
  selector: 'page-admincalender',
  templateUrl: 'admincalender.html',
})
export class AdmincalenderPage {
   
   claender : any;

  constructor(public navCtrl: NavController,private calendar: Calendar , public navParams: NavParams) {

       this.calendar.createCalendar('MyCalendar').then(
		  (msg) => { 
              
              this.claender = msg;
		      alert(JSON.stringify(msg)); 

		  },
		  (err) => { console.log(err); }
		);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdmincalenderPage');
  }

}
