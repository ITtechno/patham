import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminuserstaticsreportPage } from './adminuserstaticsreport';

@NgModule({
  declarations: [
    AdminuserstaticsreportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminuserstaticsreportPage),
  ],
})
export class AdminuserstaticsreportPageModule {}
