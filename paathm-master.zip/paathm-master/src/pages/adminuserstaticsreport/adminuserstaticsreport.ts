import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminuserstaticsreport',
  templateUrl: 'adminuserstaticsreport.html',
})
export class AdminuserstaticsreportPage {
  token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  admin: any ;
  student: any;
  teacher: any;
  parent: any;

  language : any;

  lang : any = {'sec':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

  admins: any = {"activated":"","inactivated":"","total":""};

  students: any = {"activated":"","inactivated":"","total":""};

  teachers: any = {"activated":"","inactivated":"","total":""};

  parents: any = {"activated":"","inactivated":"","total":""};

	constructor(public navCtrl: NavController, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
       
       this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

	}

  ionViewDidLoad() {
    
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getPost(this.token.token,'reports',{stats: "usersStats"
}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                  
                  console.log(this.res.admins)
                 if(this.res){
                   
                   this.admin = this.res.admins;
                   
                   this.admins = {"activated": this.admin.activated , "inactivated":this.admin.inactivated , "total":this.admin.total}; 

                   this.student = this.res.students;


                   this.teacher = this.res.teachers;
                   this.parent = this.res.parents;

                   this.students = {"activated": this.student.activated , "inactivated":this.student.inactivated , "total":this.student.total};
                   this.teachers = {"activated": this.teacher.activated , "inactivated":this.teacher.inactivated , "total":this.teacher.total};
                   this.parents = {"activated": this.parent.activated , "inactivated":this.parent.inactivated , "total":this.parent.total};


                   console.log(this.admin.activated);

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  }