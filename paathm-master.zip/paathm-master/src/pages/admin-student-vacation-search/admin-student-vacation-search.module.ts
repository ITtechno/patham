import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentVacationSearchPage } from './admin-student-vacation-search';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminStudentVacationSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentVacationSearchPage),
    MaterialModule
  ],
})
export class AdminStudentVacationSearchPageModule {}
