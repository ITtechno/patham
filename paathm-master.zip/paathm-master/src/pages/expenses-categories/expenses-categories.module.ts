import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpensesCategoriesPage } from './expenses-categories';

@NgModule({
  declarations: [
    ExpensesCategoriesPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpensesCategoriesPage),
  ],
})
export class ExpensesCategoriesPageModule {}
