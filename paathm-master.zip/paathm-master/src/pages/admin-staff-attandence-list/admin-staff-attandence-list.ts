import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import { LanguageProvider } from '../../providers';
import moment from 'moment';

@IonicPage()
@Component({
  selector: 'page-admin-staff-attandence-list',
  templateUrl: 'admin-staff-attandence-list.html',
})
export class AdminStaffAttandenceListPage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any = [];
  sect: any;

  sectionssel: any;

  fromDate: any;
  toDate: any;
  status: any;

  students: any;

  language : any;
  
  attStatus=['Absent','Present','Late','Late with Execuse','Early Dismissal'];

  lang : any = {'parent':'','student':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','admin':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController,public langs : LanguageProvider, private storage: Storage , public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
    this.fromDate = this.navParams.get('from_date');
    this.toDate = this.navParams.get('to_date');
    this.status = this.navParams.get('status');
    
    this.fromDate = moment(this.fromDate).format('DD/MM/YYYY');
    this.toDate = moment(this.toDate).format('DD/MM/YYYY');

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

      this.storage.get('auth_user').then((val) => {
     
        this.token= val;

      })
      
      this.getSections();
 
  }

  ionViewDidLoad() {

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getSections()
  {
    // console.log(this.class);

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.storage.get('auth_user').then((val) => {
     
      this.token= val;
      //console.log(this.token.token);
      this.user.getPost(this.token.token , "v1/reports" ,{ "data":{
                                                            "attendanceDayFrom":this.fromDate,
                                                            "attendanceDayTo"  :  this.toDate,
                                                            "status"           :  this.status,
                                                            "school_id"        :  0 //this.token.school[0].id
                                                           },
                                                           "stats":"stfAttendance"
                                                         }).subscribe((resp) => {
                
          loading.dismiss();  
          if(resp){

            this.responses = resp;
          }

        }, (err) => {

          loading.dismiss(); 

          let toast = this.toastCtrl.create({
            message: "Session has been expired",
            duration: 3000,
            position: 'top'
          });
          toast.present();

          this.storage.clear();
          this.navCtrl.setRoot('LoginPage');
        })
    });

  }

}
