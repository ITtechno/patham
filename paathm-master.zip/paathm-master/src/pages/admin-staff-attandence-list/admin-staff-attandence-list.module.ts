import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStaffAttandenceListPage } from './admin-staff-attandence-list';

@NgModule({
  declarations: [
    AdminStaffAttandenceListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStaffAttandenceListPage),
  ],
})
export class AdminStaffAttandenceListPageModule {}
