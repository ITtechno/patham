import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditpopoverPage } from './editpopover';

@NgModule({
  declarations: [
    EditpopoverPage,
  ],
  imports: [
    IonicPageModule.forChild(EditpopoverPage),
  ],
})
export class EditpopoverPageModule {}
