import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, ToastController  } from 'ionic-angular';

import { Storage } from '@ionic/storage';
import { User } from '../../providers';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from "@angular/forms";

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-change-password',
  templateUrl: 'change-password.html',
})
export class ChangePasswordPage {
   
   registerForm : FormGroup;
   language : any;

   res: any;
   token: any;


   lang : any = {'newPassword':'','oldPassword':'','renewPassword':'','EmailAddress':'','chgPassword':''};
  
  constructor(public navCtrl: NavController, public storage:Storage,private _fb: FormBuilder, public langs:LanguageProvider, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

        this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

               console.log(this.lang);
          });
 
  }

  ngOnInit() {

    this.registerForm = this._fb.group({
      old_password: ["", [Validators.required]],
      new_password: ["", [Validators.required]],
      confirm_password: ["", [Validators.required]]
    });

  }
  
  /*getter for email*/
  get old_password(): FormControl {
    return <FormControl>this.registerForm.get("old_password");
  }

   /*getter for email*/
  get new_password(): FormControl {
    return <FormControl>this.registerForm.get("new_password");
  }

   /*getter for email*/
  get confirm_password(): FormControl {
    return <FormControl>this.registerForm.get("confirm_password");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminstudentMainPage');
  }
  

  changePassword(){
     
     console.log(this.registerForm.value);

           console.log(this.language);
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'accountSettings/password',{password: this.registerForm.value.old_password, newPassword: this.registerForm.value.new_password,repassword: this.registerForm.value.confirm_password}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                
                
                 if(this.res){
                    let toast = this.toastCtrl.create({
                      message: this.res.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 

  }


  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com);

  }

}