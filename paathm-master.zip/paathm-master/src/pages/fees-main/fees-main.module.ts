import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FeesMainPage } from './fees-main';

@NgModule({
  declarations: [
    FeesMainPage,
  ],
  imports: [
    IonicPageModule.forChild(FeesMainPage),
  ],
})
export class FeesMainPageModule {}
