import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-chapters',
  templateUrl: 'chapters.html',
})
export class ChaptersPage {

  token: any;
  res: any;
  results:any;
  getData: any;
  subjectId: any;
  classId: any;
  title: any;


  school_data: any;

  language : any;
  lang : any;
   
  from : any;

  constructor(public navCtrl: NavController, public langs: LanguageProvider, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

     this.token = navParams.get('token');
     this.subjectId = navParams.get('subjectId');
     this.classId= navParams.get('studentClass'); 
     this.title= navParams.get('title'); 

     this.from= navParams.get('from'); 
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChaptersPage');
  }

  ngOnInit()
  {

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.school_data = val;
    
          this.user.getChapters(this.token , this.subjectId ,this.classId  , this.school_data.school[0].board_type , this.school_data.school[0].board_name , this.from  ).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                 this.results = this.res.chapters;
                
                 //console.log(this.results);

                 if(this.results == undefined)
                 {   
                        let toast = this.toastCtrl.create({
                          message: "There is no chapter available.",
                          duration: 3000,
                          position: 'top'
                        });
                        toast.present();

                        this.navCtrl.pop();
                 }
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });        
  }

  getSubChapters( chapterId: any , title: any, token: any)
  {
     this.navCtrl.push('SubChaptersPage',{chapterId: chapterId ,title: title , token: token});
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }


}
