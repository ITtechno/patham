import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { DatePipe } from '@angular/common';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-search-ebook',
  templateUrl: 'admin-search-ebook.html',
})
export class AdminSearchEbookPage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any;
  sect: any;

  sectionssel: any;
  myDate: any;

  students: any;

  language : any;

  course_from: any;
  board_type : any;
  board_typeList : any;

  board_name : any;
  board_nameList: any;

  classList: any;

  school_name : any;

  lang : any = {'sec':'','course_from':'','board_type':'','board_name':'','studyMaterial':'','Subject':'','loginActivity':'','min':'','editProfile':'','inCounts':'','ave':'','best':'','test':'','previous':'','next':'','submitAnswers':'','submitChanges':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController, public langs : LanguageProvider, private storage: Storage ,public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.school){
                 this.school_name = this.language.school[0].school_name;
               }
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.token = navParams.get('token');

      events.subscribe('user:created', (user, time) => {

            this.myDate = user;

      });
 
  }

  ionViewDidLoad() {
  
    this.storage.get('auth_user').then((val) => {
     
      this.token = val;

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    if(this.token){
           this.user.getSubjectList(this.token.token).subscribe((resp) => {
                   
            loading.dismiss();  
            if(resp){

               this.res = resp;
               this.results = this.res.classes;
            }

          }, (err) => {

            loading.dismiss(); 

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();
          })
      }

    });
  }

  getBoard(){

       let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

       this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getboardtype/"+this.course_from;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            loading.dismiss();

            this.board_typeList = resp;

            if(this.board_typeList){
               this.board_typeList = this.board_typeList.board_type;
            
            }

          }, (err) => {
            
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
  }

  getBoardName(){

       let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

       this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getBoardNameGlobal/"+this.course_from+"/"+this.board_type;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            loading.dismiss();

            this.board_nameList = resp;

            if(this.board_nameList){
               this.board_nameList = this.board_nameList.board;
            
            }

          }, (err) => {
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
  }

  getClasses(){

       let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
       this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getAllClasses/"+this.course_from+"/"+this.board_name;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            loading.dismiss();
            this.classList = resp;

            if(this.board_nameList){
               this.classList = this.classList.classes;
            
            }

          }, (err) => {
            
            loading.dismiss();
            
            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getSubjects()
  {
    // console.log(this.class);

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    //console.log(this.token.token);
    this.user.getCall(this.token.token , "materials/getAllSubject/"+this.class+"/"+this.course_from).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){
           this.responses = resp;

           this.sect = this.responses.subjects;
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');

      })

  }

  getStudent()
  {

     if(this.class  && this.sectionssel)
     {

      this.navCtrl.push('AdminListEbookPage',{'classes':this.class,'subject':this.sectionssel, 'board_type':this.board_type , 'board_name':this.board_name , 'course_from':this.course_from});
     }
     else
     {
        let msg='';
        
        if(this.class  == undefined )
        {
          msg='Please Select class Field';
        }
        else if(this.sectionssel  == undefined)
        {
          msg='Please Select section Field';
        }
        

        let toast = this.toastCtrl.create({
          message: msg,
          duration: 3000,
          position: 'top'
        });
        toast.present();
     }

  }

}

