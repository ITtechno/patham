import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSearchEbookPage } from './admin-search-ebook';

@NgModule({
  declarations: [
    AdminSearchEbookPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSearchEbookPage),
  ],
})
export class AdminSearchEbookPageModule {}
