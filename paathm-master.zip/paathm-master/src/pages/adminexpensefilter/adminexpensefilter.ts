import { Component} from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminexpensefilter',
  templateUrl: 'adminexpensefilter.html',
})
export class AdminexpensefilterPage {
  
  from : any;
  to: any;
  status : any;

  language : any;

  lang : any = {'ip':'','listTeachers':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController, public langs : LanguageProvider , public toastCtrl: ToastController , public navParams: NavParams) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminexpensefilterPage');
  }
  
  searchData(){

      if(!this.from)
      {
        this.message("Please select from date");
      }
      else if(!this.to){
         this.message("Please select to date");
      }
      else
      {
        this.navCtrl.push('AdminexpensereportPage', {"from":this.from , "to":this.to});
      }
  }

  message(msg : any){

              let toast = this.toastCtrl.create({
                message: msg,
                duration: 3000,
                position: 'top'
              });
              toast.present();
  }

}
