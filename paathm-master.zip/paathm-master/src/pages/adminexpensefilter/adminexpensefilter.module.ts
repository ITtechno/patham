import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminexpensefilterPage } from './adminexpensefilter';

@NgModule({
  declarations: [
    AdminexpensefilterPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminexpensefilterPage),
  ],
})
export class AdminexpensefilterPageModule {}
