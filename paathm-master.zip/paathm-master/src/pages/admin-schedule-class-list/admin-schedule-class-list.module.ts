import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminScheduleClassListPage } from './admin-schedule-class-list';

@NgModule({
  declarations: [
    AdminScheduleClassListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminScheduleClassListPage),
  ],
})
export class AdminScheduleClassListPageModule {}
