import { Component } from '@angular/core';
import { IonicPage, AlertController, ActionSheetController , ModalController, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';

import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-schedule-class-list',
  templateUrl: 'admin-schedule-class-list.html',
})
export class AdminScheduleClassListPage {

  token: any;
  res: any;
  results:any=[];
  getData: any;
  id:any;
  
  record: any;
  language: any ={"ClassShedule":""};

  lang : any;

  classId : any;

  sheduleData : any;
  
  stuId : any;
  constructor( private alertCtrl: AlertController ,public actionSheetCtrl: ActionSheetController , public modalCtrl: ModalController, public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
    
    this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
    this.storage.get('auth_user').then((val) => {
        
                this.record = val;

                this.token = val;
                
                if(this.record.dashRecord){

                   this.language = this.record.dashRecord.language;

                   console.log('language',this.language);
                }
    }) 

     this.id = navParams.get('id');


     this.sheduleData = navParams.get('res');
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {

      this.token = val;
      this.user.getCall( this.token.token , 'classschedule/'+this.id).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){
          this.res=resp;
         for (let key in this.res) {
         
              let sub;
              if(this.res[key].sub) { sub=this.res[key].sub; } else { sub=[]; };

              this.results.push({'day':this.res[key].dayName,'data':this.res[key].data , 'sub':sub});
            }

         console.log(this.results);   

        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

            this.storage.clear();
            this.navCtrl.setRoot('LoginPage');

      });
    });
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  closeModal() {
        this.navCtrl.pop();
  }
  
  addSchedule(id : any){
    let profileModal = this.modalCtrl.create('AdminaddclassshedulePage' , { "id" : this.sheduleData , upId : this.id });
    profileModal.present();
  }

  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.editShedule(id);
          }
        },
        {
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
}

editShedule(id : any){
  let profileModal = this.modalCtrl.create('AdminEditScheduleClassPage' , { "id" : this.sheduleData ,"schedule_id": id , upId : this.id });
  profileModal.present();
}

deleteSubject(id : any){
  let loading = this.loadingCtrl.create({content:'Please Wait..'});
  loading.present(loading);

  this.storage.get('auth_user').then((val) => {
   
        this.token = val;

        let url ="classschedule/delete/"+this.id+"/"+this.stuId;

        this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
                 
          loading.dismiss();  
          if(resp){

             this.res = resp;
             
            if(this.res.status == 'success'){

                  let toast = this.toastCtrl.create({
                message: this.res.message,
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.reloadPreviousPage();

            }
          
          }

        }, (err) => {

          loading.dismiss(); 

          let toast = this.toastCtrl.create({
            message: "Session has been expired",
            duration: 3000,
            position: 'top'
          });
          toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');
        })

    });

}

reloadPreviousPage(){

  this.navCtrl.pop();
}

deleteConfirm(id : any) {
  this.stuId = id ;
  let alert = this.alertCtrl.create({
    title: 'Confirm',
    message: 'Are you sure want to delete ?',
    buttons: [
      {
        text: 'Confirm',
        role: id,
        handler: id => {
          this.deleteSubject(this.stuId);
          
        }
      },
      {
        text: 'Cancel',
        handler: () => {
          console.log('Buy clicked');
        }
      }
    ]
  });
  alert.present();
}

}
