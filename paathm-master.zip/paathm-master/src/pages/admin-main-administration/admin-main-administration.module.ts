import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMainAdministrationPage } from './admin-main-administration';

@NgModule({
  declarations: [
    AdminMainAdministrationPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMainAdministrationPage),
  ],
})
export class AdminMainAdministrationPageModule {}
