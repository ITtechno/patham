import { Component } from '@angular/core';
import { IonicPage,AlertController, ActionSheetController,PopoverController, NavController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-users',
  templateUrl: 'admin-users.html',
})
export class AdminUsersPage {
  inputData: any;
  token: any;
  res: any;
  
  language : any;

  teacherList: any = [];

  subjects: any;
  
  stuId : any;

  admin : any;

  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  
  constructor(private alertCtrl: AlertController , public navCtrl: NavController, public actionSheetCtrl: ActionSheetController,public popoverCtrl: PopoverController, public langs : LanguageProvider , private storage: Storage,  public loadingCtrl: LoadingController, public user: User, public toastCtrl: ToastController , public navParams: NavParams) {

      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="admins/listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }
  
  teacherS(teacher: any){
  
    let teacherName = JSON.parse(teacher);
    let teachers='N/A';

    if(teacherName.length > 0){
      for (let name in teacherName) {  
        for (let key in this.teacherList) { 
          if(teacherName[name] == this.teacherList[key].id) { 
            teachers = this.teacherList[key].name.fullName;
          }
        }
      }
    }

    return teachers;

  }
  
  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {

           
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
}

removeUser(id : any){
  this.deleteConfirm(id);
}

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

  addUser(com: any)
  {
     this.navCtrl.push(com);
  }

  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteUser(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }

  deleteUser(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPost(this.token.token,'admins/delete/'+id, { }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.admin = resp;

                 if(this.admin.status){
                  let toast = this.toastCtrl.create({
                    message: this.admin.message,
                    duration: 3000,
                    position: 'top'
                  });
                  toast.present();
                   
                  this.navCtrl.pop();
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });
  }

}

