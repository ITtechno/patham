import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRoutesAddPage } from './admin-routes-add';

@NgModule({
  declarations: [
    AdminRoutesAddPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRoutesAddPage),
  ],
})
export class AdminRoutesAddPageModule {}
