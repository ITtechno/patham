import { Component } from '@angular/core';
import { IonicPage, NavController, Platform, ViewController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';



@IonicPage()
@Component({
  selector: 'page-admin-routes-add',
  templateUrl: 'admin-routes-add.html',
})
export class AdminRoutesAddPage {

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  addRoute : FormGroup;


  route_name : any;
  description : any;



  constructor(public navCtrl: NavController,public platform: Platform, public viewCtrl: ViewController,public formBuilder: FormBuilder , public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
    

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          


     this.addRoute = this.formBuilder.group({
              route_name : ['', Validators.required],

              description : ['', Validators.required],
            });

    this.route_name = this.addRoute.controls['route_name'];
    this.description = this.addRoute.controls['description'];

  }


  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPost(this.token.token,'v1/transports/tpt_routes',
                                                              {
                                                               "route_name":this.route_name.value,
                                                               "tpt_routes_description":this.description.value,
                                                              }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminRoutesPage');
  }
 
  ngOnInit() {

  }

 
  
}