import { Component } from '@angular/core';
import { IonicPage, Events , NavController,LoadingController,AlertController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminstaffattandencelist',
  templateUrl: 'adminstaffattandencelist.html',
})
export class AdminstaffattandencelistPage {

  token: any;
  res: any;
  results:any;
  class: any;
  students: any;
  sectionssel: any;
  date: any;
  selectedAll: any= false;
  selectedArray :any = [];
  attanType: any;
  sta: any;
  tot:any;

  language : any;

  attStatus : any = ['Absent' , 'Present' , 'Late' , 'Late With Execuse','Early Dismissal']
  
  lang : any = {'sec':'','saveAttendance':'','studyMaterial':'','Vacation':'','indStfActHistory':'','staff_login_seession':'','Subject':'','loginActivity':'','min':'','editProfile':'','inCounts':'','ave':'','best':'','test':'','previous':'','next':'','submitAnswers':'','submitChanges':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  

  constructor(public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public events:Events, private alertCtrl: AlertController, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

     this.token = navParams.get('token');

     this.date = navParams.get('date');
 
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    //let date=this.myDate.replace(/-/g, '/');
    
    this.user.getPost(this.token ,'sattendance/list',{'attendanceDay':this.date}).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){
           this.results=resp;
           console.log(this.results);
           if(this.results.teachers.length > 0)
           {
             this.students=this.results.teachers;
           }
           else
           {

              let toast = this.toastCtrl.create({
                message: "There is no students for attendence",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.navCtrl.pop();
           }
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');

      })
  }

 presentPrompt() {
   let alert = this.alertCtrl.create({
    title: 'Select All',
    inputs: [
      {
        label:'Present',
        name: 'attandence',
        type: 'radio',
        value:'1'
      },
      {
        label:'Absent',
        name: 'attandence',
        type: 'radio',
        value:'0'
      },
      {
        label:'Late',
        name: 'attandence',
        type: 'radio',
        value:'2'
      },
      {
        label:'Late with Execuse',
        name: 'attandence',
        type: 'radio',
        value:'3'
      },
      {
        label:'Early Dismissal',
        name: 'attandence',
        type: 'radio',
        value:'4'
      }
    ],
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: data => {

        }
      },
      {
          text: 'Submit',
          handler: data => {

            this.attanType = data;
            this.checkAll();

          }
        }
      ]
    });
    alert.present();
  }

  checkAll(){
      this.selectedAll=true;
      
      let i=0;
      for(let data of this.students) {

          this.tot = data;
          this.students[i].attendance=this.attanType;
          i++;
      }
  }

  check(id: any, event: Event){

        this.sta= event;
        if(this.sta){
          this.sta.target.checked=true;
        }
        this.checkAtttype(id , this.students[id].attendance == 0 ? 7 : this.students[id].attendance );

  }
   
checkAtttype(id: any, att: any) {
  
  console.log(att);
  let alert = this.alertCtrl.create({
    title: 'Attendence',
    inputs: [
      {
        label:'Absent',
        name: 'attandence',
        type: 'radio',
        checked: att == 7 && att != '',
        value:'0'
      },
      {
        label:'Present',
        name: 'attandence',
        type: 'radio',
        checked: att==1 && att != '',
        value:'1'
      },
      {
        label:'Late',
        name: 'attandence',
        type: 'radio',
        checked: att==2 && att != '',
        value:'2'
      },
      {
        label:'Late with Execuse',
        name: 'attandence',
        type: 'radio',
        checked: att==3 && att != '',
        value:'3'
      },
      {
        label:'Early Dismissal',
        name: 'attandence',
        type: 'radio',
        checked: att==4 && att != '',
        value:'4'
      }
    ],
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: data => {
          this.students[id].attendance=data;
        }
      },
      {
          text: 'Submit',
          handler: data => {
            this.students[id].attendance=data;
          }
        }
      ]
    });
    alert.present();
  } 

  submitatt()
  {

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    //let date=this.myDate.replace(/-/g, '/');
    
    console.log(this.students);

    this.user.getPost(this.token ,'sattendance',{'attendanceDay':this.date , 'stAttendance':this.students}).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){
           this.results=resp;
           console.log(this.results);
            let toast = this.toastCtrl.create({
              message: this.results.message,
              duration: 3000,
              position: 'top'
            });
            toast.present();
            
            this.events.publish('user:flush_date', this.tot, Date.now());
            this.navCtrl.pop();
          
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');

      })
  }


}

