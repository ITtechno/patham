import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminstaffattandencelistPage } from './adminstaffattandencelist';

@NgModule({
  declarations: [
    AdminstaffattandencelistPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminstaffattandencelistPage),
  ],
})
export class AdminstaffattandencelistPageModule {}
