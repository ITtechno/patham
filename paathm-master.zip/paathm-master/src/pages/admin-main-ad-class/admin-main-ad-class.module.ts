import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMainAdClassPage } from './admin-main-ad-class';

@NgModule({
  declarations: [
    AdminMainAdClassPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMainAdClassPage),
  ],
})
export class AdminMainAdClassPageModule {}
