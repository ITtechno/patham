import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { LanguageProvider } from '../../providers';


@IonicPage()
@Component({
  selector: 'page-admin-main-ad-class',
  templateUrl: 'admin-main-ad-class.html',
})
export class AdminMainAdClassPage {
  
  language : any;
  lang : any = {'sec':'','classSch':'','classes':'','Subjects':'','sections':'','events':'','takeExam':'','Calender':'','People':'','Year':'','Administrators':'','user':'','Inactive':'','Active':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};;

  constructor(public navCtrl: NavController, public langs : LanguageProvider, public navParams: NavParams) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminMainReportPage');
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com);

  }

}
