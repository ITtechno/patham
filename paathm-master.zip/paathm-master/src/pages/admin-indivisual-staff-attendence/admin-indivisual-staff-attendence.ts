import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-indivisual-staff-attendence',
  templateUrl: 'admin-indivisual-staff-attendence.html',
})
export class AdminIndivisualStaffAttendencePage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any;
  sect: any;

  sectionssel: any;

  year: any;
  month: any;
  staff: any;

  students: any;

  language : any;
  attendenceData : any;
  teacher : any;

  attStatus=['Absent','Present','Late','Late with Execuse','Early Dismissal'];

  lang : any = {'parent':'','student':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','admin':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  
  count = 0;

  constructor(public navCtrl: NavController,public langs : LanguageProvider, private storage: Storage , public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
    this.year = this.navParams.get('year');
    this.month = this.navParams.get('month');
    this.staff = this.navParams.get('staff');

    this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

      this.storage.get('auth_user').then((val) => {
     
        this.token= val;

      })
      
      this.getSections();
 
  }

  ionViewDidLoad() {

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getSections()
  {
    // console.log(this.class);

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.storage.get('auth_user').then((val) => {
     
      this.token= val;
      //console.log(this.token.token);
      this.user.getPost(this.token.token , "v1/reports" ,{ "data":{
                                                            "status"           :"All",
                                                            "year"             :this.year,
                                                            "month"            :this.month,
                                                            "staffList"        :this.staff,
                                                            "school_id"        :0 //this.token.school[0].id
                                                           },
                                                           "stats"             : "indStfAttdReports"
                                                         }).subscribe((resp) => {
                
          loading.dismiss();  
          if(resp){

            this.responses = resp;
            
            this.teacher = this.responses.teacher_name;
            this.attendenceData = this.responses.attendanceData;

            this.count = this.attendenceData.length;
          }

        }, (err) => {

          loading.dismiss(); 

          let toast = this.toastCtrl.create({
            message: "Session has been expired",
            duration: 3000,
            position: 'top'
          });
          toast.present();

          this.storage.clear();
          this.navCtrl.setRoot('LoginPage');
        })
    });

  }

}
