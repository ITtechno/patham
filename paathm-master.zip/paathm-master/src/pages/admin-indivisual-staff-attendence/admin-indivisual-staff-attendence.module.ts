import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminIndivisualStaffAttendencePage } from './admin-indivisual-staff-attendence';

@NgModule({
  declarations: [
    AdminIndivisualStaffAttendencePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminIndivisualStaffAttendencePage),
  ],
})
export class AdminIndivisualStaffAttendencePageModule {}
