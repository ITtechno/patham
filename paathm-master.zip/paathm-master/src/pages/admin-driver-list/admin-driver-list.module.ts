import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminDriverListPage } from './admin-driver-list';


@NgModule({
  declarations: [
    AdminDriverListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminDriverListPage),
  ],
})
export class AdminDriverListPageModule {}
