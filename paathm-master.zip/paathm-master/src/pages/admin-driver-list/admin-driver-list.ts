import { Component } from '@angular/core';
import { IonicPage, NavController, AlertController ,ActionSheetController ,ModalController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';
import { constants } from '../../service/constants';
import { LanguageProvider } from '../../providers';

import { Events } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-admin-driver-list',
  templateUrl: 'admin-driver-list.html',
})
export class AdminDriverListPage {
  
  data : any;
  inputData: any;
  token: any;
  res: any;
  image_base : any;
  language : any;
  
  stuId : any;

  count = 0;
  
  status :any = ['N/A','Active','Inactive','Deleted']
  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  
  constructor(public navCtrl: NavController,
              public modalCtrl :ModalController,
              public actionSheetCtrl : ActionSheetController,
              public langs : LanguageProvider ,
              private storage: Storage,  
              public loadingCtrl: LoadingController, 
              public alertCtrl  : AlertController,
              public user: User,
              public events: Events, 
              public toastCtrl: ToastController , 
              public navParams: NavParams) {
      
                this.events.subscribe('reloadPage1',() => {
                    this.getData();
                 });
      this.image_base = constants.IMAGE_URL;

      console.log(this.image_base);
      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
     this.getData();
  }
  
  presentPopover(id: any , tracking : any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.edit(id);
          }
        },
        {
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
  }
  

  edit(id){
    let profileModal = this.modalCtrl.create('AdminDriverListEditPage' , { id : id});
    profileModal.present();
  }

  AddNewClass(){
    let profileModal = this.modalCtrl.create('AdminAddDriverPage');
    profileModal.present();
  }

  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteSubject(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }

  deleteSubject(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="subjects/delete/"+this.stuId;

		      this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;
               
              if(this.res.status == 'success'){

                    let toast = this.toastCtrl.create({
                  message: this.res.message,
                  duration: 3000,
                  position: 'top'
                });
                toast.present();

                this.getData();

              }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });

  }

  getData(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="driver/get-drivers/"+this.token.data.school_id;

		      this.user.getCallNode(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
               
               this.count = this.res.result.length;
               this.data = this.res.result;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

}

