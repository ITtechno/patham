import { Component , ViewChild} from '@angular/core';
import { IonicPage, Platform, ActionSheetController, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { Camera } from '@ionic-native/camera';
import { ImagePicker } from '@ionic-native/image-picker';

import { onSelectFile } from './../../service/file-input';
import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';
import * as moment from 'moment';

@IonicPage()
@Component({
  selector: 'page-admin-driver-list-edit',
  templateUrl: 'admin-driver-list-edit.html',
})
export class AdminDriverListEditPage {
  
  @ViewChild('fileInput') fileInput;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  class : FormGroup;

  fullname : any;
  username : any;
  email : any;
  password : any;
  gender :any;
  birthday : any;

  address : any;

  mobileNo : any;
  phoneNo : any;

  photo : any;

  imgUrl : any;

  licenseNo : any;

       
  urlImage: any; 

  imageData: any;

  photosUpload: any;
  success: any;

  response: any = {};

  img_src: any;
  
  urls = new Array<string>();

  constructor(
    public navCtrl: NavController, 
    public formBuilder: FormBuilder , 
    public langs : LanguageProvider ,  
    public actionsheetCtrl :ActionSheetController,
    private storage: Storage ,
    public navParams: NavParams, 
    public imagePicker : ImagePicker,
    public camera :Camera,
    public platform : Platform,
    public user: User, 
    public toastCtrl: ToastController , 
    public loadingCtrl: LoadingController) {

    this.id = navParams.get('id');

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          


     this.class = this.formBuilder.group({
              fullname: ['', Validators.required],
              username: ['', Validators.required],
              email : ['', Validators.required],
              password : ['', Validators.required],
              gender : ['', Validators.required],
              birthday : ['', Validators.required],
              address : ['', Validators.required],
              phoneNo : ['', Validators.required],
              mobileNo : [''],
              photo : [''],
              licenseNo : [''],
            });

    this.fullname = this.class.controls['fullname'];
    this.username = this.class.controls['username'];
    this.email = this.class.controls['email'];
    
    this.password = this.class.controls['password'];
    this.gender = this.class.controls['gender'];

    this.birthday = this.class.controls['birthday'];

    this.address = this.class.controls['address'];
    this.phoneNo = this.class.controls['phoneNo'];
    this.mobileNo = this.class.controls['mobileNo'];

    this.photo = this.class.controls['photo'];
    this.licenseNo = this.class.controls['licenseNo'];

  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

      console.log(this.urlImage);
     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          let fd = new FormData();
          fd.append('fullname',this.fullname.value);
          fd.append('username',this.username.value);
          fd.append('email',this.email.value);
          fd.append('school_id',this.token.data.school_id);
          fd.append('password',this.password.value);
          fd.append('phoneNo',this.phoneNo.value);
          fd.append('mobileNo',this.mobileNo.value);
          fd.append('gender',this.gender.value);
          fd.append('photo',this.urlImage);
          fd.append('licenseNo',this.licenseNo.value);
          fd.append('birthday', moment(this.birthday.value).format('YYYY-MM-DD'));
          fd.append('address',this.address.value);


          this.user.getPostMultiNode(this.token.token,'driver/add-driver', 
                            fd ).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                console.log(this.res);

                  let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 
                 
              }

            }, (err) => {

              loading.dismiss();
              let msg = err.error.message;
              console.log(err);
              if(err.status == 401){
                  this.storage.clear();
                  this.navCtrl.setRoot('LoginPage');
              }
              let toast = this.toastCtrl.create({
                message: msg,
                duration: 3000,
                position: 'top'
              });
              toast.present();

              

            })

     });

  }
  
  getDataEdit(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="driver/get/"+this.id;

		      this.user.getCallNode(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
              
               this.res = this.res.result;
               
               this.response.upload = "http://35.154.195.164:3000/"+this.res.photo;
               this.class.patchValue({
                                       fullname : this.res.fullname,
                                       username : this.res.username,
                                       email    : this.res.email,
                                       school_id : this.res.school_id,
                                       phoneNo : this.res.phoneNo,
                                       mobileNo : this.res.mobileNo,
                                       gender  : this.res.gender,
                                       licenseNo : this.res.licenseNo,
                                       birthday : this.res.birthday,
                                       address : this.res.address,
                                     });
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminDriverListPage');
  }
 
  ngOnInit() {
    this.getDataEdit();  
  }
  
  async onSelectFile(event){
    let url = await onSelectFile(event);
    this.imgUrl = url.file;
    console.log('test',url);
 }
 
 changeListener(event) {
   this.photosUpload = event.target.files[0];
 }

 pickImage(){
    
    let options = {
         // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
         maximumImagesCount: 1,
         title: 'Select Picture',
         message: 'Profile Picture', // optional default no helper message above the picker UI
         // be careful with these options as they require additional processing
         width: 400,
         quality: 80,
         outputType:1
         //             outputType: imagePicker.OutputType.BASE64_STRING
       }

    this.imagePicker.getPictures(options).then((results) => {
       
           this.response.upload = 'data:image/jpg;base64,' + results;
           
           this.urlImage = this.dataURItoBlob(this.response.upload)

     }, (err) => { });

 }

 dataURItoBlob(dataURI) {
   var binary = atob(dataURI.split(',')[1]);
   var array = [];
   for (var i = 0; i < binary.length; i++) {
      array.push(binary.charCodeAt(i));
   }
   return new Blob([new Uint8Array(array)], {
     type: 'image/jpg'
   });
 }

 getPicture() {
   if (Camera['installed']()) {
     this.camera.getPicture({
       destinationType: this.camera.DestinationType.DATA_URL,
       targetWidth: 96,
       targetHeight: 96
     }).then((data) => {
       this.response.upload = 'data:image/jpg;base64,' + data ;
       
       this.urlImage = this.dataURItoBlob(this.response.upload)

     }, (err) => {
       //alert('Unable to take photo');
     })
   } else {
     this.fileInput.nativeElement.click();
   }
 }

 processWebImage(event) {

   let reader = new FileReader();
   reader.onload = (readerEvent) => {

     let imageData = (readerEvent.target as any).result;
     this.response.upload= imageData;
   };
   
   this.urlImage = event.target.files[0];

   console.log(this.urlImage)
   reader.readAsDataURL(event.target.files[0]);
 }

 getProfileImageStyle() {
   return 'url(' + this.response.upload + ')'
 }
 
 openeditprofile() {
   let actionSheet = this.actionsheetCtrl.create({
     title: 'Option',
     cssClass: 'action-sheets-basic-page',
     buttons: [
       {
         text: 'Take photo',
         role: 'destructive',
         icon: !this.platform.is('ios') ? 'ios-camera-outline' : null,
         handler: () => {
           this.getPicture();
         }
       },
       {
         text: 'Choose photo from Gallery',
         icon: !this.platform.is('ios') ? 'ios-images-outline' : null,
         handler: () => {
           this.pickImage();
         }
       },
     ]
   });
   actionSheet.present();
 }

 
  
}

