import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminDriverListEditPage } from './admin-driver-list-edit';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminDriverListEditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminDriverListEditPage),
    MaterialModule
  ],
})
export class AdminDriverListEditPageModule {}
