import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminParentLoginReportPage } from './admin-parent-login-report';

@NgModule({
  declarations: [
    AdminParentLoginReportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminParentLoginReportPage),
  ],
})
export class AdminParentLoginReportPageModule {}
