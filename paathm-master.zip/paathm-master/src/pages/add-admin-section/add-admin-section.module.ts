import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddAdminSectionPage } from './add-admin-section';

@NgModule({
  declarations: [
    AddAdminSectionPage,
  ],
  imports: [
    IonicPageModule.forChild(AddAdminSectionPage),
  ],
})
export class AddAdminSectionPageModule {}
