import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSearchBookListSyllabusPage } from './admin-search-book-list-syllabus';

@NgModule({
  declarations: [
    AdminSearchBookListSyllabusPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSearchBookListSyllabusPage),
  ],
})
export class AdminSearchBookListSyllabusPageModule {}
