import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminExpenseReportSearchPage } from './admin-expense-report-search';

@NgModule({
  declarations: [
    AdminExpenseReportSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminExpenseReportSearchPage),
  ],
})
export class AdminExpenseReportSearchPageModule {}
