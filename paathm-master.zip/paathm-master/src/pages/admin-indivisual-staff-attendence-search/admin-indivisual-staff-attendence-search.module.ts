import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminIndivisualStaffAttendenceSearchPage } from './admin-indivisual-staff-attendence-search';

@NgModule({
  declarations: [
    AdminIndivisualStaffAttendenceSearchPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminIndivisualStaffAttendenceSearchPage),
  ],
})
export class AdminIndivisualStaffAttendenceSearchPageModule {}
