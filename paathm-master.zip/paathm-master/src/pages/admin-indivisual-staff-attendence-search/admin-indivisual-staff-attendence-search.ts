import { Component } from '@angular/core';
import { IonicPage, Events, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';
import { DatePipe } from '@angular/common';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-indivisual-staff-attendence-search',
  templateUrl: 'admin-indivisual-staff-attendence-search.html',
})
export class AdminIndivisualStaffAttendenceSearchPage {

  token: any;
  res: any;
  results:any;
  getData: any;
  class: any;

  responses: any;
  sect: any;

  sectionssel: any;

  year: any;
  month: any;
  staff: any;

  students: any;

  language : any;

  lang : any = {'parent':'','student':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','admin':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public navCtrl: NavController,public langs : LanguageProvider, private storage: Storage , public events:Events, public datepipe: DatePipe, public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     


     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });

     this.getStaffList();
  }

  getStaffList(){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.storage.get('auth_user').then((val) => {
     
      this.token= val;
      //console.log(this.token.token);
      this.user.getCall(this.token.token , "v1/reports/getAllStaffs/undefined").subscribe((resp) => {
                
          loading.dismiss();  
          if(resp){

            this.responses = resp;
            this.responses = this.responses.staffs;
          }

        }, (err) => {

          loading.dismiss(); 

          let toast = this.toastCtrl.create({
            message: "Session has been expired",
            duration: 3000,
            position: 'top'
          });
          toast.present();

          this.storage.clear();
          this.navCtrl.setRoot('LoginPage');
        })
    });
  }

  ionViewDidLoad() {

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  getStudent()
  {

     if(this.year && this.month && this.staff)
     {
       
       this.navCtrl.push('AdminIndivisualStaffAttendencePage',{'year':this.year , 'month':this.month , 'staff':this.staff});
     }
     else
     {
        let msg='';
        
        if(this.year == undefined || this.year == '')
        {
          msg='Please Select year Field';
          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();

          return false;
        }

        if(this.month == undefined || this.month == '')
        {
          msg='Please Select month Field';

          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();
          return false;
        }

        if(this.staff == undefined || this.staff == '')
        {
          msg='Please Select staff Field';

          let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'top'
          });
          toast.present();

          return false;
        }

        
     }

  }

}