import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminAddDriverPage } from './admin-add-driver';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AdminAddDriverPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminAddDriverPage),
    MaterialModule
  ],
})
export class AdminAddDriverPageModule {}
