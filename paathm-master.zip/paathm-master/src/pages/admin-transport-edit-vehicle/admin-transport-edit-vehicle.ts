import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-transport-edit-vehicle',
  templateUrl: 'admin-transport-edit-vehicle.html',
})
export class AdminTransportEditVehiclePage {

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  class : FormGroup;

  name : any;
  type : any;
  make : any;
  model : any;
  manufactureYear :any;
  seats : any;
  editData : any;


  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.getDataEdit();
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.id = this.navParams.get('id');
 
     this.class = this.formBuilder.group({
              name: ['', Validators.required],
              type: ['', Validators.required],
              make : ['', Validators.required],
              model : ['', Validators.required],
              manufactureYear : ['', Validators.required],
              seats : ['', Validators.required],
            });

    this.name = this.class.controls['name'];
    this.type = this.class.controls['type'];
    this.make = this.class.controls['make'];
    
    this.model = this.class.controls['model'];
    this.manufactureYear = this.class.controls['manufactureYear'];

    this.seats = this.class.controls['seats'];

  }
  
  getDataEdit(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/EditTransportation_vehicles/"+this.id;

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;

               this.editData = this.res.Transportation_vehiclesDetails;

               this.class.patchValue({
                                      name : this.editData.vehicle_name,
                                      type : this.editData.vehicle_type ,
                                      make : this.editData.make,
                                      model : this.editData.model,
                                      manufactureYear : this.editData.manufacture_year,
                                      seats : this.editData.no_of_seats
                                     });
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPost(this.token.token,'v1/transports/SaveTransportation_vehicles/'+this.id, {"make":this.make.value,"model":this.model.value,"number_of_seats":this.seats.value,"vehicle_name":this.name.value,"vehicle_type":this.type.value,"year_of_manufacture": this.manufactureYear.value}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.closeModal();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminTransportPage');
  }

}

