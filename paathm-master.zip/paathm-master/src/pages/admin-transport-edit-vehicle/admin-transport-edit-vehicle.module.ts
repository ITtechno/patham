import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminTransportEditVehiclePage } from './admin-transport-edit-vehicle';

@NgModule({
  declarations: [
    AdminTransportEditVehiclePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminTransportEditVehiclePage),
  ],
})
export class AdminTransportEditVehiclePageModule {}
