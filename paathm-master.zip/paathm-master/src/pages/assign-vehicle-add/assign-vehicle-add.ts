import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-assign-vehicle-add',
  templateUrl: 'assign-vehicle-add.html',
})
export class AssignVehicleAddPage {

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  class : FormGroup;

  vehicle : any;
  driver : any;
  route : any;
  trip_date : any;

  driverList : any;
  vehicleList : any;
  routeList : any;


  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          


     this.class = this.formBuilder.group({
              vehicle : ['', Validators.required],
              driver: ['', Validators.required],
              route : ['', Validators.required],
              trip_date : ['', Validators.required]
            });

    this.vehicle = this.class.controls['vehicle'];
    this.driver = this.class.controls['driver'];
    this.route = this.class.controls['route'];    
    this.trip_date = this.class.controls['trip_date'];

  }

  ngOnInit(){
     this.getVehicles();
     this.getDrivers();
     this.getRoutes();
  }
  getVehicles(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="transports/listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.vehicleList = this.res.tpt_vehicles_detatils;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  getDrivers(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="driver/get-drivers/"+this.token.data.school_id;

		      this.user.getCallNode(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.driverList = this.res.result;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  getRoutes(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/tpt_routes_listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.routeList = this.res.tpt_routes_detatils;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPostNode(this.token.token,'assign-routes/assign', {"vehicle":this.vehicle.value,
                                                               "driver":this.driver.value,
                                                               "route":this.route.value,
                                                               "school_id" : this.token.data.school_id,
                                                               "user_id"   : this.token.data.id,
                                                               "trip_date":this.trip_date.value
                                                              }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AssignVehicleListPage');
  }

}

