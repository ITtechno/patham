import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AssignVehicleAddPage } from './assign-vehicle-add';

import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AssignVehicleAddPage,
  ],
  imports: [
    IonicPageModule.forChild(AssignVehicleAddPage),
    MaterialModule
  ],
})
export class AssignVehicleAddPageModule {}
