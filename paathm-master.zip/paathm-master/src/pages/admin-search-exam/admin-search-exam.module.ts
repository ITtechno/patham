import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSearchExamPage } from './admin-search-exam';

@NgModule({
  declarations: [
    AdminSearchExamPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSearchExamPage),
  ],
})
export class AdminSearchExamPageModule {}
