import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddNewClassPage } from './add-new-class';

@NgModule({
  declarations: [
    AddNewClassPage,
  ],
  imports: [
    IonicPageModule.forChild(AddNewClassPage),
  ],
})
export class AddNewClassPageModule {}
