import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMyInvoicesPage } from './admin-my-invoices';

@NgModule({
  declarations: [
    AdminMyInvoicesPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMyInvoicesPage),
  ],
})
export class AdminMyInvoicesPageModule {}
