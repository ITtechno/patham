import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers'

@IonicPage()
@Component({
  selector: 'page-admin-mark-sheet-filter',
  templateUrl: 'admin-mark-sheet-filter.html',
})
export class AdminMarkSheetFilterPage {
  token: any;
  res:any;

  response: any;

  class: any;

  exam: any;

  studentSuccess: any;

  from : any;
  to : any;

  language : any;
  
  lang : any = {'admin':'' , 'Reports':'','class':'','Expenses':'','examsList':'','Search':''};


	constructor( public navCtrl: NavController, public langs: LanguageProvider, public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
       
	}

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getPost(this.token.token,'reports',{stats: "marksheetGenerationPrepare", data: {status: "All"}}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                  this.class = this.res.classes;
                  this.exam  = this.res.exams; 

                 }
                 
              }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }
  
  searchData(){

      if(!this.from)
      {
        this.message("Please select class");
      }
      else if(!this.to){
         this.message("Please select date");
      }
      else
      {
        this.navCtrl.push('AdminMarkSheetreportPage', {"from":this.from , "to":this.to});
      }
  }


  message(msg : any){

              let toast = this.toastCtrl.create({
                message: msg,
                duration: 3000,
                position: 'top'
              });
              toast.present();
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

}
