import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMarkSheetFilterPage } from './admin-mark-sheet-filter';

@NgModule({
  declarations: [
    AdminMarkSheetFilterPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMarkSheetFilterPage),
  ],
})
export class AdminMarkSheetFilterPageModule {}
