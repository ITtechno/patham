import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-main-attandece',
  templateUrl: 'admin-main-attandece.html',
})
export class AdminMainAttandecePage {
  
  language : any;
  lang : any  = {"Attendance":"" , "student":"" , "staff":""};

  token: any;

  constructor(public navCtrl: NavController, public storage:Storage, public langs : LanguageProvider, public navParams: NavParams) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

          this.storage.get('auth_user').then((val) => {
      
            this.token= val;
          });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminMainReportPage');
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com , {'token': this.token});

  }

}
