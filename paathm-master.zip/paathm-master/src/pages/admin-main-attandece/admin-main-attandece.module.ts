import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMainAttandecePage } from './admin-main-attandece';

@NgModule({
  declarations: [
    AdminMainAttandecePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMainAttandecePage),
  ],
})
export class AdminMainAttandecePageModule {}
