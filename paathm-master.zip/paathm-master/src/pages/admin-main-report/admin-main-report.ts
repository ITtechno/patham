import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-main-report',
  templateUrl: 'admin-main-report.html',
})
export class AdminMainReportPage {
  
  language : any;
  lang : any = {'admin':'' , 'report':''};

  constructor(public navCtrl: NavController, public langs : LanguageProvider, public navParams: NavParams) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminMainReportPage');
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com);

  }

}
