import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminMainReportPage } from './admin-main-report';

@NgModule({
  declarations: [
    AdminMainReportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminMainReportPage),
  ],
})
export class AdminMainReportPageModule {}
