import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdmineditSubjectPage } from './adminedit-subject';

@NgModule({
  declarations: [
    AdmineditSubjectPage,
  ],
  imports: [
    IonicPageModule.forChild(AdmineditSubjectPage),
  ],
})
export class AdmineditSubjectPageModule {}
