import { Component } from '@angular/core';

import { IonicPage, NavController,LoadingController, ToastController  } from 'ionic-angular';

import { Storage } from '@ionic/storage';
import { User } from '../../providers';

import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators
} from "@angular/forms";

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-change-email-address',
  templateUrl: 'change-email-address.html',
})
export class ChangeEmailAddressPage {
   
   registerForm : FormGroup;
   language : any;
  
   res: any;
   token: any;

   lang : any = {'chgEmailAddress':'','password':'','email':'','reemail':'','EmailAddress':'','chgPassword':''};
  
  constructor(public navCtrl: NavController, public storage:Storage,private _fb: FormBuilder, public langs:LanguageProvider, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

        this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

               console.log(this.lang);
          });
 
  }

  ngOnInit() {

    this.registerForm = this._fb.group({
      password: ["", [Validators.required]],
      email: ["", [Validators.required]],
      confirm_email: ["", [Validators.required]]
    });

  }
  
  /*getter for email*/
  get password(): FormControl {
    return <FormControl>this.registerForm.get("password");
  }

   /*getter for email*/
  get email(): FormControl {
    return <FormControl>this.registerForm.get("email");
  }

   /*getter for email*/
  get confirm_email(): FormControl {
    return <FormControl>this.registerForm.get("confirm_email");
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminstudentMainPage');
  }
  

  changePassword(){
     
          
     console.log(this.registerForm.value);

           console.log(this.language);
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'accountSettings/email',{reemail: this.registerForm.value.confirm_email, password: this.registerForm.value.password, email: this.registerForm.value.email}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                    
                    let toast = this.toastCtrl.create({
                      message: this.res.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();
                    
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 
  }


  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push(com);

  }

}