import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangeEmailAddressPage } from './change-email-address';

@NgModule({
  declarations: [
    ChangeEmailAddressPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangeEmailAddressPage),
  ],
})
export class ChangeEmailAddressPageModule {}
