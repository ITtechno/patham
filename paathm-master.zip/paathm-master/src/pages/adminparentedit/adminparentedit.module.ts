import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminparenteditPage } from './adminparentedit';

@NgModule({
  declarations: [
    AdminparenteditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminparenteditPage),
  ],
})
export class AdminparenteditPageModule {}
