import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminreportPage } from './adminreport';

@NgModule({
  declarations: [
    AdminreportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminreportPage),
  ],
})
export class AdminreportPageModule {}
