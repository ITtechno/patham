import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminBookSyllbusListPage } from './admin-book-syllbus-list';
import { MaterialModule } from '../material.module';
@NgModule({
  declarations: [
    AdminBookSyllbusListPage,
  ],
  imports: [
    MaterialModule,
    IonicPageModule.forChild(AdminBookSyllbusListPage),
  ],
})
export class AdminBookSyllbusListPageModule {}
