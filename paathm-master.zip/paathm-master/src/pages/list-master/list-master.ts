import { Component } from '@angular/core';
import { IonicPage, ModalController, ActionSheetController, NavController , Events , MenuController, ToastController  } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { File } from '@ionic-native/file';

import { User } from '../../providers';

import { LanguageProvider } from '../../providers';

import { SocialSharing } from '@ionic-native/social-sharing';

@IonicPage()
@Component({
  selector: 'page-list-master',
  templateUrl: 'list-master.html'
})
export class ListMasterPage {

  record:any;
  name :any;
  school:any;
  username :any;
  resData :any;
  download_path :any;
  iterateArray :any;
  branch_name :any;
  img_src: any;
  classesd: any;

  role: any;

  study: any;
  token: any;

  success: any;

  dashboardData: any;

  language: any ;
  
  roledata : any;
  
  text = 'Download App :';
  url = 'https://play.google.com/store/apps/details?id=com.paatham.app';

  textIsta = 'Download App : https://play.google.com/store/apps/details?id=com.paatham.app';
   
  lang: any= {"Notification":"","events":"","NewsEvents":"","Administration":"","Attendance":"","Calender":"","Messages":"","classes":"","Study_material":"","Peoples":"","Reports":"","Transportation":""};

  constructor(public actionsheetCtrl: ActionSheetController, private file: File, private socialSharing: SocialSharing, public navCtrl: NavController, public langs: LanguageProvider, public menuCtrl: MenuController , public events: Events, public menu:MenuController, public toastCtrl: ToastController , public user: User , private storage: Storage , public modalCtrl: ModalController) {
             
             this.langs.language().then( res => {

                       this.language = res;
                       
                       if(this.language){
                         if(this.language.dashRecord){
                            
                            if(this.language.dashRecord.language){   
                              this.lang = this.language.dashRecord.language;
                            }
                         }
                       }

             });

  }

  /**
   * The view loaded, let's query our items for the list
   */
  ionViewDidLoad() {
  }

  ionViewDidEnter() {
    //to disable menu, or
    this.menu.enable(true);
  }

  ngOnInit()
  {    
      this.storage.get('auth_user').then((val) => {
        
                this.record = val;
                if(this.record){

                  this.dashboardData = {data:this.record.data ,classesd:this.record.classesd, token: this.record.token , school :this.record.school };

                  this.events.publish('user:created', this.dashboardData , Date.now());

                  console.log(this.record);
                  if(this.record){
                    this.roledata = (this.record.data.role).toUpperCase();
                    this.role = this.record.data.role;
                    this.name = this.record.data.fullName;
                     
                    console.log(this.role);

                    if(this.record.data.photo == null)
                    {
                       this.img_src = "assets/imgs/profile.jpg";
                    }
                    else {
                       
                       //this.img_src = "assets/imgs/profile.jpg";
                       this.img_src = "https://www.paatham.in/lms/index.php/dashboard/profileImage/"+this.record.data.id+'?nocache='+ new Date();
                    }
                    this.school = this.record.school[0].school_name;
                  }

                  this.loadDashboardData();

              }    
      });

  }

  OpenPage(comp){
     this.storage.get('auth_user').then((val) => {

          this.token = val;
          this.classesd = this.token.classesd;
          this.navCtrl.push(comp , {token: this.token , classesd:this.classesd });
      }); 
  }

 toggleMenu() {
  console.log('test');
   this.menuCtrl.toggle();
 }

  loadDashboardData(){

          let url = "dashboard";
          this.user.getCall(this.record.token , url).subscribe((resp) => {
            

            if(resp){

               this.success = resp;
               this.dashboardData.dashRecord = this.success;
               
               this.lang = this.dashboardData.dashRecord.language;
               
               this.events.publish('lang:selected', this.dashboardData.dashRecord.languageUniversal, Date.now());

               this.storage.set("auth_user", this.dashboardData);
               

            }

          }, (err) => {
            
            console.log(err);

            this.storage.clear();
            this.navCtrl.setRoot('LoginPage');
          })
  }

  shareSocial() {

    console.log('test');

    let actionSheet = this.actionsheetCtrl.create({
      title: 'Share Via',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Whatsapp',
          role: 'destructive',
          icon: 'logo-whatsapp',
          handler: () => {
            this.shareWhatsApp();
          }
        },
        {
          text: 'Email',
          icon: 'ios-mail',
          handler: () => {
            this.shareEmail();
          }
        },
        {
          text: 'Instagram',
          icon: 'logo-instagram',
          handler: () => {
            this.shareInstagram();
          }
        },
        {
          text: 'Facebook',
          icon: 'logo-facebook',
          handler: () => {
            this.shareFacebook();
          }
        },
      ]
    });
    actionSheet.present();
  }


  async shareTwitter() {
    // Either URL or Image
    this.socialSharing.shareViaTwitter(null, null, this.url).then(() => {
      // Success
    }).catch((e) => {
      // Error!
    });
  }

  async shareInstagram() {
    // Either URL or Image
    this.socialSharing.shareViaInstagram(this.textIsta, null).then(() => {
      // Success
    }).catch((e) => {
      // Error!
    });
  }
 
  async shareWhatsApp() {
    // Text + Image or URL works
    this.socialSharing.shareViaWhatsApp(this.textIsta, null, this.url).then(() => {
      // Success
    }).catch((e) => {
      // Error!
    });
  }
 
  async resolveLocalFile() {
    return this.file.copyFile(`${this.file.applicationDirectory}www/assets/imgs/`, 'paatham.png', this.file.cacheDirectory, `${new Date().getTime()}.jpg`);
  }
 
  removeTempFile(name) {
    this.file.removeFile(this.file.cacheDirectory, name);
  }
 
  async shareEmail() {
    let file = await this.resolveLocalFile();
 
    this.socialSharing.shareViaEmail(this.textIsta, 'Download Invitation', ['paatham@gmail.com'], null, null, file.nativeURL).then(() => {
      this.removeTempFile(file.name);
    }).catch((e) => {
      // Error!
    });
  }
 
  async shareFacebook() {
    let file = await this.resolveLocalFile();
 
    // Image or URL works
    this.socialSharing.shareViaFacebook(this.textIsta, file.nativeURL, null).then(() => {
      this.removeTempFile(file.name);
    }).catch((e) => {
      // Error!
    });
  }


}
