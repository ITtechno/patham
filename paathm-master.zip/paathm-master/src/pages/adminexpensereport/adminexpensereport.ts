import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';
import { DatePipe } from '@angular/common';


import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminexpensereport',
  templateUrl: 'adminexpensereport.html',
})
export class AdminexpensereportPage {
  token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  from : any;
  to : any;

  language : any;

  count = 0;
  
  lang : any = {'ip':'','listTeachers':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


	constructor(public datepipe:DatePipe, public langs : LanguageProvider, public navCtrl: NavController,public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
         
          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

         this.from = this.navParams.get("from");
         this.to   = this.navParams.get("to");
	}

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getPost(this.token.token,'reports',{stats: "expenses" , "data":{"fromDate":this.datepipe.transform(this.from, 'dd/MM/yyyy') ,"status":"All", "toDate":this.datepipe.transform(this.to, 'dd/MM/yyyy')}
}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                  this.response = this.res;

                  this.count = this.response.length;

                 }
                 
              }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  }