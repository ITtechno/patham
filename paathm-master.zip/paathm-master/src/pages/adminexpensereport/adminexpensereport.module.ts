import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminexpensereportPage } from './adminexpensereport';

@NgModule({
  declarations: [
    AdminexpensereportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminexpensereportPage),
  ],
})
export class AdminexpensereportPageModule {}
