import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminmainmessagePage } from './adminmainmessage';

@NgModule({
  declarations: [
    AdminmainmessagePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminmainmessagePage),
  ],
})
export class AdminmainmessagePageModule {}
