import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminListEbookPage } from './admin-list-ebook';

@NgModule({
  declarations: [
    AdminListEbookPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminListEbookPage),
  ],
})
export class AdminListEbookPageModule {}
