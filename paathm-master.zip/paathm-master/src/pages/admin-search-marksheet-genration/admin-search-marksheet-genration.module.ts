import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSearchMarksheetGenrationPage } from './admin-search-marksheet-genration';

@NgModule({
  declarations: [
    AdminSearchMarksheetGenrationPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSearchMarksheetGenrationPage),
  ],
})
export class AdminSearchMarksheetGenrationPageModule {}
