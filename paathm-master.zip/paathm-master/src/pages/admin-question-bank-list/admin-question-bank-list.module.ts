import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminQuestionBankListPage } from './admin-question-bank-list';

@NgModule({
  declarations: [
    AdminQuestionBankListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminQuestionBankListPage),
  ],
})
export class AdminQuestionBankListPageModule {}
