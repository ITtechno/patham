import { Component } from '@angular/core';
import { IonicPage, AlertController , ActionSheetController,PopoverController, NavController, NavParams,LoadingController , ModalController, ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-question-bank-list',
  templateUrl: 'admin-question-bank-list.html',
})
export class AdminQuestionBankListPage {
  inputData: any;
  token: any;
  res: any;
  
  language : any;

  teacherList: any = [];

  subjects: any;

  class : any;
  subject : any;
  board_type : any;
  board_name : any;
  course_from : any;
  class_name : any;
  section_name : any;

  count = 0;
  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};
  
  year : any;
  stuId : any;
  
  org = ['','Paatham','Organisation']
  constructor( private alertCtrl: AlertController , public navCtrl: NavController,public modalCtrl: ModalController, public actionSheetCtrl: ActionSheetController,public popoverCtrl: PopoverController, public langs : LanguageProvider , private storage: Storage,  public loadingCtrl: LoadingController, public user: User, public toastCtrl: ToastController , public navParams: NavParams) {

      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
    this.class = navParams.get('classes');
    this.subject = navParams.get('subject');
    this.course_from = navParams.get('course_from');
  }

  ionViewDidLoad() {
     this.getMarksheet();
  }

  getStudent()
  {

     if(this.year)
     {
        this.getMarksheet();
     }
     else
     {
        let msg='';
        
        if(this.year  == undefined )
        {
          msg='Please Select year Field';
        }
               

        let toast = this.toastCtrl.create({
          message: msg,
          duration: 3000,
          position: 'top'
        });
        toast.present();
     }

  }


  getMarksheet(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/qsbank/listAll/1";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

                   this.subjects = this.res.allQuestionBanks;
                                      
                   this.count = this.subjects.length;
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }
  
  teacherS(teacher: any){
  
    let teacherName = JSON.parse(teacher);
    let teachers='N/A';

    if(teacherName.length > 0){
      for (let name in teacherName) {  
        for (let key in this.teacherList) { 
          if(teacherName[name] == this.teacherList[key].id) { 
            teachers = this.teacherList[key].name.fullName;
          }
        }
      }
    }

    return teachers;

  }
  
  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Show Marks',
          role: 'show_marks',
          handler: () => {
            
          }
        },
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
}

  deleteSubject(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/assignments/delete/"+this.stuId;

		      this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;
               
              if(this.res.status == 'success'){

                    let toast = this.toastCtrl.create({
                  message: this.res.message,
                  duration: 3000,
                  position: 'top'
                });
                toast.present();

                this.reloadPreviousPage();

              }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });

  }
  
  reloadPreviousPage(){

    this.navCtrl.push('AdminAssignMentListPage');
  }

  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteSubject(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  AddNewSubject(){
     let profileModal = this.modalCtrl.create('AdminAssignMentAddPage' , {'data':this.res});
     profileModal.present();
  }


}



