import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddAdminSubjectPage } from './add-admin-subject';
import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AddAdminSubjectPage,

  ],
  imports: [
    MaterialModule,
    IonicPageModule.forChild(AddAdminSubjectPage),
  ],
})
export class AddAdminSubjectPageModule {}
