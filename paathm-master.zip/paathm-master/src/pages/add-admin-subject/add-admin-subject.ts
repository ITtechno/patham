import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-add-admin-subject',
  templateUrl: 'add-admin-subject.html',
})
export class AddAdminSubjectPage {
 
  className : any;
  class: FormGroup;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  language : any;
  
  lang : any = {'user':''};
  section : any;

  classes : any;

  teacher: any;
  teacherList: any =[];

  teacherName : any;

  sectionName : any;
  sectionTitle : any;
  subjectName : any;

  sectionList : any;

  passGrade : any;

  finalGrade : any;

  data : any;

  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.section = this.navParams.get('data');

     console.log(this.section);

     this.classes = this.section.classes;
     this.teacher = this.section.teachers;


     for (let key in this.teacher) {      
      this.teacherList.push({"id":key , "value":this.teacher[key].fullName});

     }

     this.class = this.formBuilder.group({
              className: ['', Validators.required],
              teacherName: ['', Validators.required],
              sectionName: ['', Validators.required],
              sectionTitle: ['', Validators.required],
              subjectName : ['', Validators.required],
              passGrade : ['', Validators.required],
              finalGrade : ['', Validators.required],
            });

    this.className = this.class.controls['className'];
    this.teacherName = this.class.controls['teacherName'];

    this.sectionName = this.class.controls['sectionName'];
    this.sectionTitle = this.class.controls['sectionTitle'];
    this.subjectName = this.class.controls['subjectName'];

    this.passGrade = this.class.controls['passGrade'];

    this.finalGrade = this.class.controls['finalGrade'];

  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'subjects' , {class_id: this.className.value , finalGrade: this.finalGrade.value , passGrade : this.passGrade.value , section_id : this.sectionName.value , subjectTitle : this.sectionTitle.value , teacherId : this.teacherName.value}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  getSection(){
           
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          this.user.getCall(this.token.token,'subjects/sections/'+this.className.value).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){
                 this.sectionList = resp;                
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });
  }

  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminSubjectsPage');
  }

}


