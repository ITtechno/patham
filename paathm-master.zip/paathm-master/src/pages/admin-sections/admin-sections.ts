import { Component} from '@angular/core';
import { AlertController, ModalController , IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-sections',
  templateUrl: 'admin-sections.html',
})
export class AdminSectionsPage {
  token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  language : any;
  
  teacherList:any =[];
  
  stuId : any;

  respn : any =[];

  lang : any = {'sec':'','Year':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

	constructor(private alertCtrl: AlertController ,  public modalCtrl: ModalController, public navCtrl: NavController, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
      
      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });
	}

  ionViewDidLoad() {
    
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getCall(this.token.token,'sections/listAll').subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   

                    this.response = this.res.sections;
                   
                    for (let key in this.response) {
                      
		              this.respn.push({'sections':this.response[key],'classs':key});

		            }

                    let teacherlist = this.res.teachers;

		            for (let key in teacherlist) {
                      
		              this.teacherList.push({ 'name':teacherlist[key] , 'id':key});

		            }

		            console.log(this.teacherList);
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }
  
  teacherS(teacher: any){

  	let teacherName = '';
    for (let key in this.teacherList) {
        
        if(teacher == this.teacherList[key].id) {       
            teacherName = this.teacherList[key].name;
        }
    }

    return teacherName;

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteClass(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }
  
  deleteClass(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getPost(this.token.token,'sections/delete/'+id, { }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status){
                  let toast = this.toastCtrl.create({
                    message: this.res.message,
                    duration: 3000,
                    position: 'top'
                  });
                  toast.present();
                   
                  this.navCtrl.pop();
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  AddNewSections(){
     let profileModal = this.modalCtrl.create('AddAdminSectionPage' , {"section" : this.res });
     profileModal.present();
  }

  editSections(id : any){
    let profileModal = this.modalCtrl.create('AdmineditSectionPage' , {"section" : this.res , "id" : id });
    profileModal.present();
 }


}