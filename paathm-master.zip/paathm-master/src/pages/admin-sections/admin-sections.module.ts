import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminSectionsPage } from './admin-sections';

@NgModule({
  declarations: [
    AdminSectionsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminSectionsPage),
  ],
})
export class AdminSectionsPageModule {}
