import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FeeGroupsPage } from './fee-groups';

@NgModule({
  declarations: [
    FeeGroupsPage,
  ],
  imports: [
    IonicPageModule.forChild(FeeGroupsPage),
  ],
})
export class FeeGroupsPageModule {}
