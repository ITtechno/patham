import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudyMainPage } from './admin-study-main';

@NgModule({
  declarations: [
    AdminStudyMainPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudyMainPage),
  ],
})
export class AdminStudyMainPageModule {}
