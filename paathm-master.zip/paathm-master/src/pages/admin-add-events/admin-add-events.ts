import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

import { LanguageProvider } from '../../providers';
import moment from 'moment';

@IonicPage()
@Component({
  selector: 'page-admin-add-events',
  templateUrl: 'admin-add-events.html',
})
export class AdminAddEventsPage {

  className : any;
  class: FormGroup;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  newsTitle : any;
  newsContent : any;
  for : any;
  date : any;
  eventPlace : any;

  language : any;
  
  lang : any = {'user':''};

  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          

     this.class = this.formBuilder.group({
              newsTitle: ['', Validators.required],
              newsContent: ['', Validators.required],
              for: ['', Validators.required],
              eventPlace : [],
              date: ['', Validators.required],

            });

    this.newsTitle = this.class.controls['newsTitle'];
    this.newsContent = this.class.controls['newsContent'];
    this.for = this.class.controls['for'];
    this.date = this.class.controls['date'];
    this.eventPlace = this.class.controls['eventPlace'];

  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'events' ,{enentPlace: this.eventPlace.value ,eventTitle: this.newsTitle.value, eventDescription: this.newsContent.value, eventFor: this.for.value, eventDate: moment(this.date.value).format('DD/MM/YYYY')}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminEventsPage');
  }

}

