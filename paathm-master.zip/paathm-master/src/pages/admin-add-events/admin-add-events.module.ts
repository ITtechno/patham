import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminAddEventsPage } from './admin-add-events';

@NgModule({
  declarations: [
    AdminAddEventsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminAddEventsPage),
  ],
})
export class AdminAddEventsPageModule {}
