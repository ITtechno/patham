import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminclassPage } from './adminclass';

@NgModule({
  declarations: [
    AdminclassPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminclassPage),
  ],
})
export class AdminclassPageModule {}
