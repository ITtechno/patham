import { Component} from '@angular/core';
import { IonicPage, AlertController,  NavController,LoadingController,ModalController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminclass',
  templateUrl: 'adminclass.html',
})
export class AdminclassPage {
  token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  language : any;

  stuId : any;

  lang : any = {'sec':'','Year':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

	constructor(private alertCtrl: AlertController , public navCtrl: NavController,public modalCtrl: ModalController, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
      
      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });
	}

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getCall(this.token.token,'classes/listAll/0').subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   
                   this.response = this.res.classes;
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  AddNewClass(){
     let profileModal = this.modalCtrl.create('AddNewClassPage');
     profileModal.present();
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteClass(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }
  
  deleteClass(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getPost(this.token.token,'classes/delete/'+id, { }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status){
                  let toast = this.toastCtrl.create({
                    message: this.res.message,
                    duration: 3000,
                    position: 'top'
                  });
                  toast.present();
                   
                  this.navCtrl.pop();
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  classEdit(id : any , name : any){
    let profileModal = this.modalCtrl.create('AdminEditClassPage' , {"id" : id , "name": name});
    profileModal.present();
  }

}