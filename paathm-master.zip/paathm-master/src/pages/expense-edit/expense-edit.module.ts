import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpenseEditPage } from './expense-edit';

@NgModule({
  declarations: [
    ExpenseEditPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpenseEditPage),
  ],
})
export class ExpenseEditPageModule {}
