import { Component , ViewChild } from '@angular/core';
import { IonicPage,Platform, NavController,ActionSheetController, Events , NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';
import { DatePipe } from '@angular/common';
import { DatePicker } from '@ionic-native/date-picker';
import { Camera } from '@ionic-native/camera';
import { LanguageProvider } from '../../providers';
import { ImagePicker } from '@ionic-native/image-picker';
import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import * as moment from 'moment';

@IonicPage()
@Component({
  selector: 'page-expense-edit',
  templateUrl: 'expense-edit.html',
})
export class ExpenseEditPage {
 
  @ViewChild('fileInput') fileInput;

  inputData: any;
  token: any ;
  res: any ;
  
   
  urlImage: any; 

  imageData: any;

  photosUpload: any;

  className : any;
  class: FormGroup;

  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  language : any;
  
  lang : any = {'user':''};
  section : any;

  classes : any;

  teacherList: any =[];

  expenseTitle : any;
  expenseAmount : any;

  expenseDate : any;

  expenseCategory : any;
  expenseNotes : any;
  expenseImage: any;

  data : any;

  success : any;

  category : any = [];

  constructor(private imagePicker: ImagePicker, public platform :Platform ,public actionsheetCtrl: ActionSheetController,public camera: Camera, public datepipe: DatePipe, public events:Events,private datePicker: DatePicker, public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.section = this.navParams.get('data');
     
     this.id = this.navParams.get('id');

     this.section = this.section.expenses_cat;

     for (let key in this.section) {
                      
        this.category.push({'value':this.section[key],'id':key});

     }

     this.class = this.formBuilder.group({
              expenseTitle: ['', Validators.required],
              expenseAmount: ['', Validators.required],
              expenseDate: ['', Validators.required],
              expenseCategory: ['', Validators.required],
              expenseNotes: [''],
              expenseImage: [''],
            });

    this.expenseTitle     = this.class.controls['expenseTitle'];
    this.expenseAmount    = this.class.controls['expenseAmount'];
    this.expenseDate      = this.class.controls['expenseDate'];
    this.expenseCategory  = this.class.controls['expenseCategory'];
    this.expenseNotes     = this.class.controls['expenseNotes'];
    this.expenseImage     = this.class.controls['expenseImage'];

    this.getExpense();

  }

  getExpense(){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    let url="v1/expenses/"+this.id;
    this.storage.get('auth_user').then((val) => {
       
        this.token = val;
  
       this.user.getCall(this.token.token , url).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){
  
                 this.res = resp;
                 
                 this.class.patchValue({
                  expenseTitle : this.res.expenseTitle,
                  expenseAmount : this.res.expenseAmount,
                  expenseCategory : this.res.expenseCategory,
                  expenseDate     : this.res.expenseDate,
                  expenseNotes    : this.res.expenseNotes
                 });
              }
            }, (err) => {
  
              loading.dismiss(); 
  
              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();
  
                  //this.storage.clear();
                  //this.navCtrl.setRoot('LoginPage');
            });
            
       });
  }



  urls = new Array<string>();

  changeListener(event) {
    this.photosUpload = event.target.files[0];
   }

  showDate()
  {
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
    }).then(
      date => {
         this.class.patchValue({ expenseDate : this.datepipe.transform(date, 'dd/MM/yyyy')  });
         },
      err => console.log('Error occurred while getting date: ', err)
    );
  }

  pickImage(){
     
     let options = {
          // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
          maximumImagesCount: 1,
          title: 'Select Picture',
          message: 'Profile Picture', // optional default no helper message above the picker UI
          // be careful with these options as they require additional processing
          width: 400,
          quality: 80,
          outputType:1
          //             outputType: imagePicker.OutputType.BASE64_STRING
        }

     this.imagePicker.getPictures(options).then((results) => {
        
      this.expenseImage = 'data:image/jpg;base64,' + results;
            
            this.urlImage = this.dataURItoBlob(this.expenseImage)

      }, (err) => { });

  }

  dataURItoBlob(dataURI) {
    var binary = atob(dataURI.split(',')[1]);
    var array = [];
    for (var i = 0; i < binary.length; i++) {
       array.push(binary.charCodeAt(i));
    }
    return new Blob([new Uint8Array(array)], {
      type: 'image/jpg'
    });
  }

  getPicture() {
    if (Camera['installed']()) {
      this.camera.getPicture({
        destinationType: this.camera.DestinationType.DATA_URL,
        targetWidth: 96,
        targetHeight: 96
      }).then((data) => {
        this.expenseImage = 'data:image/jpg;base64,' + data ;
        
        this.urlImage = this.dataURItoBlob(this.expenseImage)

      }, (err) => {
        //alert('Unable to take photo');
      })
    } else {
      this.fileInput.nativeElement.click();
    }
  }

  processWebImage(event) {

    let reader = new FileReader();
    reader.onload = (readerEvent) => {

      let imageData = (readerEvent.target as any).result;
      this.expenseImage= imageData;
    };
    
    this.urlImage = event.target.files[0];

    console.log(this.urlImage)
    reader.readAsDataURL(event.target.files[0]);
  }

  getProfileImageStyle() {
    return 'url(' + this.expenseImage + ')'
  }
  
  openeditprofile() {
    let actionSheet = this.actionsheetCtrl.create({
      title: 'Option',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Take photo',
          role: 'destructive',
          icon: !this.platform.is('ios') ? 'ios-camera-outline' : null,
          handler: () => {
            this.getPicture();
          }
        },
        {
          text: 'Choose photo from Gallery',
          icon: !this.platform.is('ios') ? 'ios-images-outline' : null,
          handler: () => {
            this.pickImage();
          }
        },
      ]
    });
    actionSheet.present();
  }

  saveExpense(event: any)
  {
  	 let loading = this.loadingCtrl.create({content:'Please Wait..'});
     loading.present(loading);
     
     //let parts =this.response.birthday.split('/');

     let fd = new FormData();
     fd.append('expenseTitle', this.expenseTitle.value);
     fd.append('expenseAmount', this.expenseAmount.value);
     fd.append('expenseDate', moment(this.expenseDate.value).format('DD/MM/YYYY'));
     fd.append('expenseCategory', this.expenseCategory.value);
     fd.append('expenseNotes', this.expenseNotes.value);
     fd.append('expenseImage', this.expenseImage);
  	 
  	 let url="expenses/"+this.id;
  this.storage.get('auth_user').then((val) => {
     
      this.token = val;

  	 this.user.getPostMulti(this.token.token , url , fd).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.success = resp;
                
               if(this.success.status == 'success'){

                    let toast = this.toastCtrl.create({
                      message: this.success.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

                    this.navCtrl.pop();

                }
            }
		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            //this.storage.clear();
		            //this.navCtrl.setRoot('LoginPage');
          });
          
     });
  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('ExpensesCategoriesPage');
  }

}


