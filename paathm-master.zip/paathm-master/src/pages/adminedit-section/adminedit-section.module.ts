import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdmineditSectionPage } from './adminedit-section';

@NgModule({
  declarations: [
    AdmineditSectionPage,
  ],
  imports: [
    IonicPageModule.forChild(AdmineditSectionPage),
  ],
})
export class AdmineditSectionPageModule {}
