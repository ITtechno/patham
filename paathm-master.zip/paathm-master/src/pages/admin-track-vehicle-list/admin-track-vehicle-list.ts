import { Component , ViewChild, ElementRef ,AfterViewInit, OnDestroy } from '@angular/core';
import { IonicPage, NavController , NavParams} from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';
import { Subscription } from 'rxjs/Subscription';
import { filter } from 'rxjs/operators';
import { Storage } from '@ionic/storage';

import { Diagnostic } from '@ionic-native/diagnostic';
import uuid from 'uuid/v1';

import { LocationServiceProvider } from '../../providers/location-service/location-service';
import { NotificationProvider } from '../../providers/notification/notification';


import { SocketService } from './../../providers';
declare const google;

@IonicPage()
@Component({
  selector: 'page-admin-track-vehicle-list',
  templateUrl: 'admin-track-vehicle-list.html',
})
export class AdminTrackVehicleListPage  implements AfterViewInit, OnDestroy {

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  currentMapTrack = null;
  
  data : any = 'test';
  data1 : any='test1';

  isTracking = false;
  trackedRoute = [];
  previousTracks = [];
  markers = [];
  positionSubscription: Subscription;

   mark : any;

  locationDenied = false;
  locationWatcher: any;
  sessionId: string;
  lastLocation = { position: {latitude:0,longitude:0}};
  tracking = false;

  driver: any;
  markerArray : any= [];

  directionsDisplay : any;
  directionsService : any;

  stepDisplay : any;

  image_url : String = 'assets/imgs/navi.png';

  trackingObject : any;

  startPoint : any;
  endPoint : any;
  pointS : any = 0;
  waypoints : any = [];

  serviceSub : any;
 
  constructor(  private navCtrl: NavController,
    private navPrams : NavParams,
    private diagnostic: Diagnostic,
    private location: LocationServiceProvider,
    private notification: NotificationProvider,
    public socketio: SocketService,
    private geolocation: Geolocation, 
    private storage: Storage) { 

        this.socketio.connect();
        this.trackingObject = this.navPrams.get('tracking');

        
    }
 
  ionViewDidLoad() {
    
    this.pointS = this.trackingObject.length;
    this.startPoint = { lat : parseFloat(this.trackingObject[0].latitude) , lng : parseFloat(this.trackingObject[0].longitude) };
    this.endPoint = { lat : parseFloat(this.trackingObject[this.pointS-1].latitude) , lng : parseFloat(this.trackingObject[this.pointS-1].longitude) };
    
    for(let i=0 ; i < (this.pointS -2) ; i++ ){
       if(this.trackingObject[i+1].stop_name != "" && this.trackingObject[i+1].stop_name != null){
        this.waypoints.push({
          location: (this.trackingObject[i+1].stop_name).trim(),
          stopover: true
        });
       }
    }


    console.log(this.waypoints);
    this.directionsDisplay = new google.maps.DirectionsRenderer;
    this.directionsService = new google.maps.DirectionsService;

    this.geolocation.getCurrentPosition({ maximumAge: 3000, timeout: 5000, enableHighAccuracy: true }).then((resp) => {
      let mylocation = new google.maps.LatLng(resp.coords.latitude,resp.coords.longitude);
      this.map = new google.maps.Map(this.mapElement.nativeElement, {
        zoom: 20,
        center: mylocation
      });

      this.directionsDisplay = new google.maps.DirectionsRenderer({map: this.map});

      this.stepDisplay = new google.maps.InfoWindow;

      this.calculateAndDisplayRoute( this.directionsDisplay , this.directionsService ,this.markerArray, this.stepDisplay , this.map);
    
      //this.calculateAndDisplayRouteAnother( this.directionsDisplay , this.directionsService ,this.markerArray, this.stepDisplay , this.map);
    
    });
     
    setTimeout(()=>{ 
     this.trackVehicle()
    }, 2000); 
  }

  async trackVehicle(){
    
      this.serviceSub = this.socketio.trackLocation().subscribe((res : any) => {
        console.log('data', JSON.parse(res));
        let resp = JSON.parse(res);
        let mylocation = new google.maps.LatLng(resp.position.latitude,resp.position.longitude);
        // this.map = new google.maps.Map(this.mapElement.nativeElement, {
        //     zoom: 17,
        //     center: mylocation
        //   });

         if(!this.mark){
           let image = 'assets/imgs/navi.png';
           this.addMarker(mylocation , image);
           this.map.setZoom(15);
         }
        

        this.mark.setPosition(mylocation);
        
        // this.socketio.updateLocation(pos);
      })
          
  }

  async calculateAndDisplayRoute(directionsDisplay, directionsService,
    markerArray, stepDisplay, map) {
  // First, remove any existing markers from the map.
  for (var i = 0; i < markerArray.length; i++) {
    markerArray[i].setMap(null);
  }

  // Retrieve the start and end locations and create a DirectionsRequest using
  // WALKING directions.
  directionsService.route({
    origin: this.startPoint,  // Haight.
    destination: this.endPoint, 
    waypoints: this.waypoints,
    provideRouteAlternatives: true,
    travelMode: 'DRIVING',
    transitOptions: {
      departureTime: new Date(1337675679473),
      modes: ['BUS'],
      routingPreference: 'FEWER_TRANSFERS'
    },
    drivingOptions: {
      departureTime: new Date(/* now, or future date */),
      trafficModel: 'pessimistic'
    },
    unitSystem: google.maps.UnitSystem.IMPERIAL
  }, (response, status) => {
    // Route the directions and pass the response to a function to create
    // markers for each step.
    if (status === 'OK') {
      // document.getElementById('warnings-panel').innerHTML =
      //     '<b>' + response.routes[0].warnings + '</b>';
      directionsDisplay.setDirections(response);
      //this.showSteps(response, markerArray, stepDisplay, map);
    } else {
      window.alert('Directions request failed due to ' + status);
    }
  });
}

async calculateAndDisplayRouteAnother(directionsDisplay, directionsService,
  markerArray, stepDisplay, map) {
// First, remove any existing markers from the map.
for (var i = 0; i < markerArray.length; i++) {
  markerArray[i].setMap(null);
}

// Retrieve the start and end locations and create a DirectionsRequest using
// WALKING directions.
directionsService.route({
  origin: {lat: 28.672149, lng: 77.411698},  // Haight.
  destination: {lat: 28.535517, lng: 77.391029}, 
  travelMode: 'DRIVING'
}, (response, status) => {
  // Route the directions and pass the response to a function to create
  // markers for each step.
  if (status === 'OK') {
    // document.getElementById('warnings-panel').innerHTML =
    //     '<b>' + response.routes[0].warnings + '</b>';
    directionsDisplay.setDirections(response);
    this.showSteps(response, markerArray, stepDisplay, map);
  } else {
    window.alert('Directions request failed due to ' + status);
  }
});
}

showSteps(directionResult, markerArray, stepDisplay, map) {
  // For each step, place a marker, and add the text to the marker's infowindow.
  // Also attach the marker to an array so we can keep track of it and remove it
  // when calculating new routes.
  var myRoute = directionResult.routes[0].legs[0];
  for (var i = 0; i < myRoute.steps.length; i++) {
    var marker = markerArray[i] = markerArray[i] || new google.maps.Marker;
    marker.setMap(map);
    marker.setPosition(myRoute.steps[i].start_location);
    this.attachInstructionText(
        stepDisplay, marker, myRoute.steps[i].instructions, map);
  }
}

attachInstructionText(stepDisplay, marker, text, map) {
  google.maps.event.addListener(marker, 'click', function() {
    // Open an info window when the marker is clicked on, containing the text
    // of the step.
    stepDisplay.setContent(text);
    stepDisplay.open(map, marker);
  });
}

  calculateAndDisplayRouteWithMode(directionsService, directionsDisplay) {
    let selectedMode = 'DRIVING';
    directionsService.route({
      origin: {lat: 28.535517, lng: 77.391029},  // Haight.
      destination: {lat: 28.704060, lng: 77.102493},  // Ocean Beach.
      // Note that Javascript allows us to access the constant
      // using square brackets and a string value as its
      // "property."
      travelMode: google.maps.TravelMode[selectedMode]
    }, function(response, status) {
      console.log(status);
      if (status == 'OK') {
        directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }
  
  async addMarker(location, image) {

    var icon = {
      url: image, // url
      scaledSize: new google.maps.Size(17, 17), // scaled size
      origin: new google.maps.Point(0,0), // origin
      anchor: new google.maps.Point(0, 0) // anchor
    };

    this.mark = new google.maps.Marker({
      position: location,
      map: this.map,
      draggable: true,
      icon: icon
    });

    this.map.setZoom(12);
    this.map.panTo(this.mark.position);
    //this.markers.push(marker);
  }
  
  setMapOnAll(map) {
    for (var i = 0; i < this.markers.length; i++) {
      this.markers[i].setMap(map);
    }
  }
  
  clearMarkers() {
    this.setMapOnAll(null);
  }
  
  deleteMarkers() {
    this.clearMarkers();
    this.markers = [];
  }

  loadHistoricRoutes() {
    this.storage.get('routes').then(data => {
      if (data) {
        this.previousTracks = data;
      }
    });
  }
  
  startTracking() {
      this.isTracking = true;
      this.trackedRoute = [];
      console.log('started');
      this.socketio.updateLocation('Started');
      

      this.positionSubscription = this.geolocation.watchPosition()
        .pipe(
          filter((p) => p.coords !== undefined) //Filter Out Errors
        )
        .subscribe(data => {
          this.data1 = JSON.stringify(data);
          this.socketio.updateLocation({ lat: data.coords.latitude, lng: data.coords.longitude });

          setTimeout(() => {
            
            this.trackedRoute.push({ lat: data.coords.latitude, lng: data.coords.longitude });
           
             console.log(data);
            this.redrawPath(this.trackedRoute);
          }, 0);
        });
   
    }
   
    redrawPath(path) {
      if (this.currentMapTrack) {
        this.currentMapTrack.setMap(null);
      }
   
      if (path.length > 1) {
        this.currentMapTrack = new google.maps.Polyline({
          path: path,
          geodesic: true,
          strokeColor: '#ff00ff',
          strokeOpacity: 1.0,
          strokeWeight: 3
        });
        this.currentMapTrack.setMap(this.map);
   }
  }

   stopTracking() {
    let newRoute = { finished: new Date().getTime(), path: this.trackedRoute };
    this.previousTracks.push(newRoute);
    this.storage.set('routes', this.previousTracks);
   
    this.isTracking = false;
    this.positionSubscription.unsubscribe();

  }
   
  showHistoryRoute(route) {
    this.redrawPath(route);
  }

  ngAfterViewInit() {
    this.diagnostic.registerLocationStateChangeHandler(() => {
      this.diagnostic.isLocationEnabled().then((locationEnabled) => {
        if (!locationEnabled) {
          this.notification.toast('You need to enable location to continue!');
          this.location.requestLocationService(
            () => this.locationDenied = true
          );
        }
      });
    });
  }

  async toggleTracking() {

    if (this.isTracking) {
      this.location.removeLocationWatcher(this.locationWatcher);
      this.socketio.trackLocation().unsubscribe();
      this.deleteMarkers();
      this.notification.toast('Tracking stopped!');
      this.isTracking = false;
      return;
    }

    this.sessionId = uuid();
    this.isTracking = true;
    // this.locationWatcher = this.location.registerLocationWatcher((location: Geoposition) => {
      
    //   // ignore if last location is same - later on update timestamp
    //   if (
    //     location.coords.latitude === this.lastLocation.position.latitude &&
    //     location.coords.longitude === this.lastLocation.position.longitude
    //   ) { return; }

    //   const pos = {
    //     latitude: location.coords.latitude,
    //     longitude: location.coords.longitude,
    //   };
      
    //   this.location
    //     .getPhysicalAddress(pos.latitude, pos.longitude)
    //     .then(address => {
    //       const locationEntry = {
    //         sessionId: this.sessionId,
    //         position: {
    //           latitude: location.coords.latitude,
    //           longitude: location.coords.longitude,
    //           physicalAddress: address,
    //         },
    //         driverPhone: 'this.driver.phone',
    //         timestamp: location.timestamp,
    //       };
          
    //         //let mylocation = new google.maps.LatLng(location.coords.latitude,location.coords.longitude);
    //         // this.map = new google.maps.Map(this.mapElement.nativeElement, {
    //         //   zoom: 17,
    //         //   center: mylocation
    //         // });

    //       // if(!this.mark){
    //       //   let image = 'assets/imgs/navi.png';
    //       //   this.addMarker(mylocation , image);
    //       // }
           
    //       // this.mark.setPosition(mylocation);
    //       // this.socketio.updateLocation(pos);
    //       // push entry to firebase
    //       // this.db.collection<LocationEntry>('locationHistory').add(locationEntry);
    //       // this.driverDocument.update({
    //       //   lastActive: locationEntry.timestamp,
    //       //   lastLocation: locationEntry.position,
    //       //   lastSessionId: this.sessionId,
    //       // });
    //       this.lastLocation = locationEntry;
    //     }).catch(error => {
    //       console.log(error);
    //     });

    // });
  }
  
  closeModal() {
    this.navCtrl.pop();
}

  ngOnDestroy() {
      //this.location.removeLocationWatcher(this.locationWatcher);
      this.serviceSub.unsubscribe();
      this.deleteMarkers();
      this.notification.toast('Tracking stopped!');
  }

}
