import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminTrackVehicleListPage } from './admin-track-vehicle-list';
import { SocketService } from './../../providers';

@NgModule({
  declarations: [
    AdminTrackVehicleListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminTrackVehicleListPage),
  ],
  providers:[
    SocketService
  ]
})
export class AdminTrackVehicleListPageModule {}
