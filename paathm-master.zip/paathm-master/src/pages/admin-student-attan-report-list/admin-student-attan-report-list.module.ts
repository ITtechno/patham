import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentAttanReportListPage } from './admin-student-attan-report-list';

@NgModule({
  declarations: [
    AdminStudentAttanReportListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentAttanReportListPage),
  ],
})
export class AdminStudentAttanReportListPageModule {}
