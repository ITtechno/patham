import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminRouteStopPointPage } from './admin-route-stop-point';

@NgModule({
  declarations: [
    AdminRouteStopPointPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminRouteStopPointPage),
  ],
})
export class AdminRouteStopPointPageModule {}
