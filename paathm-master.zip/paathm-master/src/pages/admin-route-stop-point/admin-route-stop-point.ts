import { Component } from '@angular/core';
import { IonicPage, NavController,ModalController, AlertController, ActionSheetController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

import { Events } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-admin-route-stop-point',
  templateUrl: 'admin-route-stop-point.html',
})
export class AdminRouteStopPointPage {

  inputData: any;
  token: any;
  res: any;
  
  id : any;

  language : any;

  result : any = [];
  
  status :any = ['N/A','Active','Inactive','Deleted']
  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  
  constructor(public navCtrl: NavController,
              public modalCtrl :ModalController, 
              public langs : LanguageProvider , 
              private storage: Storage, 
              public loadingCtrl: LoadingController, 
              public alertCtrl : AlertController,
              public user: User, 
              public events: Events,
              public actionSheetCtrl : ActionSheetController,
              public toastCtrl: ToastController , 
              public navParams: NavParams) {
      
                this.events.subscribe('reloadPage2',() => {
                  this.getData();
                 });

      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  getData(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/tpt_routes_points_listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
               if(this.res.tpt_routes_points_detatils){
                this.result = this.res.tpt_routes_points_detatils;
               }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  ionViewDidLoad() {
      this.getData();
  }

  AddNewClass(){
    let profileModal = this.modalCtrl.create('AdminRouteStopPointAddPage');
    profileModal.present();
  }

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.edit(id);
          }
        },
        {
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
  }
  
  edit(id){
    let profileModal = this.modalCtrl.create('AdminRouteStopPointEditPage' , {id : id});
    profileModal.present();
  }

  delete(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/removeTptRoutePoint/"+this.id.id+"/"+this.id.route_legs_id;

		      this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;
               
              if(this.res.status == 'success'){

                    let toast = this.toastCtrl.create({
                  message: this.res.message,
                  duration: 3000,
                  position: 'top'
                });
                toast.present();

                this.reloadPreviousPage();

              }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });

  }
  
  reloadPreviousPage(){

    this.navCtrl.push('AdminRouteStopPointPage');
  }

  deleteConfirm(id : any) {
    this.id = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.delete(this.id);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }


}

