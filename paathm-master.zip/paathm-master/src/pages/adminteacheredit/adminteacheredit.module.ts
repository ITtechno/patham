import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminteachereditPage } from './adminteacheredit';

@NgModule({
  declarations: [
    AdminteachereditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminteachereditPage),
  ],
})
export class AdminteachereditPageModule {}
