import { Component, ViewChild } from '@angular/core';
import { IonicPage, ActionSheetController , NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import { DatePicker } from '@ionic-native/date-picker';

import { Camera } from '@ionic-native/camera';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-adminteacheredit',
  templateUrl: 'adminteacheredit.html',
})
export class AdminteachereditPage {

 @ViewChild('fileInput') fileInput;

  token: any;
  res:any;
  students: any;

  approval: any;

  private student:FormGroup ;
  
  addres: any;
  fullName: any;
  studentRollId: any;
  email: any;
  username: any;
  phoneNo: any;
  mobileNo: any;
  studentClass: any;
  studentSection: any;

  transport: any;

  gender : any;
  birthday : any;

  classes: any;
  sections: any;

  transports: any;

  response: any;

  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  stuId: any; 

  urls: any;

  language : any;

  lang : any = {'sec':'','Year':'','EditTeacher':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(public datepipe: DatePipe,public langs : LanguageProvider , private datePicker: DatePicker, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder , public navCtrl: NavController,public viewCtrl: ViewController
, public camera: Camera, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
    

    this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
    this.stuId      = navParams.get('id');

    this.transports = navParams.get("transports");


    this.student = this.formBuilder.group({
              fullName: ['', Validators.required],
              email: ['', Validators.required],
              username: ['', Validators.required],
              addres : ['', Validators.required],
              gender  : ['', Validators.required],
              birthday: ['', ''],
              profilePic:['',''],
              mobileNo: ['', ''],
              phoneNo: ['', ''],
              transport: ['', ''],
            });

    this.fullName = this.student.controls['fullName'];
    this.addres = this.student.controls['addres'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.gender  = this.student.controls['gender'];
    this.birthday = this.student.controls['birthday'];
    this.transport = this.student.controls['transport'];
    this.mobileNo = this.student.controls['mobileNo'];
    this.phoneNo = this.student.controls['phoneNo'];
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getCall(this.token.token,'teachers/'+this.stuId).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   
                   let parts =this.res.birthday.split('/');
                   
                   
                   let birthday = this.datepipe.transform(new Date(parts[2] , parts[1] - 1 , parseInt(parts[0])), 'dd/MM/yyyy');

                   this.student.setValue({"fullName":this.res.fullName,"username":this.res.username,"profilePic":"","email":this.res.email,"phoneNo":this.res.phoneNo,"mobileNo":this.res.mobileNo,"transport":this.res.transport,"gender":this.res.gender,"birthday":birthday,"addres":this.res.address});
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 
  }

  getSection(){

      this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getAllSubjectToadd/"+this.studentClass.value;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            this.response = resp;

            if(resp){
               this.sections = this.response.sections;
            
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
    
  }
  
  showDate()
  {
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
    }).then(
      date => this.response.birthday = this.datepipe.transform(date, 'dd/MM/yyyy'),
      err => console.log('Error occurred while getting date: ', err)
    );
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  saveData()
  {

     let fd = new FormData();
     fd.append('username', this.username.value);
     fd.append('email', this.email.value);
     fd.append('fullName', this.fullName.value);
     fd.append('gender', this.gender.value);
     fd.append('birthday', this.birthday.value);
     fd.append('address', this.addres.value);
     fd.append('phoneNo', this.phoneNo.value);

     fd.append('mobileNo', this.mobileNo.value);
     fd.append('photo', this.urls );
     fd.append('transport', this.mobileNo.value);
      

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.getPostMulti(this.token.token,'teachers/'+this.stuId, fd).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
              
              let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){
                this.navCtrl.push('AdminTeacherPage');  
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })
  }


  getPicture() {
    if (Camera['installed']()) {
      this.camera.getPicture({
        destinationType: this.camera.DestinationType.DATA_URL,
        targetWidth: 96,
        targetHeight: 96
      }).then((data) => {
        this.student.patchValue({ 'profilePic': 'data:image/jpg;base64,' + data });
      }, (err) => {
        alert('Unable to take photo');
      })
    } else {
      this.fileInput.nativeElement.click();
    }
  }

  processWebImage(event) {
    let reader = new FileReader();
    reader.onload = (readerEvent) => {

      let imageData = (readerEvent.target as any).result;
      this.student.patchValue({ 'profilePic': imageData });
    };
    
    this.urls = event.target.files[0];
    reader.readAsDataURL(event.target.files[0]);
  }

  getProfileImageStyle() {
    return 'url(' + this.student.controls['profilePic'].value + ')'
  }

}

