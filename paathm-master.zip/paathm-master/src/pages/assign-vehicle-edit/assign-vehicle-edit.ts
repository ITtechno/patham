import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';


@IonicPage()
@Component({
  selector: 'page-assign-vehicle-edit',
  templateUrl: 'assign-vehicle-edit.html',
})
export class AssignVehicleEditPage {

  token: any;
  res: any;
  results : any;
  getData: any;
  id: any;
  userId: any;


  language : any;
  
  lang : any = {'user':''};
  section : any;
  
  class : FormGroup;

  vehicle : any;
  driver : any;
  route : any;
  trip_date : any;

  driverList : any;
  vehicleList : any;
  routeList : any;

  editData : any;

  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.id = navParams.get('id');

     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          


     this.class = this.formBuilder.group({
              vehicle : ['', Validators.required],
              driver: ['', Validators.required],
              route : ['', Validators.required],
              trip_date : ['', Validators.required]
            });

    this.vehicle = this.class.controls['vehicle'];
    this.driver = this.class.controls['driver'];
    this.route = this.class.controls['route'];    
    this.trip_date = this.class.controls['trip_date'];

  }

  ngOnInit(){
     
     this.getVehicles();
     this.getDrivers();
     this.getRoutes();

     this.getDataEdit();
  }
  
  getVehicles(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="transports/listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.vehicleList = this.res.tpt_vehicles_detatils;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  getDataEdit(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="assign-routes/get/"+this.id;

		      this.user.getCallNode(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
               this.editData = this.res.result[0] != undefined ? this.res.result[0] : [];
               this.class.patchValue({
                                      vehicle : this.editData.vehicle_id ,
                                      driver: this.editData.driver_id,
                                      route : this.editData.route_id,
                                      trip_date : this.editData.trip_date
                                     });
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  getDrivers(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="driver/get-drivers/"+this.token.data.school_id;

		      this.user.getCallNode(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.driverList = this.res.result;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  getRoutes(){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/transports/tpt_routes_listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

               this.routeList = this.res.tpt_routes_detatils;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;

          this.user.getPostNode(this.token.token,'assign-routes/update', {"vehicle_id":this.vehicle.value,
                                                               "id":this.id,
                                                               "driver_id":this.driver.value,
                                                               "route_id":this.route.value,
                                                               "school_id" : this.token.data.school_id,
                                                               "user_id"   : this.token.data.id,
                                                               "trip_date":this.trip_date.value
                                                              }).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AssignVehicleListPage');
  }

}

