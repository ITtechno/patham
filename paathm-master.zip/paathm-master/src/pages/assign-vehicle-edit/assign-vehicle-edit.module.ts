import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AssignVehicleEditPage } from './assign-vehicle-edit';
import { MaterialModule } from '../material.module';

@NgModule({
  declarations: [
    AssignVehicleEditPage,
  ],
  imports: [
    IonicPageModule.forChild(AssignVehicleEditPage),
    MaterialModule
  ],
})
export class AssignVehicleEditPageModule {}
