import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminstudentMainPage } from './adminstudent-main';

@NgModule({
  declarations: [
    AdminstudentMainPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminstudentMainPage),
  ],
})
export class AdminstudentMainPageModule {}
