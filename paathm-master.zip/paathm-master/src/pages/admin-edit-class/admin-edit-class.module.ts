import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminEditClassPage } from './admin-edit-class';

@NgModule({
  declarations: [
    AdminEditClassPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminEditClassPage),
  ],
})
export class AdminEditClassPageModule {}
