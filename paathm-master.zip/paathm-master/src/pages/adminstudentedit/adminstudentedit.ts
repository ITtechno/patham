import { Component , ViewChild } from '@angular/core';
import { IonicPage,Platform, NavController,ActionSheetController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { DatePipe } from '@angular/common';

import { DatePicker } from '@ionic-native/date-picker';

import { Camera } from '@ionic-native/camera';
import { LanguageProvider } from '../../providers';

import { ImagePicker } from '@ionic-native/image-picker';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import moment  from 'moment';

@IonicPage()
@Component({
  selector: 'page-adminstudentedit',
  templateUrl: 'adminstudentedit.html',
})
export class AdminstudenteditPage {

 @ViewChild('fileInput') fileInput;

  token: any;
  res:any;
  students: any;

  approval: any;

  private student:FormGroup ;
  
  addres: any;
  fullName: any;
  studentRollId: any;
  email: any;
  username: any;
  phoneNo: any;
  mobileNo: any;
  studentClass: any;
  studentSection: any;
  hostel: any;
  transport: any;

  gender : any;
  birthday : any;

  classes: any;
  sections: any;

  hostels: any;
  transports: any;

  hostal: any;
  response: any;

  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  stuId: any; 

  urls: any; 
  urlImage: any;

  language : any;
  
  lang : any = {'sec':'','Year':'','editStudent':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};


  constructor(private imagePicker: ImagePicker, public platform :Platform, public actionsheetCtrl :ActionSheetController ,public datepipe: DatePipe, public langs: LanguageProvider , private datePicker: DatePicker, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder , public navCtrl: NavController, public camera: Camera, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
    
    this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

    });

    this.stuId      = navParams.get('id');

    this.classes    = navParams.get("classes");
    this.hostal     = navParams.get("hostels");
    this.transports = navParams.get("transports");


    this.student = this.formBuilder.group({
              fullName: ['', Validators.required],
              studentRollId: ['', Validators.required],
              email: ['', Validators.required],
              username: ['', Validators.required],
              addres : ['', ''],
              gender  : ['', Validators.required],
              birthday: ['', ''],
              profilePic:['',''],
              studentClass: ['', ''],
              studentSection: ['', ''],
              mobileNo: ['', ''],
              phoneNo: ['', ''],
              transport: ['', ''],
              hostel: ['', ''],
            });

    this.fullName = this.student.controls['fullName'];
    this.studentRollId = this.student.controls['studentRollId'];
    this.addres = this.student.controls['addres'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.gender  = this.student.controls['gender'];
    this.birthday = this.student.controls['birthday'];
    this.hostel = this.student.controls['hostel'];
    this.transport = this.student.controls['transport'];
    this.studentClass = this.student.controls['studentClass'];
    this.studentSection = this.student.controls['studentSection'];
    this.mobileNo = this.student.controls['mobileNo'];
    this.phoneNo = this.student.controls['phoneNo'];
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getCall(this.token.token,'v1/students/'+this.stuId).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   
                   this.res = this.res.students;
                   //let parts =this.res.birthday.split('/');
                   
                   
                   //let birthday = this.datepipe.transform(new Date(parts[2] , parts[1] - 1 , parseInt(parts[0])), 'dd/MM/yyyy');
                   
                    let birthday;

                    
                    if(this.res.birthday){

                      birthday = this.res.birthday == null ? '' : moment(this.res.birthday).format('DD/MM/YYYY');
                    }
                
                    let address = '';

                    if(this.res.address){

                       address = this.res.address == null ? '' : this.res.address;
                    }

                   this.student.setValue({"fullName":this.res.fullName,
                   "studentRollId":this.res.studentRollId == null ? '' : this.res.studentRollId,
                   "username":this.res.username,
                   "profilePic":"https://www.paatham.in/lms/index.php/dashboard/profileImage/"+this.res.id,
                   "email":this.res.email == null ? '' : this.res.email,
                   "phoneNo":this.res.phoneNo == null ? '' : this.res.phoneNo,
                   "mobileNo":this.res.mobileNo == null ? '' : this.res.mobileNo,
                   "studentClass":this.res.studentClass == null ? '' : this.res.studentClass,
                   "studentSection":this.res.studentSection == null ? '' : this.res.studentSection,
                   "hostel":this.res.hostel == null ? '' : this.res.hostel,
                   "transport":this.res.transport == null ? '' : this.res.transport,
                   "gender": this.res.gender == null ? '' : this.res.gender,
                   "birthday":birthday,
                   "addres":address});

                   this.profilePic = "https://www.paatham.in/lms/index.php/dashboard/profileImage/"+this.res.id;
                 

               }


                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 
  }

  getSection(){

      this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="materials/getAllSubjectToadd/"+this.studentClass.value;

          this.user.getCall(this.token.token , url).subscribe((resp) => {
            
            this.response = resp;

            if(resp){
               this.sections = this.response.sections;
            
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });
    
  }
  
  showDate()
  {
    this.datePicker.show({
      date: new Date(),
      mode: 'date',
    }).then(
      date => this.response.birthday = this.datepipe.transform(date, 'dd/MM/yyyy'),
      err => console.log('Error occurred while getting date: ', err)
    );
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

    pickImage(){
     
     let options = {
          // if no title is passed, the plugin should use a sane default (preferrably the same as it was, so check the old one.. there are screenshots in the marketplace doc)
          maximumImagesCount: 1,
          title: 'Select Picture',
          message: 'Profile Picture', // optional default no helper message above the picker UI
          // be careful with these options as they require additional processing
          width: 400,
          quality: 80,
          outputType:1
          //             outputType: imagePicker.OutputType.BASE64_STRING
        }

     this.imagePicker.getPictures(options).then((results) => {
        
            this.profilePic = 'data:image/jpg;base64,' + results;
            
            this.urlImage = this.dataURItoBlob(this.profilePic)

      }, (err) => { });

  }

  dataURItoBlob(dataURI) {
    var binary = atob(dataURI.split(',')[1]);
    var array = [];
    for (var i = 0; i < binary.length; i++) {
       array.push(binary.charCodeAt(i));
    }
    return new Blob([new Uint8Array(array)], {
      type: 'image/jpg'
    });
  }

  getPicture() {
    if (Camera['installed']()) {
      this.camera.getPicture({
        destinationType: this.camera.DestinationType.DATA_URL,
        targetWidth: 96,
        targetHeight: 96
      }).then((data) => {
        this.profilePic = 'data:image/jpg;base64,' + data ;
        
        this.urlImage = this.dataURItoBlob(this.profilePic)

      }, (err) => {
        //alert('Unable to take photo');
      })
    } else {
      this.fileInput.nativeElement.click();
    }
  }

  processWebImage(event) {

    let reader = new FileReader();
    reader.onload = (readerEvent) => {

      let imageData = (readerEvent.target as any).result;
      this.profilePic= imageData;
    };
    
    this.urlImage = event.target.files[0];

    console.log(this.urlImage)
    reader.readAsDataURL(event.target.files[0]);
  }

  getProfileImageStyle() {
    return 'url(' + this.profilePic + ')'
  }
  
  openeditprofile() {
    let actionSheet = this.actionsheetCtrl.create({
      title: 'Option',
      cssClass: 'action-sheets-basic-page',
      buttons: [
        {
          text: 'Take photo',
          role: 'destructive',
          icon: !this.platform.is('ios') ? 'ios-camera-outline' : null,
          handler: () => {
            this.getPicture();
          }
        },
        {
          text: 'Choose photo from Gallery',
          icon: !this.platform.is('ios') ? 'ios-images-outline' : null,
          handler: () => {
            this.pickImage();
          }
        },
      ]
    });
    actionSheet.present();
  }

  saveData()
  {
     let fd = new FormData();
     fd.append('username', this.username.value);
     fd.append('email', this.email.value);
     fd.append('fullName', this.fullName.value);
     fd.append('gender', this.gender.value);
     fd.append('birthday', this.birthday.value);
     fd.append('address', this.addres.value);
     fd.append('phoneNo', this.phoneNo.value);
     fd.append('studentRollId', this.studentRollId.value);

     fd.append('mobileNo', this.mobileNo.value);
     fd.append('photo', this.urlImage );
     fd.append('studentClass', this.studentClass.value);
     fd.append('transport', this.mobileNo.value);
     fd.append('hostel', this.mobileNo.value);
     fd.append("studentSection",this.studentSection.value);


    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.getPostMulti(this.token.token,'v1/students/'+this.stuId, fd).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
              
              let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){
                this.navCtrl.push('AdminstudentPage');  
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })
  }


}
