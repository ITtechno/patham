import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminstudenteditPage } from './adminstudentedit';

@NgModule({
  declarations: [
    AdminstudenteditPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminstudenteditPage),
  ],
})
export class AdminstudenteditPageModule {}
