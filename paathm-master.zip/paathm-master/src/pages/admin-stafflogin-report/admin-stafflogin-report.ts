import { Component} from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-stafflogin-report',
  templateUrl: 'admin-stafflogin-report.html',
})
export class AdminStaffloginReportPage {
token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  language : any;

  lang : any = {'ip':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

	constructor(public navCtrl: NavController, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

	}

  ionViewDidLoad() {
    
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getCall(this.token.token,'reports/StaffLoginReports/'+this.token.data.school_id).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   
                   this.response = this.res.staffLogReport;
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }


}

