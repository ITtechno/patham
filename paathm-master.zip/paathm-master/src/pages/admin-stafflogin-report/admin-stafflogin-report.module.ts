import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStaffloginReportPage } from './admin-stafflogin-report';

@NgModule({
  declarations: [
    AdminStaffloginReportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStaffloginReportPage),
  ],
})
export class AdminStaffloginReportPageModule {}
