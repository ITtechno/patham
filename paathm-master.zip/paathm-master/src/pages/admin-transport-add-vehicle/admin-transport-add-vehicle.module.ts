import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminTransportAddVehiclePage } from './admin-transport-add-vehicle';

@NgModule({
  declarations: [
    AdminTransportAddVehiclePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminTransportAddVehiclePage),
  ],
})
export class AdminTransportAddVehiclePageModule {}
