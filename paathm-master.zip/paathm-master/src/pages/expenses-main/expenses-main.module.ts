import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpensesMainPage } from './expenses-main';

@NgModule({
  declarations: [
    ExpensesMainPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpensesMainPage),
  ],
})
export class ExpensesMainPageModule {}
