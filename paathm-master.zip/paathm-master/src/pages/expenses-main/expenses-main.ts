import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-expenses-main',
  templateUrl: 'expenses-main.html',
})
export class ExpensesMainPage {
 
  record: any;
  language: any;
  lang: any = {"People":"","student":"","parents":"","teacher":""};

  constructor(public storage: Storage, public langs: LanguageProvider, public navCtrl: NavController, public navParams: NavParams) {


          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

               console.log(this.lang);
          });

          console.log(this.language);

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AdminpeoplePage');
  }


  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  OpenPage(com: any)
  {
     this.navCtrl.push(com);
  }

}

