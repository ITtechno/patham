import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminEditScheduleClassPage } from './admin-edit-schedule-class';

@NgModule({
  declarations: [
    AdminEditScheduleClassPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminEditScheduleClassPage),
  ],
})
export class AdminEditScheduleClassPageModule {}
