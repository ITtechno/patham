import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-edit-schedule-class',
  templateUrl: 'admin-edit-schedule-class.html',
})
export class AdminEditScheduleClassPage {

  className : any;
  class: FormGroup;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  language : any;
  
  lang : any = {'user':''};
  section : any;

  classes : any;

  teacher: any;
  teacherList: any =[];

  teacherName : any;

  sectionName : any;
  sectionTitle : any;
  subjectName : any;

  sectionList : any;

  passGrade : any;

  finalGrade : any;

  data : any;

  subject : any ;

  day : any;
  
  upId : any;

  startTimeHour : any;
  startTimeMin : any;
  endTimeHour : any;
  endTimeMin : any;
 
  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.section = this.navParams.get('id');
     this.upId = this.navParams.get('schedule_id');
     console.log(this.section);
     this.subject = this.section.subject;

     this.classes = this.section.classes;
     this.teacher = this.section.teachers;


     this.class = this.formBuilder.group({
              subjectName: ['', Validators.required],
              teacherName: ['', Validators.required],
              startTimeHour : ['', Validators.required],
              startTimeMin : [],
              endTimeHour : ['', Validators.required],
              endTimeMin : [],
              day        :  ['', Validators.required],
            });

    this.subjectName = this.class.controls['subjectName'];
    this.teacherName = this.class.controls['teacherName'];
    this.endTimeHour = this.class.controls['endTimeHour'];
    
    this.endTimeMin = this.class.controls['endTimeMin'];
    this.startTimeHour = this.class.controls['startTimeHour'];

    this.startTimeMin = this.class.controls['startTimeMin'];

    this.day = this.class.controls['day'];

    this.getClassSchedule();

  }
  
  getClassSchedule(){
      
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getCall(this.token.token,'v1/classschedule/sub/'+this.upId ).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;
                 
                 if(this.res){
                   this.class.patchValue(
                     {
                      'subjectName':this.res.subjectId,
                      'teacherName':this.res.teacherId,
                      'endTimeHour':this.res.endTimeHour,
                      'endTimeMin' :this.res.endTimeMin,
                      'startTimeHour':this.res.startTimeHour,
                      'startTimeMin' :this.res.startTimeMin,
                      'day'          :this.res.dayOfWeek
                     }
                   );
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });
  }

  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'v1/classschedule/sub/'+this.upId , {dayOfWeek: this.day.value , endTimeHour: this.endTimeHour.value , endTimeMin : this.endTimeMin.value , startTimeHour : this.startTimeHour.value , startTimeMin : this.startTimeMin.value , subjectId : this.subjectName.value, teacherId : this.teacherName.value}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('AdminClassShedulePage');
  }

}


