import { Component } from '@angular/core';
import { IonicPage,AlertController, NavController,ModalController,ActionSheetController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-student-vacation',
  templateUrl: 'admin-student-vacation.html',
})
export class AdminStudentVacationPage {

  inputData: any;
  token: any;
  res: any;
  
  language : any;
  stuId : any;

  class : any;
  section : any;
  from : any;
  to : any;
  student : any;
  
  result : any;

  name : any;

  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  attStatus=['Absent','Present','Late','Late with Execuse','Early Dismissal'];

  constructor(private alertCtrl: AlertController ,public navCtrl: NavController,public actionSheetCtrl:ActionSheetController, public modalCtrl :ModalController, public langs : LanguageProvider , private storage: Storage,  public loadingCtrl: LoadingController, public user: User, public toastCtrl: ToastController , public navParams: NavParams) {

        this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

        });

        this.class   = navParams.get('class');
        this.section = navParams.get('section');
        this.from   = navParams.get('from');
        this.to    = navParams.get('to');
        this.student = navParams.get('student');
  }

  ionViewDidLoad() {
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="v1/reports";

		      this.user.getPost(this.token.token , url , {stats:"stdVacation",data:{
                                                                                        attendanceDayFrom: "25/09/2019",
                                                                                        attendanceDayTo: "25/09/2019",
                                                                                        classId: "223",
                                                                                        fromDate: this.from,
                                                                                        school_id: 0,
                                                                                        sectionId: "286",
                                                                                        status: "All",
                                                                                        studentList: "4231",
                                                                                        toDate: this.to
                                                                                }}).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;
               
               this.name = this.res.student_name;
               this.result = this.res.activityDetails;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }

  AddNewClass(){
    let profileModal = this.modalCtrl.create('AssignVehicleAddPage');
    profileModal.present();
  }

  presentPopover(id: any , tracking : any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Track',
          role: 'track',
          handler: () => {
            if(tracking.length > 1) {
             let profileModal = this.modalCtrl.create('AdminTrackVehicleListPage' , 
                                                    {"id":id ,'data':this.res , 'tracking': tracking});
             profileModal.present();
            }
            else {
              let toast = this.toastCtrl.create({
                message: "Start point route and end point route is not define",
                duration: 3000,
                position: 'top'
              });
              toast.present();
            }
           
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.deleteConfirm(id);
          }
        }
      ]
    });
    actionSheet.present();
  }
  
  deleteConfirm(id : any) {
    this.stuId = id ;
    let alert = this.alertCtrl.create({
      title: 'Confirm',
      message: 'Are you sure want to delete ?',
      buttons: [
        {
          text: 'Confirm',
          role: id,
          handler: id => {
            this.deleteSubject(this.stuId);
            
          }
        },
        {
          text: 'Cancel',
          handler: () => {
            console.log('Buy clicked');
          }
        }
      ]
    });
    alert.present();
  }

  deleteSubject(id : any){
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="subjects/delete/"+this.stuId;

		      this.user.getPost(this.token.token , url , { }).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

               this.res = resp;
               
              if(this.res.status == 'success'){

                    let toast = this.toastCtrl.create({
                  message: this.res.message,
                  duration: 3000,
                  position: 'top'
                });
                toast.present();

                this.reloadPreviousPage();

              }
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });

  }
  
  reloadPreviousPage(){

    this.navCtrl.push('AdminTransportPage');
  }
  
  nextPage(root : any){
    this.navCtrl.setRoot(root);
  }
  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

}


