import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentVacationPage } from './admin-student-vacation';

@NgModule({
  declarations: [
    AdminStudentVacationPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentVacationPage),
  ],
})
export class AdminStudentVacationPageModule {}
