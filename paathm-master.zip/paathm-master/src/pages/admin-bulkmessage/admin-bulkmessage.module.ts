import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminBulkmessagePage } from './admin-bulkmessage';

@NgModule({
  declarations: [
    AdminBulkmessagePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminBulkmessagePage),
  ],
})
export class AdminBulkmessagePageModule {}
