import { Component } from '@angular/core';
import { IonicPage, ActionSheetController,PopoverController , NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

import { DatePipe } from '@angular/common';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-bulkmessage',
  templateUrl: 'admin-bulkmessage.html',
})
export class AdminBulkmessagePage {
  pet: string = "puppies";
  token: any;
  res:any;
  students: any;

  approval: any;

  private bulkMessage:FormGroup ;
  
  userType : any;
  classSelected: any;
  userSelected: any;
  message: any;

  classList : any;


  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;
  studentSuccess: any;
  history: any;
  language : any;
  showClass : any = false;
  showSearch : any = false;

  total_message_day: any;
  total_message_day_date: any;

  total_message_month: any;
  start_date_month : any;
  end_date_month : any;
  
  total_message_week : any;
  start_date_week : any;
  end_date_week : any;

  searchUser : any;

  usersList: any =[]; 

  usersListArray: any = [];

  selectedUser : any = [];

  sender_id : any;

  smsContentType : any;

  lang : any = {'parent':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','admin':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  

  constructor(public datepipe: DatePipe, public langs:LanguageProvider, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder ,public popoverCtrl: PopoverController, public navCtrl: NavController,private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

    this.bulkMessage = formBuilder.group({
              userType: ['', Validators.required],
              message: ['', Validators.required],
              classSelected : [],
              searchUser    : [],
              smsContentType: ['', Validators.required],
              
            });

    this.userType = this.bulkMessage.controls['userType'];
    this.message = this.bulkMessage.controls['message'];
    this.classSelected = this.bulkMessage.controls['classSelected'];
    this.searchUser = this.bulkMessage.controls['searchUser'];
    this.smsContentType = this.bulkMessage.controls['smsContentType'];

    this.bulkMessage.setValue({"smsContentType":"English","userType":'all',"message":'',"classSelected":"" , "searchUser":""});

  }
  
  enableClass(){

     if(this.userType.value == 'students' || this.userType.value == 'parents'){
         
         this.showSearch = false;
         this.showClass = true;

         this.usersListArray = [];
         this.selectedUser = [];
     }
     else if(this.userType.value == 'users'){
         this.showClass = false;
         this.showSearch = true;
     }
     else
     {
        this.showSearch = false;
        this.showClass = false;
        this.usersListArray = [];
        this.selectedUser = [];
     }
  }
  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getCall(this.token.token,'mobileNotif/listAll/'+this.page).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   this.history = this.res.items;

                   this.classList = this.res.classes;

                   this.totalData= parseInt(this.res.totalItems);

                   if(this.totalData % this.perPage == 0)
                   {
                        this.totalPage = this.totalData / this.perPage ; 
                   }else
                   {
                        this.totalPage = this.totalData / this.perPage + 1; 
                   }
                   
                   this.sender_id = this.res.sender_id;
                   this.total_message_day = this.res.total_message_day;
                   this.total_message_day_date = this.res.total_message_day_date;

                   this.total_message_month = this.res.total_message_month;
                   this.start_date_month = this.res.start_date_month;
                   this.end_date_month = this.res.end_date_month;
                    
                   this.total_message_week = this.res.total_message_week;
                   this.start_date_week    = this.res.start_date_week;
                   this.end_date_week      = this.res.end_date_week;
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 
  }
  
  selectUser(use : any){
     if(this.selectedUser.indexOf(use.user) == -1){
         this.selectedUser.push(use.user);
     }

     console.log(this.selectedUser);
  }

  deleteUser(use : any){
     if(this.selectedUser.indexOf(use) != -1){
        
      this.selectedUser.splice(this.selectedUser.indexOf(use) , 1);
     }
  }

  getUsers(){

   this.storage.get('auth_user').then((val) => {
    
        this.token= val;
        
        let tot = this.searchUser.value;
        if( tot.length < 2){
          this.usersListArray = [];
          return;
        }
        this.user.getCall(this.token.token,'mobileNotif/searchUsers/all/'+tot).subscribe((resp) => {
 
            if(resp){

               this.usersList = resp;
               
               this.usersListArray = [];
               if(this.usersList){
                    for (let key in this.usersList) {
                          
                      this.usersListArray.push({'user':this.usersList[key],'id':key});

                    }

                    console.log(this.usersListArray)
               }
               
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

            this.storage.clear();
            this.navCtrl.setRoot('LoginPage');

          })

   }); 

 } 

 doInfinite(infiniteScroll) {
  this.page = this.page+1;
  setTimeout(() => {
    this.user.getCall(this.token.token,'mobileNotif/listAll/'+this.page)
       .subscribe(
         (resp) =>{
            if(resp){

               this.getData = resp;
               
               for (let key in this.getData.items) {
                  this.history.push(this.getData.items[key]);
 
                }

               this.totalData= this.getData.totalItems;

               if(this.totalData % this.perPage == 0)
               {
                    this.totalPage = this.totalData / this.perPage ; 
               }else
               {
                    this.totalPage = this.totalData / this.perPage + 1; 
               }
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();
               this.storage.clear();
               this.navCtrl.setRoot('LoginPage');
          }
       );

      infiniteScroll.complete();
    }, 1000);
  }

   presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.navCtrl.push('AdminparenteditPage',{"id":id});
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
  }

  saveForm(){
    
    console.log(this.selectedUser);

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    let DataValue = {'smsContentType':this.smsContentType.value,'classId':this.classSelected.value ,'sender_id':this.sender_id,'selectedUsers':this.selectedUser,'notifData':this.message.value,'userType':this.userType.value};
    this.user.getPostMulti(this.token.token,'mobileNotif', DataValue).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
               
              this.history = this.studentSuccess.items;

              this.classList = this.studentSuccess.classes;

              this.totalData= parseInt(this.studentSuccess.totalItems);

              if(this.totalData % this.perPage == 0)
              {
                  this.totalPage = this.totalData / this.perPage ; 
              }else
              {
                  this.totalPage = this.totalData / this.perPage + 1; 
              }
              
              this.sender_id = this.studentSuccess.sender_id;
              this.total_message_day = this.studentSuccess.total_message_day;
              this.total_message_day_date = this.studentSuccess.total_message_day_date;

              this.total_message_month = this.studentSuccess.total_message_month;
              this.start_date_month = this.studentSuccess.start_date_month;
              this.end_date_month = this.studentSuccess.end_date_month;
              
              this.total_message_week = this.studentSuccess.total_message_week;
              this.start_date_week    = this.studentSuccess.start_date_week;
              this.end_date_week      = this.studentSuccess.end_date_week;


                    let toast = this.toastCtrl.create({
                      message: 'Message Queued for sending successfully',
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

    removeUser(id: any){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="parents/delete/"+id;

          this.user.getPost(this.token.token , url , {}).subscribe((resp) => {
            loading.dismiss();

            this.studentSuccess = resp;

            let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){

                    let active = this.navCtrl.getActive(); 
                    this.navCtrl.remove(active.index);
                    this.navCtrl.push(active.component);

              }

          }, (err) => {
            
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });

  }

}
