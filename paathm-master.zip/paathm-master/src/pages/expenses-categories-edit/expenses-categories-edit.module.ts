import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpensesCategoriesEditPage } from './expenses-categories-edit';

@NgModule({
  declarations: [
    ExpensesCategoriesEditPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpensesCategoriesEditPage),
  ],
})
export class ExpensesCategoriesEditPageModule {}
