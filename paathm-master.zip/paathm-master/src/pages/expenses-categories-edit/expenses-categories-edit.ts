import { Component } from '@angular/core';
import { IonicPage, NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-expenses-categories-edit',
  templateUrl: 'expenses-categories-edit.html',
})
export class ExpensesCategoriesEditPage {

  className : any;
  class: FormGroup;

  token: any;
  res: any;
  results = [];
  getData: any;
  id: any;
  userId: any;

  responses: any;
  sect: any;
  name: any;

  language : any;
  
  lang : any = {'user':''};
  section : any;

  classes : any;

  teacher: any;
  teacherList: any =[];

  teacherName : any;

  cat_title : any;
  cat_desc : any;

  passGrade : any;

  finalGrade : any;

  data : any;

  constructor(public formBuilder: FormBuilder , public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage ,public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
          
     this.section = this.navParams.get('id');

     this.class = this.formBuilder.group({
              cat_title: ['', Validators.required],
              cat_desc: ['', Validators.required]
            });

    this.cat_title = this.class.controls['cat_title'];
    this.cat_desc = this.class.controls['cat_desc'];

    this.getCategory();

  }


  getCategory(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getCall(this.token.token,'v1/expensesCat/'+ this.section).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 this.class.patchValue({cat_title:this.res.cat_title , cat_desc : this.res.cat_desc });
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }


  saveClass(){
       
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'v1/expensesCat/'+ this.section, this.class.value).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res.status == 'success'){

                      let toast = this.toastCtrl.create({
		                message: this.res.message,
		                duration: 3000,
		                position: 'top'
		              });
		              toast.present();

		              this.reloadPreviousPage();

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }

  closeModal() {
        this.navCtrl.pop();
  }

  reloadPreviousPage(){

       this.navCtrl.push('ExpensesCategoriesPage');
  }

}


