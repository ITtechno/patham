import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams , LoadingController, ToastController  } from 'ionic-angular';
import { User } from '../../providers';

import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-exams',
  templateUrl: 'exams.html',
})
export class ExamsPage {

	  token: any;
	  res: any;
	  results:any;
	  getData: any;
	  chapterId: any;
	  title: any;

    //Response from takeTest Api
    resResult: any;
    examQues: any;

    language : any;
  lang : any;

  from : any;

  constructor(public navCtrl: NavController, public langs : LanguageProvider , private storage: Storage , public navParams: NavParams, public user: User, public toastCtrl: ToastController ,   public loadingCtrl: LoadingController) {
     
     this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });
      
  	 this.token = navParams.get('token');
     this.chapterId = navParams.get('chapterId');
     this.title= navParams.get('title'); 
     this.from= navParams.get('from'); 
  }

  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.getExamLists( this.token , this.chapterId , this.from ).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){

           this.res = resp;
           this.results = this.res.onlineExams;

           if(this.results.length == 0)
           {   
                  let toast = this.toastCtrl.create({
                    message: "There is no exams available.",
                    duration: 3000,
                    position: 'top'
                  });
                  toast.present();

                  this.navCtrl.pop();
           }
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');

      })

  }

  takeTest(id: any)
  {
  	console.log(this.token);
  	let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);
    
    this.user.takeTest( this.token , id ).subscribe((resp) => {
               
        loading.dismiss();  
        if(resp){

           this.resResult = resp;

           if(this.resResult.status == "failed" )
           {
                   let toast = this.toastCtrl.create({
                      message: "You already took this exam before",
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();
           }
           else
           {
               if(this.resResult.completePrevExam)
               {
                   let toast = this.toastCtrl.create({
                      message: "You must complete the test of previous chapter",
                      duration: 5000,
                      position: 'top'
                    });
                    toast.present();
               }else
               {
                   this.examQues = this.resResult.examQuestion;
                  
                   let examtitle = this.resResult.examTitle ;
                   let chapter = this.resResult.examDescription;
                   let time = this.resResult.timeLeft;

                   this.navCtrl.push('QuestionsPage' , { record: this.examQues ,time: time, examtitle: examtitle, token: this.token , chapter: chapter ,exam: this.resResult });
               }
           }
           
        }

      }, (err) => {

        loading.dismiss(); 

        let toast = this.toastCtrl.create({
          message: "Session has been expired",
          duration: 3000,
          position: 'top'
        });
        toast.present();

        this.storage.clear();
        this.navCtrl.setRoot('LoginPage');

      })
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

}
