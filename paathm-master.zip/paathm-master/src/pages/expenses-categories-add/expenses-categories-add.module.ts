import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ExpensesCategoriesAddPage } from './expenses-categories-add';

@NgModule({
  declarations: [
    ExpensesCategoriesAddPage,
  ],
  imports: [
    IonicPageModule.forChild(ExpensesCategoriesAddPage),
  ],
})
export class ExpensesCategoriesAddPageModule {}
