import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminAssignMentListPage } from './admin-assign-ment-list';

@NgModule({
  declarations: [
    AdminAssignMentListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminAssignMentListPage),
  ],
})
export class AdminAssignMentListPageModule {}
