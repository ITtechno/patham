import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminStudentExamDetailsPage } from './admin-student-exam-details';

@NgModule({
  declarations: [
    AdminStudentExamDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminStudentExamDetailsPage),
  ],
})
export class AdminStudentExamDetailsPageModule {}
