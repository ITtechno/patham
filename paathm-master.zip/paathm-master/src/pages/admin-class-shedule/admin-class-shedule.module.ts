import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminClassShedulePage } from './admin-class-shedule';

@NgModule({
  declarations: [
    AdminClassShedulePage,
  ],
  imports: [
    IonicPageModule.forChild(AdminClassShedulePage),
  ],
})
export class AdminClassShedulePageModule {}
