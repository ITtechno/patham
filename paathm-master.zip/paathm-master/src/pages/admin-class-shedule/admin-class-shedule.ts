import { Component} from '@angular/core';
import { IonicPage, NavController,ModalController, LoadingController, NavParams, ToastController , ViewController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-class-shedule',
  templateUrl: 'admin-class-shedule.html',
})
export class AdminClassShedulePage {
   token: any;
  res:any;

  response: any;

  getData: any;

  profilePic: any;

  studentSuccess: any;

  language : any;
  
  teacherList:any =[];

  respn : any =[];

  lang : any = {'sec':'','Year':'','Total':'','paathamActivity':'','editStudent':'','Present':'','studentExamReport':'','indivStdActHistory':'','studentVacation':'','indivStdLogSession':'','month':'','Hostel':'','ip':'','listStudents':'','addStudent':'','rollid':'','StudentLoginStats':'','listTeachers':'','editParent':'','from':'','to':'','Search':'','Transportation':'','EmailAddress':'','teacher':'','addTeacher':'','student':'','StaffLoginReports':'','class':'','section':'','controlAttendance':'','Attendance':'','staff':'','parent':'','admin':'','password':'','Birthday':'','Address':'','Male':'','Female':'','phoneNo':'','phoneMobile':'','Gender':'','email':'','listParents':'','waitingApproval':'','AddParent':'','username':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};

	constructor( public modalCtrl: ModalController, public navCtrl: NavController, public langs : LanguageProvider , public viewCtrl: ViewController
	, private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {
      
      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

      });
	}

  ionViewDidLoad() {
    
         let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
          
          console.log(val);

          this.user.getCall(this.token.token,'classschedule/listAll').subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   

                    this.response = this.res.sections;
                   
                    for (let key in this.response) {
                      
		                    this.respn.push({'sections':this.response[key],'classs':key});

		                 }

                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     });

  }
  
  teacherS(teacher: any){

  	let teacherName = '';
    for (let key in this.teacherList) {
        
        if(teacher == this.teacherList[key].id) {       
		  teacherName = this.teacherList[key].name;
	    }
    }

    return teacherName;

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

  navPage(com : any){

    this.navCtrl.push("LoginreportPage",{"id":com});

  }

  showSchedule(id : any){
     let profileModal = this.modalCtrl.create('AdminScheduleClassListPage' , { "id" : id ,'res': this.res });
     profileModal.present();
  }


}