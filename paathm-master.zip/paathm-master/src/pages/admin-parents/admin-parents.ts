import { Component } from '@angular/core';
import { IonicPage, ActionSheetController,PopoverController , NavController,LoadingController, NavParams, ToastController } from 'ionic-angular';
import { User } from '../../providers';
import { Storage } from '@ionic/storage';

import {Validators,FormBuilder, FormGroup } from '@angular/forms';

import { DatePipe } from '@angular/common';

import { LanguageProvider } from '../../providers';

import { MenuController } from 'ionic-angular';

@IonicPage()
@Component({
  selector: 'page-admin-parents',
  templateUrl: 'admin-parents.html',
})
export class AdminParentsPage {
  pet: string = "puppies";
  token: any;
  res:any;
  students: any;

  approval: any;

  private student:FormGroup ;
  
  searchText :any;
  searchGender : any;
  searchEmail :any;

  address : any;
  fullName: any;
  studentRollId: any;
  email: any;
  username: any;
  password: any;
  phoneNo: any;
  mobileNo: any;
  studentClass: any;
  studentSection: any;
  hostel: any;
  transport: any;

  gender : any;
  birthday : any;


  page = 1;
  perPage = 20;
  totalData = 0;
  totalPage = 0;

  getData: any;

  studentSuccess: any;

  language : any;

  lang : any = {'parent':'','password':'','Birthday':'','Address':'','AddParent':'','Male':'','Female':'','phoneNo':'','Gender':'','email':'','listParents':'','waitingApproval':'','username':'','admin':'','FullName':'' ,'ParentLoginReports':'','Name':'','ID':'','lastLogin':'', 'Reports':'','Notes':'','Category':'','Date':'','expenseAmount':'','UsersStats':'','Expenses':'','expenseTitle':'','Payments':'','marksheetGen':''};
  

  constructor(public datepipe: DatePipe, public menuCtrl:MenuController ,  public langs:LanguageProvider, public actionSheetCtrl: ActionSheetController,public formBuilder: FormBuilder ,public popoverCtrl: PopoverController, public navCtrl: NavController,private storage: Storage ,  public navParams: NavParams, public user: User, public toastCtrl: ToastController ,  public loadingCtrl: LoadingController) {

          this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });

    this.student = formBuilder.group({
              fullName: ['', Validators.required],
              email: ['', Validators.compose([
                        Validators.required,
                        Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')
                      ])],
              username: ['', Validators.required],
              password: ['', Validators.required],
              gender  : ['', ''],
              birthday: ['', ''],
              studentClass: ['', ''],
              studentSection: ['', ''],
              mobileNo: ['', ''],
              phoneNo: ['', ''],
              address:['','']
            });

    this.fullName = this.student.controls['fullName'];
    this.address = this.student.controls['address'];
    this.email  = this.student.controls['email'];
    this.username = this.student.controls['username'];
    this.password = this.student.controls['password'];
    this.gender  = this.student.controls['gender'];
    this.birthday = this.student.controls['birthday'];

    this.mobileNo = this.student.controls['mobileNo'];
    this.phoneNo = this.student.controls['phoneNo'];
  }

   
  toggleMenu() {
    this.menuCtrl.toggle('authenticated');
  }


    
  advanceSearch(){


    if(this.searchText == '' && this.searchGender == '' && this.searchEmail == ''){
         
         let toast = this.toastCtrl.create({
           message: "Please fill atleast one field",
           duration: 3000,
           position: 'top'
         });
         toast.present();

         return false;
    }

    this.menuCtrl.close('authenticated');
    
    this.storage.get('auth_user').then((val) => {
     
         this.token= val;
   
         this.user.getPost(this.token.token,'parents/listAll/1', {searchInput: { text : this.searchText ,
                                                                                            email: this.searchEmail ,
                                                                                            gender:this.searchGender }}).subscribe((resp) => {
                    

             if(resp){

              this.res = resp;

              if(this.res){
                this.students=this.res.parents;

                this.totalData= parseInt(this.res.totalItems);

                if(this.totalData % this.perPage == 0)
                {
                     this.totalPage = this.totalData / this.perPage ; 
                }
                else
                {
                     this.totalPage = this.totalData / this.perPage + 1; 
                }
              }
                
             }

           }, (err) => {


             let toast = this.toastCtrl.create({
               message: "Session has been expired",
               duration: 3000,
               position: 'top'
             });
             toast.present();

             this.storage.clear();
             this.navCtrl.setRoot('LoginPage');

           })

    });  
 }
  
  ionViewDidLoad() {
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);


     this.storage.get('auth_user').then((val) => {
      
          this.token= val;
    
          this.user.getPost(this.token.token,'parents/listAll/'+this.page , {sortBy: "id + 0 DESC"}).subscribe((resp) => {
                     
              loading.dismiss();  
              if(resp){

                 this.res = resp;

                 if(this.res){
                   this.students=this.res.parents;

                   this.totalData= parseInt(this.res.totalItems);

                   if(this.totalData % this.perPage == 0)
                   {
                        this.totalPage = this.totalData / this.perPage ; 
                   }
                   else
                   {
                        this.totalPage = this.totalData / this.perPage + 1; 
                   }
                 }
                 
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

     }); 
  }

 doInfinite(infiniteScroll) {
  this.page = this.page+1;
  setTimeout(() => {
    this.user.getCall(this.token.token,'parents/listAll/'+this.page)
       .subscribe(
         (resp) =>{
            if(resp){

               this.getData = resp;
               
               for (let key in this.getData.messages) {
                  this.students.push(this.getData.messages[key]);
 
                }

               this.totalData= this.getData.totalItems;

               if(this.totalData % this.perPage == 0)
               {
                    this.totalPage = this.totalData / this.perPage ; 
               }else
               {
                    this.totalPage = this.totalData / this.perPage + 1; 
               }
            }

          }, (err) => {

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();
               this.storage.clear();
               this.navCtrl.setRoot('LoginPage');
          }
       );

      infiniteScroll.complete();
    }, 1000);
  }

   presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {
            this.navCtrl.push('AdminparenteditPage',{"id":id});
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
  }

  saveForm(){
    
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    let dataValue = {"username":this.username.value,"email":this.email.value,"fullName":this.fullName.value,"password":this.password.value,"gender":this.gender.value,"address":this.address.value,"phoneNo":this.phoneNo.value,"mobileNo":this.mobileNo.value,"birthday":this.datepipe.transform(this.birthday.value, 'dd/MM/yyyy')};
    
    this.user.getPostMulti(this.token.token,'parents', dataValue).subscribe((resp) => {
                     
              loading.dismiss(); 

              this.studentSuccess = resp;
              
              let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){
                this.navCtrl.push('AdminParentsPage');  
              }

            }, (err) => {

              loading.dismiss(); 

              let toast = this.toastCtrl.create({
                message: "Session has been expired",
                duration: 3000,
                position: 'top'
              });
              toast.present();

              this.storage.clear();
              this.navCtrl.setRoot('LoginPage');

            })

  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

    removeUser(id: any){

    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
          this.token = val;

          let url ="parents/delete/"+id;

          this.user.getPost(this.token.token , url , {}).subscribe((resp) => {
            loading.dismiss();

            this.studentSuccess = resp;

            let toast = this.toastCtrl.create({
                      message: this.studentSuccess.message,
                      duration: 3000,
                      position: 'top'
                    });
                    toast.present();

              if(this.studentSuccess.status == 'success' ){

                    let active = this.navCtrl.getActive(); 
                    this.navCtrl.remove(active.index);
                    this.navCtrl.push(active.component);

              }

          }, (err) => {
            
            loading.dismiss();

            let toast = this.toastCtrl.create({
              message: "Session has been expired",
              duration: 3000,
              position: 'top'
            });
            toast.present();

                this.storage.clear();
                this.navCtrl.setRoot('LoginPage');
          })

      });

  }

}
