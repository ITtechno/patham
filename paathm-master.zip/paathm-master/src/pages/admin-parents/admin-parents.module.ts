import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminParentsPage } from './admin-parents';

@NgModule({
  declarations: [
    AdminParentsPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminParentsPage),
  ],
})
export class AdminParentsPageModule {}
