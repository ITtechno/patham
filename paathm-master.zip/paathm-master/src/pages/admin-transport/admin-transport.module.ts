import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminTransportPage } from './admin-transport';

@NgModule({
  declarations: [
    AdminTransportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminTransportPage),
  ],
})
export class AdminTransportPageModule {}
