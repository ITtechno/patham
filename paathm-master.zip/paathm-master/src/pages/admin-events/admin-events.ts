import { Component } from '@angular/core';
import { IonicPage, ActionSheetController,ModalController,PopoverController, NavController, NavParams,LoadingController , ToastController } from 'ionic-angular';

import { User } from '../../providers';
import { Storage } from '@ionic/storage';
import { LanguageProvider } from '../../providers';

@IonicPage()
@Component({
  selector: 'page-admin-events',
  templateUrl: 'admin-events.html',
})
export class AdminEventsPage {
  inputData: any;
  token: any;
  res: any;
  
  language : any;

  teacherList: any = [];

  subjects: any;

  lang : any = {'Transportation':'' , 'vehicle_name':'','vehicle_type':'','startTime':'','endTime':'','from_place':'','to_place':'','cost':''};

  
  constructor(public navCtrl: NavController, public modalCtrl: ModalController, public actionSheetCtrl: ActionSheetController,public popoverCtrl: PopoverController, public langs : LanguageProvider , private storage: Storage,  public loadingCtrl: LoadingController, public user: User, public toastCtrl: ToastController , public navParams: NavParams) {

      this.langs.language().then( res => {

               this.language = res;
               
               if(this.language.dashRecord){
                  this.lang = this.language.dashRecord.language;
               }

          });
  }

  ionViewDidLoad() {
    let loading = this.loadingCtrl.create({content:'Please Wait..'});
    loading.present(loading);

    this.storage.get('auth_user').then((val) => {
     
		      this.token = val;

		      let url ="events/listAll";

		      this.user.getCall(this.token.token , url).subscribe((resp) => {
		               
		        loading.dismiss();  
		        if(resp){

		           this.res = resp;

                   this.subjects = this.res.events;
		        
		        }

		      }, (err) => {

		        loading.dismiss(); 

		        let toast = this.toastCtrl.create({
		          message: "Session has been expired",
		          duration: 3000,
		          position: 'top'
		        });
		        toast.present();

		            this.storage.clear();
		            this.navCtrl.setRoot('LoginPage');
		      })

      });
  }
  
  teacherS(teacher: any){
  
    let teacherName = JSON.parse(teacher);
    let teachers='N/A';

    if(teacherName.length > 0){
      for (let name in teacherName) {  
        for (let key in this.teacherList) { 
          if(teacherName[name] == this.teacherList[key].id) { 
            teachers = this.teacherList[key].name.fullName;
          }
        }
      }
    }

    return teachers;

  }
  
  presentPopover(id: any) {
    const actionSheet = this.actionSheetCtrl.create({
      title: 'Action',
      buttons: [
        {
          text: 'Edit',
          role: 'edit',
          handler: () => {

           
          }
        },{
          text: 'Remove',
          role: 'remove',
          handler: () => {
            this.removeUser(id);
          }
        }
      ]
    });
    actionSheet.present();
}

removeUser(id : any){

}

  onInputData(event: any)
  {

    return this.res.filter((item) => {
            return item;
        });  

  }

  AddEvent(){
     let profileModal = this.modalCtrl.create('AdminAddEventsPage');
     profileModal.present();
  }

  nextPage(com: any)
  {
     this.navCtrl.setRoot(com);
  }

}

