import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminExpenseReportPage } from './admin-expense-report';

@NgModule({
  declarations: [
    AdminExpenseReportPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminExpenseReportPage),
  ],
})
export class AdminExpenseReportPageModule {}
