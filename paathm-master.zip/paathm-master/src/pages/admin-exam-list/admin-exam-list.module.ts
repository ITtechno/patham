import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AdminExamListPage } from './admin-exam-list';

@NgModule({
  declarations: [
    AdminExamListPage,
  ],
  imports: [
    IonicPageModule.forChild(AdminExamListPage),
  ],
})
export class AdminExamListPageModule {}
